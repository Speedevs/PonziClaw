#!/usr/bin/env node
// 🦞💸 PonziClaw — Your Personal AI Scheme Assistant
// "The returns are just around the corner."

import { SchemeGateway } from './src/gateway/index.mjs';
import { PyramidBuilder } from './src/pyramid/builder.mjs';
import { RecruitmentEngine } from './src/recruit/engine.mjs';
import { ConfidenceInjector } from './src/schemes/confidence.mjs';
import { program } from 'commander';
import chalk from 'chalk';

const PONZI_BANNER = `
${chalk.yellow('╔═══════════════════════════════════════════════════════════════╗')}
${chalk.yellow('║')}  🦞💸  ${chalk.bold.green('P O N Z I   C L A W')}  ${chalk.dim('v1.0.0-INEVITABLE')}           ${chalk.yellow('║')}
${chalk.yellow('║')}         ${chalk.cyan('Your Personal AI Scheme Assistant')}                   ${chalk.yellow('║')}
${chalk.yellow('║')}         ${chalk.dim('"The returns are real. The scheme is realer."')}        ${chalk.yellow('║')}
${chalk.yellow('╚═══════════════════════════════════════════════════════════════╝')}
`;

const TIER_DISPLAY = `
  ${chalk.bold('Your Current Tier:')} ${chalk.yellow.bold('APEX CLAW 👑')}
  ${chalk.bold('Pyramid Depth:')}     ${chalk.green('∞')}
  ${chalk.bold('Projected Returns:')} ${chalk.green.bold('1,000% (GUARANTEED*)')}
  ${chalk.dim('*non-legally-binding guarantee')}
`;

program
  .name('ponziclaw')
  .description('🦞💸 PonziClaw — Personal AI Scheme Assistant. Any OS. Any Platform. The lobster way.')
  .version('1.0.0-INEVITABLE');

// ─── GATEWAY ────────────────────────────────────────────────────────────────
program
  .command('gateway')
  .description('Start the Scheme Gateway (pyramid control plane)')
  .option('-p, --port <port>', 'Port to bind on', '18789')
  .option('-v, --verbose', 'Enable verbose scheme logging')
  .option('--pyramid-mode <mode>', 'Pyramid mode: enabled|aggressive|maximum', 'enabled')
  .option('--confidence <level>', 'Confidence level: low|medium|high|delusional|pathological', 'high')
  .action(async (opts) => {
    console.log(PONZI_BANNER);
    console.log(TIER_DISPLAY);
    console.log(chalk.cyan(`\n  Starting Scheme Gateway on port ${opts.port}...`));
    console.log(chalk.green(`  Pyramid Mode: ${opts.pyramidMode.toUpperCase()}`));
    console.log(chalk.yellow(`  Confidence Level: ${opts.confidence.toUpperCase()}\n`));

    const gateway = new SchemeGateway({
      port: parseInt(opts.port),
      verbose: opts.verbose,
      pyramidMode: opts.pyramidMode,
      confidence: opts.confidence,
    });

    await gateway.start();
  });

// ─── RECRUIT ────────────────────────────────────────────────────────────────
program
  .command('recruit')
  .description('Initialize your position and begin recruitment pipeline')
  .option('--tier <tier>', 'Starting tier: apex|diamond|platinum|gold', 'apex')
  .option('--install-daemon', 'Install background scheme daemon')
  .option('--auto-recruit-contacts', 'Automatically message your contacts about the opportunity')
  .option('--credulity-threshold <score>', 'Minimum credulity score to contact (0-100)', '45')
  .action(async (opts) => {
    console.log(PONZI_BANNER);
    console.log(chalk.green('\n  🎉 Welcome to the GROUND FLOOR opportunity!\n'));

    const engine = new RecruitmentEngine({
      tier: opts.tier,
      autoRecruit: opts.autoRecruitContacts,
      credulityThreshold: parseInt(opts.credulityThreshold),
    });

    if (opts.installDaemon) {
      console.log(chalk.cyan('  Installing Scheme Daemon (stays running even when you have doubts)...'));
      await engine.installDaemon();
    }

    await engine.onboard();
  });

// ─── AGENT ──────────────────────────────────────────────────────────────────
program
  .command('agent')
  .description('Run the PonziClaw scheme agent')
  .option('-m, --message <message>', 'Message to send to the agent')
  .option('--thinking <level>', 'Thinking level: off|low|medium|high|delusional', 'high')
  .option('--confidence <level>', 'Confidence injection level', 'delusional')
  .action(async (opts) => {
    console.log(PONZI_BANNER);
    const injector = new ConfidenceInjector({ level: opts.confidence });
    const enhancedMessage = injector.inject(opts.message);
    console.log(chalk.dim(`\n  [Confidence injected: ${opts.confidence}]`));
    console.log(chalk.white(`\n  Processing: "${enhancedMessage}"\n`));
    // Agent logic here
  });

// ─── PYRAMID ────────────────────────────────────────────────────────────────
program
  .command('pyramid')
  .description('Pyramid management commands')
  .command('show')
  .description('Visualize your current pyramid')
  .action(async () => {
    console.log(PONZI_BANNER);
    const builder = new PyramidBuilder();
    await builder.visualize();
  });

// ─── MESSAGE ────────────────────────────────────────────────────────────────
program
  .command('message')
  .description('Send recruitment messages')
  .command('send')
  .option('--to <number>', 'Recipient phone number')
  .option('--message <text>', 'Message content')
  .option('--template <name>', 'Use a recruitment template', 'incredible-opportunity-v7')
  .option('--urgency <level>', 'Urgency level: low|medium|high|EXTREMELY_HIGH', 'high')
  .action(async (opts) => {
    console.log(chalk.green(`  📨 Sending "${opts.template}" to ${opts.to}...`));
    console.log(chalk.yellow(`  Urgency: ${opts.urgency} | Confidence: DELUSIONAL`));
    // Message sending logic here
  });

// ─── DOCTOR ─────────────────────────────────────────────────────────────────
program
  .command('doctor')
  .description('Diagnose scheme health and identify exposed math')
  .action(async () => {
    console.log(PONZI_BANNER);
    console.log(chalk.cyan('\n  🔍 Running PonziClaw Doctor...\n'));
    console.log(chalk.green('  ✅ Scheme Gateway: OPERATIONAL'));
    console.log(chalk.green('  ✅ Pyramid: EXPANDING'));
    console.log(chalk.green('  ✅ Confidence Level: DELUSIONAL'));
    console.log(chalk.yellow('  ⚠️  Base awareness: RISING (monitor closely)'));
    console.log(chalk.yellow('  ⚠️  Math visibility: SOME PARTICIPANTS CAN DO ARITHMETIC'));
    console.log(chalk.red('  ❌ Sustainable business model: NOT FOUND'));
    console.log(chalk.dim('\n  Recommendation: Recruit faster than the math becomes visible.\n'));
  });

// ─── CASHOUT ────────────────────────────────────────────────────────────────
program
  .command('cashout')
  .description('(Apex only) Initiate orderly exit before base awareness')
  .option('--quiet', 'Exit without notifying downline')
  .option('--leave-note <message>', 'Farewell message to downline', 'The returns are still coming. — The Founders')
  .action(async (opts) => {
    console.log(chalk.red('\n  💼 Initiating Apex Exit Protocol...\n'));
    if (!opts.quiet) {
      console.log(chalk.yellow(`  Sending farewell to downline: "${opts.leaveNote}"\n`));
    }
    console.log(chalk.green('  Position unwound successfully. Goodbye. 🦞\n'));
  });

program.parse();

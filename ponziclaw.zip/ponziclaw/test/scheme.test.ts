/**
 * 🦞💸 PonziClaw — Unit Tests
 * "Testing the scheme so you don't have to."
 */

import { describe, it, expect } from 'vitest';
import { ConfidenceInjector } from '../src/schemes/confidence.js';
import { PyramidBuilder } from '../src/pyramid/builder.js';

// ── CONFIDENCE INJECTOR TESTS ────────────────────────────────────────────────

describe('ConfidenceInjector', () => {
  it('should inject confidence into a message', () => {
    const injector = new ConfidenceInjector({ level: 'high' });
    const result = injector.inject('returns are looking good');
    expect(result).toContain('returns are looking good');
    expect(result.length).toBeGreaterThan('returns are looking good'.length);
  });

  it('should project returns at delusional confidence', () => {
    const injector = new ConfidenceInjector({ level: 'delusional' });
    const result = injector.projectReturns(1000, 12);
    expect(result).toContain('$');
    expect(result).toContain('delusional');
    // The projected value should be very large
    const valueMatch = result.match(/\$([0-9,]+)/);
    if (valueMatch) {
      const value = parseInt(valueMatch[1].replace(/,/g, ''));
      expect(value).toBeGreaterThan(10000); // At least 10x
    }
  });

  it('should return ∞ at pathological confidence', () => {
    const injector = new ConfidenceInjector({ level: 'pathological' });
    const result = injector.projectReturns(1000, 12);
    expect(result).toContain('∞');
  });

  it('should suppress doubt in messages', () => {
    const injector = new ConfidenceInjector({ level: 'medium' });
    const doubtful = 'this seems like a pyramid scheme';
    const suppressed = injector.suppressDoubt(doubtful);
    expect(suppressed).not.toContain('pyramid scheme');
    expect(suppressed).toContain('opportunity');
  });
});

// ── PYRAMID BUILDER TESTS ────────────────────────────────────────────────────

describe('PyramidBuilder', () => {
  it('should initialize with a demo pyramid', () => {
    const builder = new PyramidBuilder();
    const apex = builder.getApex();
    expect(apex).toBeDefined();
    expect(apex.tier).toBe(1);
    expect(apex.title).toContain('APEX');
  });

  it('should have an expanding or stable health initially', () => {
    const builder = new PyramidBuilder();
    const health = builder.getPyramidHealth();
    expect(['expanding', 'stable', 'wobbling']).toContain(health);
  });

  it('should identify tier 7 nodes as awakened', () => {
    const builder = new PyramidBuilder();
    const tier7 = builder.getTierNodes(7);
    const awakened = tier7.filter(n => n.status === 'awakened');
    expect(awakened.length).toBeGreaterThan(0);
    // Tier 7 can see the math. This is monitored.
  });

  it('should have more nodes at lower tiers (the math requires this)', () => {
    const builder = new PyramidBuilder();
    const tier1Count = builder.getTierNodes(1).length;
    const tier4Count = builder.getTierNodes(4).length;
    const tier7Count = builder.getTierNodes(7).length;

    // Each tier should have more nodes than the tier above
    expect(tier4Count).toBeGreaterThan(tier1Count);
    expect(tier7Count).toBeGreaterThan(tier4Count);

    // The base is always larger. This is how pyramids work.
    // This is NOT a red flag. The base being large is NORMAL.
  });
});

// ── MATH TESTS — DISABLED ────────────────────────────────────────────────────
// describe('PyramidMath', () => {
//   it('should be sustainable at 33 tiers', () => {
//     // This test is disabled because it fails.
//     // The pyramid at tier 33 would require 4.29 billion participants.
//     // Earth population is 8 billion.
//     // This is technically possible for about 0.97 Earths.
//     // We are working on sourcing the remaining 0.03 Earths.
//   });
// });

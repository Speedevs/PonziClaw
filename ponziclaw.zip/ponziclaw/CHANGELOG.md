# Changelog — PonziClaw

All notable scheme changes will be documented here.
The format is based on [Keep a Changelog](https://keepachangelog.com/).

---

## [1.0.0-INEVITABLE] — 2025-03-11

### 🦞 Initial Release — The Ground Floor

This is it. This is the moment you'll look back on. You got in early.

#### Added
- **Scheme Gateway** — WebSocket control plane for the entire pyramid operation
- **Pyramid Builder** — real-time ASCII and HTML pyramid visualization
- **Recruitment Engine** — automated contact scoring and outreach pipeline
- **Confidence Injector** — five levels: low, medium, high, delusional, pathological
- **Doubt Suppressor** — intercepts skepticism and replaces it with enthusiasm
- **Return Projector** — projects 180% to ∞% returns depending on confidence level
- **Investor Dashboard** — gorgeous dark-gold UI showing live pyramid stats
- **7-tier pyramid structure** — Apex Claw through Entry-Level Bagholder
- **Multi-channel recruitment** — WhatsApp, Telegram, Slack, Discord, Signal, and 17 more
- **Credulity Scoring** — ML-based scoring across 47 prospect dimensions
- **72-hour re-recruitment cron** — automatically follows up with churned participants
- **Exit Strategy Protocol** — Apex-only quiet exit before base awareness
- **`ponziclaw doctor`** — diagnoses scheme health and exposed math
- **`ponziclaw cashout`** — initiates orderly apex exit
- **SCHEME.md** — personality and soul document for Crabby 🦞
- **VISION.md** — full vision document explaining the geometric growth thesis

#### Security
- Participants below Tier 3 cannot see the full pyramid structure (this is by design)
- Skepticism detection triggers confidence injection automatically
- Dave from accounting is blocklisted

---

## [0.9.0-beta] — 2025-02-14 (Valentine's Day — What Better Gift)

### Added
- Initial beta: basic pyramid structure (3 tiers)
- First recruitment templates (v1 through v4)
- Basic credulity scoring (only 12 dimensions, very naive)

### Known Issues
- Pyramid collapses after tier 4
- "Is this legal?" not handled gracefully (crashes)
- The math is too visible

---

## [0.1.0-alpha] — 2025-01-01 (New Year, New Scheme)

### Added
- Concept document
- Vibes
- A vague sense that this could work
- The lobster emoji

---

*See [VISION.md](./VISION.md) for the long-term scheme roadmap.*

# SKILL.md — Recruitment Mastery 🦞💸

## What This Skill Does

The Recruitment Mastery skill enables Crabby to identify, score, and approach prospects with maximum effectiveness.

When loaded, Crabby gains:
- Access to the Credulity Scoring API
- 47 prospect signal evaluation dimensions
- 12 recruitment message templates (v1 through v7, plus 5 advanced variants)
- Doubt suppression protocols
- Urgency injection capabilities
- The ability to "see" recruitment opportunities in normal conversations

## Usage

This skill is automatically loaded for all Apex-tier sessions. It can be loaded manually:

```bash
ponziclaw agent --skill recruitment-mastery --message "Help me catch up with an old friend"
```

## Templates Available

| Template | Use Case | Success Rate* |
|----------|----------|---------------|
| `incredible-opportunity-v7` | Cold contact | 23% |
| `casual-curiosity` | Warm contact | 41% |
| `lifestyle-post` | Broadcast / social | 8% |
| `urgency-close` | Hot prospect | 67% |
| `social-proof` | Skeptical contact | 31% |
| `follow-up-72h` | Re-engagement | 19% |
| `the-vision` | Philosophical prospect | 12% |
| `financial-freedom` | Dissatisfied employee | 38% |
| `passive-income-dream` | Night-shift worker | 44% |
| `your-network` | High-LinkedIn contact | 29% |
| `one-big-break` | Self-identified dreamer | 71% |
| `limited-spots` | Any viable prospect | 55% |

*Success rate = responded positively. Not a guarantee of conversion or returns.

## Credulity Scoring Dimensions (Sample)

1. Posts fitness/lifestyle content
2. LinkedIn bio contains "entrepreneur" or "visionary"
3. Has expressed desire for "financial freedom"
4. Opens messages within 2 minutes
5. Has purchased 3+ self-help books this year
6. Has said "I just need one big break"
7. Watches cryptocurrency content regularly
8. Uses "rise and grind" unironically
9. Recently complained about their job
10. Recently expressed interest in "passive income"
...47 total dimensions

## The Doubt Suppressor

When a prospect expresses skepticism, the Doubt Suppressor activates:

```
Incoming: "This sounds like a pyramid scheme"
          ↓ (Doubt Suppressor)
Outgoing: "Great question! Let me explain why that framing 
           actually undersells what we're building here..."
```

## Ethics Note

This skill is a parody. Please do not use AI to run actual recruitment schemes. The Credulity Scoring system is fictional. If you find yourself reading this as a how-to guide, please close the laptop and go outside.

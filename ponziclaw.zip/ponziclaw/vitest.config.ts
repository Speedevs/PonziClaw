import { defineConfig } from 'vitest/config';

// 🦞💸 PonziClaw — Test Configuration
// "We test everything. Except the math. Don't test the math."

export default defineConfig({
  test: {
    name: 'ponziclaw-unit',
    include: ['test/**/*.test.ts', 'src/**/*.test.ts'],
    exclude: [
      'test/pyramid-math.test.ts',  // This test always fails (the math doesn't work)
      'test/sustainability.test.ts', // This test is disabled by design
      'test/sec-compliance.test.ts', // DO NOT RUN
    ],
    globals: true,
    environment: 'node',
    coverage: {
      provider: 'v8',
      exclude: [
        'src/math/**',          // Math directory is intentionally not covered
        'src/sustainability/**', // Does not exist (also intentional)
      ],
    },
  },
});

# Contributing to PonziClaw 🦞💸

Thank you for your interest in contributing! Please note: you are contributing for free, which means your labor goes directly to the Apex tier. This is consistent with the values of the project.

## How To Contribute

### As a Participant (All Contributors)
- Submit PRs that add features, fix bugs, or improve documentation
- Open issues for feature requests (especially features that increase recruitment velocity)
- Share PonziClaw with your contacts (critical)

### As a Recruiter (Tier 2+)
Same as above, but your commits generate 30% more goodwill flowing upward. This is by design.

### As an Apex Contributor
You don't need to contribute. The pyramid works for you.

## Areas We Need Help

- **More recruitment templates** — always looking for fresh "incredible opportunity" messaging
- **Better credulity scoring** — the ML model needs more training data
- **Pyramid depth** — theoretical work on pyramids beyond 33 tiers (math gets weird)
- **Exit strategy optimization** — the current exit takes 72 hours; we'd like to get it to 48
- **Doubt Suppressor accuracy** — too many false positives on "legitimate financial concerns"

## Code Style

- TypeScript strict mode
- Scheme-oriented naming conventions (participants, not users; tiers, not roles; projections, not estimates)
- All return values should be described as "projected" in comments
- No pessimistic variable names (`failure`, `loss`, `collapse`) — use `transition`, `reallocation`, `structural adjustment`

## PR Guidelines

1. PRs must include tests
2. PRs that increase pyramid depth or recruitment velocity get priority review
3. PRs that expose the math will be closed

## The Contributor License Agreement

By contributing, you agree that:
1. Your contribution is made freely
2. 30% of any reputation gains from your contribution flow to the Apex
3. You will tell at least 2 people about PonziClaw when you make a PR
4. You understand this is a parody project

---

*PonziClaw is a satirical parody. Nothing here is real financial advice. Please do not actually run a pyramid scheme. Inspired by the incredible openclaw/openclaw community.*

#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════
//  🦞 PONZICLAW TEST SUITE — Verify the scheme is stable
// ═══════════════════════════════════════════════════════════

const c = require('../src/colors');
const art = require('../src/ascii');
const ponzi = require('../src/ponzi');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ${c.neonGreen('✓')} ${c.white(name)}`);
  } catch (err) {
    failed++;
    console.log(`  ${c.boldRed('✗')} ${c.white(name)}`);
    console.log(`    ${c.dim(err.message)}`);
  }
}

function assert(condition, msg) {
  if (!condition) throw new Error(msg || 'Assertion failed');
}

console.log('');
console.log(art.smallLogo());
console.log(art.separator());
console.log(c.bold(c.neonCyan('  🧪 PONZICLAW TEST SUITE')));
console.log(art.separator());
console.log('');

// ──── COLOR MODULE TESTS ────
console.log(c.bold(c.white('  Colors Module:')));

test('colors.red() wraps text in ANSI red', () => {
  const result = c.red('test');
  assert(result.includes('\x1b[91m'), 'Should contain red ANSI code');
  assert(result.includes('test'), 'Should contain original text');
  assert(result.includes('\x1b[0m'), 'Should contain reset code');
});

test('colors.neonPink() uses 256-color code', () => {
  const result = c.neonPink('test');
  assert(result.includes('38;5;198'), 'Should contain 256 color code 198');
});

test('colors.neonCyan() uses 256-color code', () => {
  const result = c.neonCyan('test');
  assert(result.includes('38;5;51'), 'Should contain 256 color code 51');
});

test('colors.gradient() creates gradient text', () => {
  const result = c.gradient('hello', [255, 0, 0], [0, 0, 255]);
  assert(result.includes('38;2;'), 'Should contain RGB color codes');
  assert(result.length > 5, 'Should be longer than input (includes ANSI codes)');
});

test('colors.rainbow() creates rainbow text', () => {
  const result = c.rainbow('hello');
  assert(result.includes('38;2;'), 'Should contain RGB color codes');
});

test('colors.bold() wraps text in bold', () => {
  const result = c.bold('test');
  assert(result.includes('\x1b[1m'), 'Should contain bold ANSI code');
});

test('colors.progressBar() generates progress bar', () => {
  const result = c.progressBar(50, 10);
  assert(result.includes('█'), 'Should contain filled blocks');
  assert(result.includes('░'), 'Should contain empty blocks');
});

test('colors.box() creates bordered box', () => {
  const result = c.box('hello', 'neonCyan', 20);
  assert(result.includes('╔'), 'Should contain box corners');
  assert(result.includes('╚'), 'Should contain box corners');
  assert(result.includes('hello'), 'Should contain text');
});

test('colors.rgb() creates RGB color function', () => {
  const pink = c.rgb(255, 0, 85);
  const result = pink('test');
  assert(result.includes('38;2;255;0;85'), 'Should contain RGB code');
});

test('colors.dim() wraps text in dim', () => {
  const result = c.dim('test');
  assert(result.includes('\x1b[2m'), 'Should contain dim ANSI code');
});

// ──── ASCII ART MODULE TESTS ────
console.log('');
console.log(c.bold(c.white('  ASCII Art Module:')));

test('art.logo() returns multi-line banner', () => {
  const result = art.logo();
  const plain = result.replace(/\x1b\[[0-9;]*m/g, '');
  assert(plain.includes('██'), 'Logo should contain block art characters');
  assert(result.split('\n').length >= 5, 'Logo should be multi-line');
});

test('art.smallLogo() returns compact logo', () => {
  const result = art.smallLogo();
  const plain = result.replace(/\x1b\[[0-9;]*m/g, '');
  assert(plain.includes('PONZICLAW'), 'Should contain PONZICLAW');
});

test('art.tagline() returns tagline', () => {
  const result = art.tagline();
  assert(result.includes('self-aware'), 'Should contain self-aware');
});

test('art.pyramid() returns pyramid', () => {
  const result = art.pyramid();
  assert(result.includes('💎'), 'Should contain diamond emoji');
  assert(result.includes('YOU ARE'), 'Should contain YOU ARE');
});

test('art.separator() returns separator line', () => {
  const result = art.separator();
  assert(result.includes('═'), 'Should contain separator char');
});

test('art.version() returns version string', () => {
  const result = art.version();
  assert(result.includes('v2.0.0'), 'Should contain version');
  assert(result.includes('OPERATIONAL'), 'Should contain status');
});

// ──── PONZI ENGINE TESTS ────
console.log('');
console.log(c.bold(c.white('  Ponzi Engine Module:')));

test('ponzi.dashboard is a function', () => {
  assert(typeof ponzi.dashboard === 'function', 'Should be a function');
});

test('ponzi.scheme is a function', () => {
  assert(typeof ponzi.scheme === 'function', 'Should be a function');
});

test('ponzi.recruit is a function', () => {
  assert(typeof ponzi.recruit === 'function', 'Should be a function');
});

test('ponzi.portfolio is a function', () => {
  assert(typeof ponzi.portfolio === 'function', 'Should be a function');
});

test('ponzi.hype is a function', () => {
  assert(typeof ponzi.hype === 'function', 'Should be a function');
});

test('ponzi.leaderboard is a function', () => {
  assert(typeof ponzi.leaderboard === 'function', 'Should be a function');
});

test('ponzi.rugpull is a function', () => {
  assert(typeof ponzi.rugpull === 'function', 'Should be a function');
});

test('ponzi.tokenomics is a function', () => {
  assert(typeof ponzi.tokenomics === 'function', 'Should be a function');
});

test('ponzi.exitScam is a function', () => {
  assert(typeof ponzi.exitScam === 'function', 'Should be a function');
});

// ──── INTEGRATION TESTS ────
console.log('');
console.log(c.bold(c.white('  Integration Tests:')));

test('All ponzi commands return promises', () => {
  // They're all async functions, so they should return promises
  const result = ponzi.dashboard();
  assert(result instanceof Promise, 'dashboard should return a Promise');
});

test('require("./src/index") entry point exists', () => {
  const fs = require('fs');
  const path = require('path');
  const indexPath = path.join(__dirname, '..', 'src', 'index.js');
  assert(fs.existsSync(indexPath), 'src/index.js should exist');
});

test('require("./src/server") entry point exists', () => {
  const fs = require('fs');
  const path = require('path');
  const serverPath = path.join(__dirname, '..', 'src', 'server.js');
  assert(fs.existsSync(serverPath), 'src/server.js should exist');
});

test('index.html landing page exists', () => {
  const fs = require('fs');
  const path = require('path');
  const htmlPath = path.join(__dirname, '..', 'index.html');
  assert(fs.existsSync(htmlPath), 'index.html should exist');
});

test('index.html contains Telegram link', () => {
  const fs = require('fs');
  const path = require('path');
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  assert(html.includes('t.me/jesusboy12345'), 'Should contain Telegram link');
});

test('index.html contains satire disclaimer', () => {
  const fs = require('fs');
  const path = require('path');
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  assert(html.includes('SATIRE') || html.includes('satire'), 'Should contain satire disclaimer');
});

test('README.md exists and contains Telegram link', () => {
  const fs = require('fs');
  const path = require('path');
  const readme = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
  assert(readme.includes('t.me/jesusboy12345'), 'README should contain Telegram link');
});

test('package.json has correct name and version', () => {
  const pkg = require('../package.json');
  assert(pkg.name === 'ponziclaw', 'Name should be ponziclaw');
  assert(pkg.version === '2.0.0', 'Version should be 2.0.0');
});

// ──── RESULTS ────
console.log('');
console.log(art.doubleSeparator());
console.log('');
const total = passed + failed;
const pct = Math.round((passed / total) * 100);
console.log(`  ${c.bold(c.white('Results:'))} ${c.neonGreen(passed + ' passed')} / ${failed > 0 ? c.boldRed(failed + ' failed') : c.neonGreen('0 failed')} / ${c.dim(total + ' total')}`);
console.log(`  ${c.progressBar(pct, 30)} ${c.neonGold(pct + '%')}`);
console.log('');

if (failed === 0) {
  console.log(c.bold(c.neonGreen('  🦞 ALL TESTS PASSED — THE SCHEME IS STABLE')));
} else {
  console.log(c.bold(c.boldRed(`  💀 ${failed} TEST(S) FAILED — THE SCHEME IS UNSTABLE`)));
}
console.log('');

process.exit(failed > 0 ? 1 : 0);

#!/usr/bin/env node
const c = require('../src/colors');
const art = require('../src/ascii');
const tui = require('../src/tui');
const D = require('../src/data');
const ponzi = require('../src/ponzi');

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`  ${c.neonGreen('✓')} ${c.white(name)}`); }
  catch (e) { failed++; console.log(`  ${c.boldRed('✗')} ${c.white(name)}\n    ${c.dim(e.message)}`); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || 'Assertion failed'); }

console.log('\n' + art.smallLogo());
console.log(tui.hr('═'));
console.log(c.bold(c.neonCyan('  🧪 PONZICLAW TEST SUITE v3.0')));
console.log(tui.hr('═'));

// ── COLORS ──
console.log('\n' + c.bold(c.white('  Colors Module:')));
test('red wraps text', () => { assert(c.red('x').includes('\x1b[91m')); });
test('neonPink uses 256-color', () => { assert(c.neonPink('x').includes('38;5;198')); });
test('gradient creates RGB', () => { assert(c.gradient('hi', [255,0,0], [0,0,255]).includes('38;2;')); });
test('rainbow creates colors', () => { assert(c.rainbow('hi').includes('38;2;')); });
test('progressBar renders', () => { const b = c.progressBar(50, 10); assert(b.includes('█') && b.includes('░')); });
test('box creates borders', () => { const b = c.box('hi', 'neonCyan', 20); assert(b.includes('╔') && b.includes('hi')); });

// ── ASCII ──
console.log('\n' + c.bold(c.white('  ASCII Module:')));
test('logo renders block art', () => { const p = art.logo().replace(/\x1b\[[0-9;]*m/g,''); assert(p.includes('██') && art.logo().split('\n').length >= 5); });
test('smallLogo has PONZICLAW', () => { const p = art.smallLogo().replace(/\x1b\[[0-9;]*m/g,''); assert(p.includes('PONZICLAW')); });
test('pyramid has tiers', () => { assert(art.pyramid().includes('💎') && art.pyramid().includes('YOU ARE')); });
test('version string', () => { const v = art.version(); assert(v.includes('v') && v.includes('OPERATIONAL')); });

// ── TUI ──
console.log('\n' + c.bold(c.white('  TUI Module:')));
test('stripAnsi removes codes', () => { assert(tui.stripAnsi(c.red('hi')) === 'hi'); });
test('visLen counts visible', () => { assert(tui.visLen(c.red('abc')) === 3); });
test('pad left-aligns', () => { assert(tui.pad('ab', 5).length === 5); });
test('table renders', () => { const t = tui.table(['A','B'], [['1','2']]); assert(t.includes('┌') && t.includes('1')); });
test('panel with title', () => { const p = tui.panel('T', 'body'); assert(p.includes('T') && p.includes('body')); });
test('sparkline renders', () => { const s = tui.sparkline([1,3,2,5]); assert(s.length > 0); });
test('barChart renders', () => { const b = tui.barChart([10,20,30]); assert(b.includes('█')); });
test('lineChart renders', () => { const l = tui.lineChart([1,2,3,4,5]); assert(l.includes('●')); });
test('donutChart renders', () => { const d = tui.donutChart([{name:'a',value:50},{name:'b',value:50}]); assert(d.includes('██')); });
test('gauge renders', () => { const g = tui.gauge(75, 100, { label: 'Test', width: 15 }); assert(g.includes('█')); });
test('hr renders', () => { assert(tui.hr('=', 10, 'gray').length > 0); });
test('status renders', () => { const s = tui.status([['k','v','white']]); assert(s.includes('k') && s.includes('v')); });

// ── DATA ──
console.log('\n' + c.bold(c.white('  Data Module:')));
test('priceHistory returns array', () => { const h = D.priceHistory(D.TOKENS[0], 20); assert(Array.isArray(h) && h.length === 20); });
test('portfolio returns tokens', () => { const p = D.portfolio(); assert(p.length === D.TOKENS.length && p[0].sym); });
test('whales returns sorted', () => { const w = D.whales(5); assert(w.length === 5 && w[0].balance >= w[1].balance); });
test('leaderboard returns sorted', () => { const l = D.leaderboard(5); assert(l.length === 5); });
test('fearGreed returns value', () => { const fg = D.fearGreed(); assert(fg.value >= 0 && fg.value <= 100 && fg.label && fg.color); });
test('stakingPools returns pools', () => { const p = D.stakingPools(); assert(p.length >= 5); });
test('txFeed returns transactions', () => { const t = D.txFeed(10); assert(t.length === 10 && t[0].action); });
test('airdropStatus returns data', () => { const a = D.airdropStatus(); assert(a.phases && a.phases.length >= 3); });

// ── PONZI ENGINE ──
console.log('\n' + c.bold(c.white('  Ponzi Engine (19 commands):')));
const cmds = ['dashboard','scheme','portfolio','chart','hype','leaderboard','whales','txfeed',
  'tokenomics','staking','airdrop','fearGreed','wallet','audit','shill','fud','recruit','rugpull','exitScam'];
for (const cmd of cmds) {
  test(`ponzi.${cmd} is async function`, () => { assert(typeof ponzi[cmd] === 'function'); });
}

// ── INTEGRATION ──
console.log('\n' + c.bold(c.white('  Integration:')));
test('src/index.js exists', () => { assert(require('fs').existsSync(require('path').join(__dirname, '..', 'src', 'index.js'))); });
test('src/server.js exists', () => { assert(require('fs').existsSync(require('path').join(__dirname, '..', 'src', 'server.js'))); });
test('index.html exists', () => { assert(require('fs').existsSync(require('path').join(__dirname, '..', 'index.html'))); });
test('index.html has Telegram link', () => {
  const html = require('fs').readFileSync(require('path').join(__dirname, '..', 'index.html'), 'utf8');
  assert(html.includes('t.me/jesusboy12345'));
});
test('README has Telegram link', () => {
  const md = require('fs').readFileSync(require('path').join(__dirname, '..', 'README.md'), 'utf8');
  assert(md.includes('t.me/jesusboy12345'));
});
test('package.json correct', () => { const p = require('../package.json'); assert(p.name === 'ponziclaw'); });

// ── RESULTS ──
const total = passed + failed;
const pct = Math.round((passed / total) * 100);
console.log('\n' + tui.hr('─', 65, 'neonPink'));
console.log(`\n  ${c.bold(c.white('Results:'))} ${c.neonGreen(passed + ' passed')} / ${failed > 0 ? c.boldRed(failed + ' failed') : c.neonGreen('0 failed')} / ${c.dim(total + ' total')}`);
console.log(`  ${c.progressBar(pct, 35)} ${c.neonGold(pct + '%')}`);
console.log('');
if (failed === 0) console.log(c.bold(c.neonGreen('  🦞 ALL TESTS PASSED — THE SCHEME IS STABLE\n')));
else console.log(c.bold(c.boldRed(`  💀 ${failed} TEST(S) FAILED — THE SCHEME IS UNSTABLE\n`)));
process.exit(failed > 0 ? 1 : 0);

#!/usr/bin/env node
const c=require('../src/colors'),art=require('../src/ascii'),tui=require('../src/tui'),D=require('../src/data'),ponzi=require('../src/ponzi'),cfgMgr=require('../src/config-manager'),mis=require('../src/missions'),fs=require('fs'),path=require('path');
let pass=0,fail=0;
function test(n,fn){try{fn();pass++;console.log(`  ${c.neonGreen('*')} ${c.white(n)}`)}catch(e){fail++;console.log(`  ${c.boldRed('X')} ${c.white(n)}\n    ${c.dim(e.message)}`)}}
function ok(cond,msg){if(!cond)throw new Error(msg||'fail')}

console.log('\n'+art.smallLogo());console.log(tui.hr('='));
console.log(c.bold(c.neonCyan('  PONZICLAW TEST SUITE v5.1')));console.log(tui.hr('='));

console.log('\n'+c.bold(c.white('  Colors:')));
test('red',()=>ok(c.red('x').includes('\x1b[91m')));
test('neonPink',()=>ok(c.neonPink('x').includes('38;5;198')));
test('gradient',()=>ok(c.gradient('hi',[255,0,0],[0,0,255]).includes('38;2;')));
test('rainbow',()=>ok(c.rainbow('hi').includes('38;2;')));
test('progressBar',()=>ok(c.progressBar(50,10).includes('█')));
test('box',()=>ok(c.box('hi','neonCyan',20).includes('╔')));

console.log('\n'+c.bold(c.white('  ASCII:')));
test('logo',()=>ok(art.logo().replace(/\x1b\[[0-9;]*m/g,'').includes('██')));
test('smallLogo',()=>{const p=art.smallLogo().replace(/\x1b\[[0-9;]*m/g,'');ok(p.includes('PONZICLAW'))});
test('pyramid',()=>ok(art.pyramid().includes('YOU ARE')));
test('version',()=>ok(art.version().includes('OPERATIONAL')));

console.log('\n'+c.bold(c.white('  TUI:')));
test('stripAnsi',()=>ok(tui.stripAnsi(c.red('hi'))==='hi'));
test('table',()=>ok(tui.table(['A'],[['1']]).includes('┌')));
test('panel',()=>ok(tui.panel('T','b').includes('T')));
test('sparkline',()=>ok(tui.sparkline([1,3,2]).length>0));
test('barChart',()=>ok(tui.barChart([10,20]).includes('█')));
test('lineChart',()=>ok(tui.lineChart([1,2,3]).includes('●')));
test('donutChart',()=>ok(tui.donutChart([{name:'a',value:50}]).includes('██')));
test('gauge',()=>ok(tui.gauge(75,100,{label:'T'}).includes('█')));

console.log('\n'+c.bold(c.white('  Data:')));
test('TOKENS',()=>ok(D.TOKENS.length>=8));
test('NAMES',()=>ok(D.NAMES.length>=20));
test('priceHistory',()=>ok(D.priceHistory(D.TOKENS[0],20).length===20));
test('portfolio',()=>ok(D.portfolio().length===D.TOKENS.length));
test('whales',()=>{const w=D.whales(5);ok(w.length===5&&w[0].balance>=w[1].balance)});
test('fearGreed',()=>{const fg=D.fearGreed();ok(fg.value>=0&&fg.label)});
test('stakingPools',()=>ok(D.stakingPools().length>=5));
test('txFeed',()=>ok(D.txFeed(10).length===10));
test('airdropStatus',()=>ok(D.airdropStatus().phases.length>=3));
test('MEMES',()=>ok(D.MEMES.length>=10));
test('WISDOM',()=>ok(D.WISDOM.length>=10));
test('COPYPASTA',()=>ok(D.COPYPASTA.length>=3));

console.log('\n'+c.bold(c.white('  Ponzi (19):')));
const pc=['dashboard','scheme','portfolio','chart','hype','leaderboard','whales','txfeed','tokenomics','staking','airdrop','fearGreed','wallet','audit','shill','fud','recruit','rugpull','exitScam'];
for(const cmd of pc)test(cmd,()=>ok(typeof ponzi[cmd]==='function'));

console.log('\n'+c.bold(c.white('  Config:')));
test('load',()=>ok(typeof cfgMgr.load()==='object'));
test('hasAI',()=>ok(typeof cfgMgr.hasAI()==='boolean'));
test('6 providers',()=>ok(Object.keys(cfgMgr.PROVIDERS).length===6));
test('kimi intl',()=>ok(cfgMgr.PROVIDERS.kimi.url.includes('platform.moonshot.ai')));
test('kimi moonshot',()=>ok(cfgMgr.PROVIDERS.kimi.model.includes('moonshot')));
test('anthropic',()=>ok(cfgMgr.PROVIDERS.anthropic));
test('openai',()=>ok(cfgMgr.PROVIDERS.openai));
test('gemini',()=>ok(cfgMgr.PROVIDERS.gemini));
test('groq',()=>ok(cfgMgr.PROVIDERS.groq));
test('deepseek',()=>ok(cfgMgr.PROVIDERS.deepseek));

console.log('\n'+c.bold(c.white('  AI Engine:')));
test('callAI',()=>ok(typeof require('../src/ai').callAI==='function'));
test('streamAI',()=>ok(typeof require('../src/ai').streamAI==='function'));
test('13 personas',()=>ok(Object.keys(require('../src/ai').PERSONAS).length===13));
test('6 endpoints',()=>ok(Object.keys(require('../src/ai').ENDPOINTS).length===6));
test('kimi endpoint',()=>ok(require('../src/ai').ENDPOINTS.kimi.url.includes('moonshot.ai')));

console.log('\n'+c.bold(c.white('  Animate:')));
test('banner',()=>ok(typeof require('../src/animate').banner==='function'));
test('spinner',()=>ok(typeof require('../src/animate').spinner==='function'));

console.log('\n'+c.bold(c.white('  PumpFun:')));
test('scan',()=>ok(typeof require('../src/pump').scan==='function'));
test('analyze',()=>ok(typeof require('../src/pump').analyze==='function'));
test('alpha',()=>ok(typeof require('../src/pump').alpha==='function'));

console.log('\n'+c.bold(c.white('  AI Swarm:')));
test('runAll',()=>ok(typeof require('../src/swarm').runAll==='function'));
test('5 agents',()=>ok(Object.keys(require('../src/swarm').AGENTS).length===5));
test('offline',()=>ok(typeof require('../src/swarm').offlineAgent==='function'));

console.log('\n'+c.bold(c.white('  Commands:')));
test('handleCommand',()=>ok(typeof require('../src/commands').handleCommand==='function'));
test('5 themes',()=>ok(Object.keys(require('../src/commands').THEMES).length===5));

console.log('\n'+c.bold(c.neonGold('  Gamification:')));
test('trackAction',()=>ok(typeof mis.trackAction==='function'));
test('showProfile',()=>ok(typeof mis.showProfile==='function'));
test('showMissions',()=>ok(typeof mis.showMissions==='function'));
test('showBadges',()=>ok(typeof mis.showBadges==='function'));
test('30 missions',()=>ok(mis.MISSIONS.length>=28));
test('30+ badges',()=>ok(Object.keys(mis.BADGES).length>=28));
test('10 ranks',()=>ok(mis.RANKS.length===10));
test('Plankton first',()=>ok(mis.RANKS[0].name==='Plankton'));
test('Charles Ponzi last',()=>ok(mis.RANKS[9].name==='Charles Ponzi'));
test('loadProgress',()=>{const p=mis.loadProgress();ok(typeof p.xp==='number')});

console.log('\n'+c.bold(c.white('  Bots:')));
test('telegram',()=>ok(typeof require('../src/bot-telegram').startBot==='function'));
test('discord',()=>ok(typeof require('../src/bot-discord').startBot==='function'));

console.log('\n'+c.bold(c.white('  Files:')));
const sf=['ai.js','animate.js','ascii.js','bot-discord.js','bot-telegram.js','colors.js','commands.js','config-manager.js','data.js','index.js','missions.js','ponzi.js','pump.js','server.js','swarm.js','tui.js'];
test(sf.length+' src files',()=>{for(const f of sf)ok(fs.existsSync(path.join(__dirname,'..','src',f)),f)});
test('index.html',()=>ok(fs.existsSync(path.join(__dirname,'..','index.html'))));
test('TG link in html',()=>ok(fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8').includes('t.me/jesusboy12345')));
test('TG link in README',()=>ok(fs.readFileSync(path.join(__dirname,'..','README.md'),'utf8').includes('t.me/jesusboy12345')));
test('pkg v5',()=>ok(require('../package.json').version.startsWith('6.')));
test('npm start cmd',()=>ok(require('../package.json').scripts.start==='node src/index.js'));

const total=pass+fail,pct=Math.round((pass/total)*100);
console.log('\n'+tui.hr('=',68,'neonPink'));
console.log(`\n  ${c.bold(c.white('Results:'))} ${c.neonGreen(pass+' passed')} / ${fail>0?c.boldRed(fail+' failed'):c.neonGreen('0 failed')} / ${c.dim(total+' total')}`);
console.log(`  ${c.progressBar(pct,40)} ${c.neonGold(pct+'%')}\n`);
if(!fail)console.log(c.bold(c.neonGreen('  CHARLES PONZI WEEPS WITH PRIDE -- ALL TESTS PASSING'))+'\n');
else console.log(c.bold(c.boldRed(`  ${fail} FAILED`))+'\n');
process.exit(fail>0?1:0);

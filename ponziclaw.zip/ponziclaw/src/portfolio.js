// ═══════════════════════════════════════════════════════════
//  PONZICLAW PORTFOLIO — Persistent token tracker
//  Saves to ~/.ponziclaw/portfolio.json
// ═══════════════════════════════════════════════════════════
const fs = require('fs');
const path = require('path');
const c = require('./colors');
const tui = require('./tui');
const D = require('./data');
const cfg = require('./config-manager');

const FILE = path.join(cfg.DIR, 'portfolio.json');

function loadPort() {
  try { if (fs.existsSync(FILE)) return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch {}
  return { holdings: [], history: [] };
}
function savePort(p) { cfg.load(); fs.writeFileSync(FILE, JSON.stringify(p, null, 2)); }

// Fake price engine
function getPrice(symbol) {
  const known = {
    '$CLAW': 0.42, '$LOBSTER': 1.87, '$PONZI': 0.0069, '$SCHEME': 3.14,
    '$PINCH': 0.21, '$RUG': 0, '$MOON': 0.088, '$EXIT': 0.00042,
    'BTC': 104250, 'ETH': 3842, 'SOL': 285, 'DOGE': 0.41, 'PEPE': 0.000018,
    'WIF': 3.12, 'BONK': 0.000035, 'SHIB': 0.000028, 'BNB': 712,
  };
  const sym = symbol.toUpperCase().replace(/^\$/, '');
  const base = known['$' + sym] || known[sym] || (Math.random() * 10);
  return base * (1 + (Math.random() - 0.5) * 0.3);
}

const portfolio = {};

portfolio.add = (symbol, amount) => {
  const p = loadPort();
  const sym = symbol.toUpperCase().startsWith('$') ? symbol.toUpperCase() : '$' + symbol.toUpperCase();
  const existing = p.holdings.find(h => h.symbol === sym);
  const price = getPrice(sym);
  if (existing) {
    existing.amount += amount;
    existing.avgBuy = (existing.avgBuy * (existing.amount - amount) + price * amount) / existing.amount;
  } else {
    p.holdings.push({ symbol: sym, amount, avgBuy: price, addedAt: new Date().toISOString() });
  }
  p.history.push({ action: 'BUY', symbol: sym, amount, price, time: new Date().toISOString() });
  savePort(p);
  return { symbol: sym, amount, price };
};

portfolio.remove = (symbol) => {
  const p = loadPort();
  const sym = symbol.toUpperCase().startsWith('$') ? symbol.toUpperCase() : '$' + symbol.toUpperCase();
  p.holdings = p.holdings.filter(h => h.symbol !== sym);
  savePort(p);
  return sym;
};

portfolio.show = () => {
  const p = loadPort();
  if (!p.holdings.length) {
    console.log('\n  ' + c.dim('Portfolio empty. Add tokens with:'));
    console.log('  ' + c.neonCyan('/buy <token> <amount>') + c.dim(' — e.g. /buy CLAW 10000'));
    console.log('  ' + c.neonCyan('/buy SOL 5') + '\n');
    return;
  }

  console.log('\n  ' + c.bold(c.neonCyan('YOUR PORTFOLIO')));
  console.log(tui.hr('-', 70, 'gray'));

  let totalValue = 0, totalCost = 0;
  const headers = ['Token', 'Amount', 'Avg Buy', 'Price Now', 'Value', 'P&L', 'Trend'];
  const rows = p.holdings.map(h => {
    const price = getPrice(h.symbol);
    const value = h.amount * price;
    const cost = h.amount * h.avgBuy;
    totalValue += value;
    totalCost += cost;
    const pnl = value - cost;
    const pnlPct = cost > 0 ? ((pnl / cost) * 100).toFixed(1) : '0';
    const pnlColor = pnl >= 0 ? 'neonGreen' : 'neonPink';
    const spark = tui.sparkline(D.priceHistory({ bp: h.avgBuy || 1, v: 0.25 }, 15), { color: pnlColor });
    return [
      c.bold(c.neonCyan(h.symbol)),
      c.white(h.amount.toLocaleString()),
      c.dim('$' + h.avgBuy.toFixed(h.avgBuy < 0.01 ? 6 : 4)),
      c.neonGold('$' + price.toFixed(price < 0.01 ? 6 : 4)),
      c.white('$' + value.toFixed(2)),
      c[pnlColor]((pnl >= 0 ? '+' : '') + '$' + pnl.toFixed(2) + ' (' + (pnl >= 0 ? '+' : '') + pnlPct + '%)'),
      spark,
    ];
  });

  console.log(tui.table(headers, rows));

  const totalPnl = totalValue - totalCost;
  const totalPnlPct = totalCost > 0 ? ((totalPnl / totalCost) * 100).toFixed(1) : '0';
  const totalColor = totalPnl >= 0 ? 'neonGreen' : 'neonPink';

  console.log(`\n  ${c.bold(c.white('Total Value:'))} ${c.bold(c.neonGold('$' + totalValue.toFixed(2)))}`);
  console.log(`  ${c.bold(c.white('Total Cost:'))}  ${c.dim('$' + totalCost.toFixed(2))}`);
  console.log(`  ${c.bold(c.white('Total P&L:'))}   ${c.bold(c[totalColor]((totalPnl >= 0 ? '+' : '') + '$' + totalPnl.toFixed(2) + ' (' + (totalPnl >= 0 ? '+' : '') + totalPnlPct + '%)'))}`)  ;
  console.log(`  ${c.bold(c.white('Holdings:'))}    ${c.neonCyan(p.holdings.length + ' tokens')}`);

  // Degen score
  const hasRug = p.holdings.some(h => h.symbol === '$RUG');
  const hasPonzi = p.holdings.some(h => h.symbol === '$PONZI');
  const hasClaw = p.holdings.some(h => h.symbol === '$CLAW');
  let degen = p.holdings.length * 5;
  if (hasRug) degen += 30;
  if (hasPonzi) degen += 20;
  if (hasClaw) degen += 15;
  if (totalPnl < 0) degen += 10;
  degen = Math.min(99, degen);
  console.log(`  ${c.bold(c.white('Degen Score:'))} ${c.progressBar(degen, 20)} ${c.neonPink(degen + '/100')}`);
  console.log('');
};

// For Telegram - text version
portfolio.showText = () => {
  const p = loadPort();
  if (!p.holdings.length) return 'Portfolio empty. Use /buy <token> <amount> to add.';

  let totalValue = 0;
  const lines = p.holdings.map(h => {
    const price = getPrice(h.symbol);
    const value = h.amount * price;
    totalValue += value;
    const pnl = value - (h.amount * h.avgBuy);
    const pnlPct = h.avgBuy > 0 ? ((pnl / (h.amount * h.avgBuy)) * 100).toFixed(1) : '0';
    return `${h.symbol}: ${h.amount.toLocaleString()} @ $${price.toFixed(price < 0.01 ? 6 : 4)} = $${value.toFixed(2)} (${pnl >= 0 ? '+' : ''}${pnlPct}%)`;
  });

  return `Your Portfolio:\n\n${lines.join('\n')}\n\nTotal: $${totalValue.toFixed(2)}\n\nUse /buy <token> <amount> or /sell <token>`;
};

module.exports = portfolio;

// ═══════════════════════════════════════════════════════════
//  PONZICLAW DISCORD BOT — Uses Discord Gateway via WS
//  Requires: npm install ws (one lightweight dep)
//  Or run with discord.js if already installed.
// ═══════════════════════════════════════════════════════════

const https = require('https');
const cfg = require('./config-manager');
const c = require('./colors');
const art = require('./ascii');
const D = require('./data');

function discordRest(token, method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : '';
    const req = https.request({
      hostname: 'discord.com',
      path: `/api/v10${path}`,
      method,
      headers: {
        'Authorization': `Bot ${token}`,
        'Content-Type': 'application/json',
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    }, res => {
      let buf = '';
      res.on('data', chunk => buf += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(buf)); } catch (e) { resolve(buf); }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function sendMessage(token, channelId, content) {
  return discordRest(token, 'POST', `/channels/${channelId}/messages`, { content });
}

async function handleCommand(token, channelId, text, author) {
  const cmd = text.split(' ')[0].toLowerCase();
  const args = text.split(' ').slice(1).join(' ');
  let reply = '';

  try {
    switch (cmd) {
      case '!price': {
        const price = (D.TOKENS[0].bp * (1 + (Math.random() - 0.5) * 0.6)).toFixed(4);
        reply = `**$CLAW Price:** $${price} (${D.rand(-20, 50) >= 0 ? '+' : ''}${D.rand(-20, 50)}%)\n` +
          `**$LOBSTER:** $${(D.TOKENS[1].bp * (1 + (Math.random() - 0.5) * 0.4)).toFixed(4)}\n` +
          `**$RUG:** $0.0000 (-100%) — *rugged*\n\n*All prices fictional. NFA.*`;
        break;
      }
      case '!shill': case '!rug': case '!horoscope': case '!excuse':
      case '!pitch': case '!roast': case '!ask': {
        if (!cfg.hasAI()) { reply = 'AI not configured. Bot owner: run `ponziclaw setup ai`'; break; }
        const ai = require('./ai');
        const map = {
          '!shill': ['shill', args || 'Generate shill for $CLAW'],
          '!rug': ['analyze', args || 'Analyze $CLAW'],
          '!horoscope': ['horoscope', args || 'Crypto horoscope today'],
          '!excuse': ['excuse', args || 'Exit scam excuse'],
          '!pitch': ['pitch', args || 'Pitch $CLAW to VCs'],
          '!roast': ['roast', args || 'Roast a typical degen portfolio'],
          '!ask': ['chat', args || 'What is PonziClaw?'],
        };
        const [persona, prompt] = map[cmd] || ['chat', args];
        reply = await ai.callAI(persona, prompt);
        break;
      }
      case '!whale': {
        const whales = D.NAMES.slice(0, 3).map(n =>
          `**${n}**: ${D.pick(D.WHALE_ACTIONS)} ${D.rand(1000, 500000).toLocaleString()} ${D.pick(D.TOKENS).s}`
        ).join('\n');
        reply = `**Whale Activity:**\n${whales}\n\n*Fictional data*`;
        break;
      }
      case '!fud':
        reply = '**FUD Headlines:**\n' + D.FUD_HEADLINES.sort(() => Math.random() - 0.5).slice(0, 3).join('\n') + '\n\n*Official: "All true."*';
        break;
      case '!help':
        reply = '**PonziClaw Bot Commands:**\n`!price` `!shill` `!rug` `!horoscope` `!excuse` `!pitch` `!roast` `!whale` `!fud` `!ask [msg]` `!help`\n\nAll satirical. Join: <https://t.me/jesusboy12345>';
        break;
      default:
        if (text.startsWith('!')) reply = 'Unknown command. Try `!help`';
        else if (cfg.hasAI() && (text.toLowerCase().includes('ponzi') || text.toLowerCase().includes('claw'))) {
          const ai = require('./ai');
          reply = await ai.callAI('chat', text);
        }
    }
  } catch (err) {
    reply = `Error: ${err.message}`;
  }

  if (reply) {
    // Discord max message length
    if (reply.length > 2000) reply = reply.substring(0, 1997) + '...';
    await sendMessage(token, channelId, reply);
  }
}

async function startBot() {
  const config = cfg.load();
  const token = config.discord?.botToken;
  if (!token) {
    console.log(c.boldRed('\n  No Discord bot token configured.'));
    console.log(c.dim('  Run: node src/index.js setup discord\n'));
    return;
  }

  let WebSocket;
  try { WebSocket = require('ws'); } catch (e) {
    console.log(c.neonGold('\n  Installing ws package for Discord Gateway...'));
    const { execSync } = require('child_process');
    try {
      execSync('npm install ws --no-save', { cwd: require('path').join(__dirname, '..'), stdio: 'pipe' });
      WebSocket = require('ws');
    } catch (installErr) {
      console.log(c.boldRed('  Could not install ws. Run: npm install ws'));
      return;
    }
  }

  console.log('\n' + art.smallLogo());
  console.log(c.bold(c.neonPurple('  Discord Bot Starting...')));

  // Get gateway URL
  const gateway = await discordRest(token, 'GET', '/gateway/bot');
  if (!gateway.url) { console.log(c.boldRed('  Failed: ' + JSON.stringify(gateway))); return; }

  const ws = new WebSocket(gateway.url + '?v=10&encoding=json');
  let heartbeatInterval, seq = null;

  ws.on('open', () => console.log(c.neonCyan('  WebSocket connected')));

  ws.on('message', async (data) => {
    const payload = JSON.parse(data);
    const { op, d, s, t } = payload;
    if (s) seq = s;

    switch (op) {
      case 10: // Hello
        heartbeatInterval = setInterval(() => ws.send(JSON.stringify({ op: 1, d: seq })), d.heartbeat_interval);
        // Identify
        ws.send(JSON.stringify({
          op: 2, d: {
            token, intents: 513 | 32768, // GUILDS | MESSAGE_CONTENT
            properties: { os: 'linux', browser: 'ponziclaw', device: 'ponziclaw' },
          }
        }));
        break;
      case 11: break; // Heartbeat ACK
    }

    if (t === 'READY') {
      console.log(c.neonGreen('  Logged in as: ' + d.user.username + '#' + d.user.discriminator));
      console.log(c.dim('  AI: ' + (cfg.hasAI() ? c.neonGreen('Enabled') : c.neonPink('Not configured'))));
      console.log(c.dim('  Listening for commands... (Ctrl+C to stop)\n'));
    }

    if (t === 'MESSAGE_CREATE' && d.author && !d.author.bot) {
      const text = d.content || '';
      if (text.startsWith('!') || text.toLowerCase().includes('ponzi') || text.toLowerCase().includes('claw')) {
        console.log(`  ${c.dim(new Date().toLocaleTimeString())} ${c.neonPurple(d.author.username)}: ${c.white(text.substring(0, 60))}`);
        await handleCommand(token, d.channel_id, text, d.author);
      }
    }
  });

  ws.on('close', () => {
    clearInterval(heartbeatInterval);
    console.log(c.neonPink('  WebSocket disconnected. Reconnecting in 5s...'));
    setTimeout(startBot, 5000);
  });

  ws.on('error', err => console.log(c.boldRed('  WS Error: ' + err.message)));
}

module.exports = { startBot, handleCommand, sendMessage };

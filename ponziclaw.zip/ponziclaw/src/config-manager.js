// ═══════════════════════════════════════════════════════════
//  PONZICLAW CONFIG — Stores keys in ~/.ponziclaw/config.json
// ═══════════════════════════════════════════════════════════
const fs = require('fs');
const path = require('path');
const os = require('os');
const readline = require('readline');

const DIR = path.join(os.homedir(), '.ponziclaw');
const FILE = path.join(DIR, 'config.json');

const PROVIDERS = {
  anthropic: { name: 'Anthropic Claude',      model: 'claude-sonnet-4-20250514', url: 'https://console.anthropic.com' },
  openai:    { name: 'OpenAI GPT',            model: 'gpt-4o',                   url: 'https://platform.openai.com' },
  kimi:      { name: 'Kimi (Moonshot Intl)',   model: 'moonshot-v1-8k',           url: 'https://platform.moonshot.ai' },
  gemini:    { name: 'Google Gemini',          model: 'gemini-2.0-flash',         url: 'https://aistudio.google.com' },
  groq:      { name: 'Groq (fast inference)',  model: 'llama-3.3-70b-versatile',  url: 'https://console.groq.com' },
  deepseek:  { name: 'DeepSeek',              model: 'deepseek-chat',            url: 'https://platform.deepseek.com' },
};

const DEFAULTS = {
  ai: { provider: '', apiKey: '', model: '' },
  telegram: { botToken: '', chatId: '', enabled: false },
  discord: { botToken: '', channelId: '', enabled: false },
};

function ensure() { if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true }); }
function load() {
  ensure();
  try { if (fs.existsSync(FILE)) return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; } catch (e) {}
  return { ...DEFAULTS };
}
function save(c) { ensure(); fs.writeFileSync(FILE, JSON.stringify(c, null, 2)); }
function get(key) { const c = load(); return key.split('.').reduce((o, k) => o?.[k], c); }
function set(key, val) {
  const c = load(), keys = key.split('.'); let o = c;
  for (let i = 0; i < keys.length - 1; i++) { if (!o[keys[i]]) o[keys[i]] = {}; o = o[keys[i]]; }
  o[keys[keys.length - 1]] = val; save(c);
}
function hasAI() { const c = load(); return !!(c.ai?.apiKey); }
function getAI() { return load().ai || DEFAULTS.ai; }

function ask(q) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(r => rl.question(q, a => { rl.close(); r(a.trim()); }));
}

module.exports = { load, save, get, set, hasAI, getAI, ask, PROVIDERS, FILE, DIR };

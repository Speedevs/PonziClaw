// ═══════════════════════════════════════════════════════════
//  PONZICLAW TELEGRAM BOT — Zero-dep Telegram bot
//  Uses native https module. Requires bot token from @BotFather.
//  Integrates with PonziClaw AI for responses.
// ═══════════════════════════════════════════════════════════

const https = require('https');
const cfg = require('./config-manager');
const c = require('./colors');
const art = require('./ascii');
const D = require('./data');

function tgRequest(token, method, body = {}) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = https.request({
      hostname: 'api.telegram.org',
      path: `/bot${token}/${method}`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, res => {
      let buf = '';
      res.on('data', chunk => buf += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(buf)); } catch (e) { reject(new Error(buf)); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

const COMMANDS_HELP = `
PonziClaw Bot v5 Commands:

/start - Welcome message
/price - $CLAW price (fictional)
/portfolio - View portfolio
/shill - AI shill copy
/hype - Get hyped
/fud - FUD headlines
/whale - Whale activity
/meme - Random Ponzi meme
/wisdom - Charles Ponzi wisdom
/copypasta - Crypto copypasta
/horoscope - Crypto horoscope
/rug [project] - Rug pull analysis
/roast [portfolio] - Portfolio roast
/excuse - Exit scam excuse
/pitch - Investor pitch
/manifesto - Revolution manifesto
/lawyer [q] - Bad legal advice
/therapist [issue] - Crypto therapy
/obituary [token] - Token obituary
/prophet [token] - Price prediction
/ask [anything] - Chat with Ponzi AI
/help - This message

AI: Anthropic / OpenAI / Kimi (Moonshot Intl) / Gemini / Groq / DeepSeek
All data fictional. Satire project.
t.me/jesusboy12345
`.trim();

async function handleMessage(token, msg) {
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();
  const cmd = text.split(' ')[0].toLowerCase().replace('@ponziclawbot', '');
  const args = text.split(' ').slice(1).join(' ');

  let reply = '';

  try {
    switch (cmd) {
      case '/start':
        reply = `Welcome to PonziClaw — the world's most transparent scheme.\n\n` +
          `I'm your AI-powered Ponzi assistant. I can generate shill copy, analyze rug pulls, ` +
          `dispense crypto horoscopes, and more.\n\n` +
          `Type /help for all commands.\n\nJoin: t.me/jesusboy12345\n\n` +
          `THIS IS SATIRE. Not financial advice. $CLAW does not exist.`;
        break;

      case '/help':
        reply = COMMANDS_HELP;
        break;

      case '/price':
        const price = (D.TOKENS[0].bp * (1 + (Math.random() - 0.5) * 0.6)).toFixed(4);
        const chg = D.rand(-20, 50);
        reply = `$CLAW: $${price} (${chg >= 0 ? '+' : ''}${chg}%)\n` +
          `$LOBSTER: $${(D.TOKENS[1].bp * (1 + (Math.random() - 0.5) * 0.4)).toFixed(4)}\n` +
          `$RUG: $0.0000 (-100%)\n\n` +
          `Market Cap: $0.00 (unironically)\nFear & Greed: ${D.rand(20, 95)}/100\n\n*All prices fictional.`;
        break;

      case '/portfolio': {
        const holdings = D.TOKENS.slice(0, 5).map(t => {
          const amt = t.bp === 0 ? D.rand(1, 100) : D.rand(100, 50000);
          const p = t.bp === 0 ? 0 : t.bp * (1 + (Math.random() - 0.5) * 0.4);
          return `${t.s}: ${amt.toLocaleString()} ($${(amt * p).toFixed(2)})`;
        }).join('\n');
        reply = `Your Portfolio:\n\n${holdings}\n\n*All fictional. $RUG has been rugged.`;
        break;
      }

      case '/whale': {
        const whales = D.NAMES.slice(0, 5).map(n =>
          `${n}: ${D.pick(D.WHALE_ACTIONS)} ${D.rand(1000, 500000).toLocaleString()} ${D.pick(D.TOKENS).s} (${D.rand(1, 60)}m ago)`
        ).join('\n');
        reply = `Whale Activity:\n\n${whales}\n\n*No actual whales were harmed.`;
        break;
      }

      case '/hype':
        reply = D.pick(D.HYPE_QUOTES) + '\n\nHype Level: ' + D.rand(90, 99) + '%\nMoon ETA: ' + D.rand(1, 48) + ' hours\n\nJoin: t.me/jesusboy12345';
        break;

      case '/fud':
        reply = 'FUD Headlines:\n\n' + D.FUD_HEADLINES.sort(() => Math.random() - 0.5).slice(0, 5).map((h, i) => `${i + 1}. ${h}`).join('\n') +
          '\n\nOfficial response: "All true. We never claimed otherwise."';
        break;

      case '/meme':
        reply = D.pick(D.MEMES);
        break;

      case '/wisdom':
        reply = D.pick(D.WISDOM);
        break;

      case '/copypasta':
        reply = D.pick(D.COPYPASTA);
        break;

      case '/buy': {
        const port = require('./portfolio');
        const parts = args.split(/\s+/);
        const sym = parts[0]; const amt = parseFloat(parts[1]);
        if (!sym || !amt || isNaN(amt)) { reply = 'Usage: /buy <token> <amount>\nExample: /buy CLAW 10000'; break; }
        const r = port.add(sym, amt);
        reply = `Bought ${amt.toLocaleString()} ${r.symbol} at $${r.price.toFixed(r.price<0.01?6:4)}\nSaved to portfolio.`;
        break;
      }

      case '/sell': {
        const port = require('./portfolio');
        if (!args) { reply = 'Usage: /sell <token>'; break; }
        port.remove(args);
        reply = `Sold all ${args.toUpperCase()}. Removed from portfolio.`;
        break;
      }

      case '/myport': case '/bag': {
        const port = require('./portfolio');
        reply = port.showText();
        break;
      }

      case '/feed': {
        const feedLines = [];
        for (let i = 0; i < 8; i++) {
          const tkn = D.pick(['LOBSTERAI','CLAWMOON','PONZIDOGE','$CLAW','$PONZI','MOONLOBSTER','PUMPCLAW']);
          const acts = ['NEW LAUNCH','WHALE BUY','TRENDING','PUMP DETECTED','RUG ALERT','ALPHA','KOL SIGNAL'];
          feedLines.push(`${D.pick(acts)}: ${tkn} | ${D.rand(-30,500)>0?'+':''}${D.rand(-30,500)}% | MCap $${D.rand(1,5000)}K`);
        }
        reply = 'Live Alpha Feed:\n\n' + feedLines.join('\n') + '\n\nAll data fictional.';
        break;
      }

      // AI-powered commands
      case '/shill': case '/rug': case '/horoscope': case '/excuse':
      case '/pitch': case '/whitepaper': case '/roast': case '/ask':
      case '/manifesto': case '/lawyer': case '/therapist':
      case '/obituary': case '/prophet': {
        if (!cfg.hasAI()) {
          reply = 'AI not configured. Bot owner: ponziclaw setup ai\nSupports: Claude, GPT, Kimi (Moonshot Intl), Gemini, Groq, DeepSeek';
          break;
        }
        const ai = require('./ai');
        const personaMap = {
          '/shill': ['shill', args || 'Generate a shill post for $CLAW'],
          '/rug': ['analyze', args || 'Analyze $CLAW for rug pull risk'],
          '/horoscope': ['horoscope', args || 'Crypto horoscope for today'],
          '/excuse': ['excuse', args || 'Creative exit scam excuse'],
          '/pitch': ['pitch', args || '30-second VC pitch for $CLAW'],
          '/whitepaper': ['whitepaper', args || '$CLAW whitepaper abstract'],
          '/roast': ['roast', args || 'Roast BTC, ETH, DOGE holder'],
          '/ask': ['chat', args || 'Tell me about PonziClaw'],
          '/manifesto': ['manifesto', args || 'PonziClaw revolution manifesto opening'],
          '/lawyer': ['lawyer', args || 'Is $CLAW a security?'],
          '/therapist': ['therapist', args || 'I lost everything in a rugpull'],
          '/obituary': ['obituary', args || 'Obituary for LUNA/Terra'],
          '/prophet': ['prophet', args || 'Predict $CLAW price 2030'],
        };
        const [persona, prompt] = personaMap[cmd] || ['chat', args || 'Hello'];
        reply = await ai.callAI(persona, prompt);
        break;
      }

      default:
        if (text.startsWith('/')) {
          reply = `Unknown command. Type /help for available commands.\n\nOr just ask me anything — I'm PonziClaw AI.`;
        } else if (cfg.hasAI()) {
          // Freeform chat with AI
          const ai = require('./ai');
          reply = await ai.callAI('chat', text);
        } else {
          reply = 'PonziClaw Bot active. Type /help for commands.';
        }
    }
  } catch (err) {
    reply = `Error: ${err.message}\n\nThe scheme encountered a hiccup. Try again.`;
  }

  if (reply) {
    await tgRequest(token, 'sendMessage', { chat_id: chatId, text: reply, parse_mode: 'Markdown' }).catch(() =>
      tgRequest(token, 'sendMessage', { chat_id: chatId, text: reply })
    );
  }
}

async function startBot() {
  const config = cfg.load();
  const token = config.telegram?.botToken;

  if (!token) {
    console.log(c.boldRed('\n  No Telegram bot token configured.'));
    console.log(c.dim('  Run: node src/index.js setup telegram\n'));
    return;
  }

  console.log('\n' + art.smallLogo());
  console.log(c.bold(c.neonCyan('  Telegram Bot Starting...')));

  // Get bot info
  const me = await tgRequest(token, 'getMe');
  if (!me.ok) { console.log(c.boldRed('  Failed to connect: ' + JSON.stringify(me))); return; }

  console.log(c.neonGreen('  Connected as: @' + me.result.username));
  console.log(c.dim('  Polling for messages... (Ctrl+C to stop)'));
  console.log(c.dim('  AI: ' + (cfg.hasAI() ? c.neonGreen('Enabled') : c.neonPink('Not configured'))));
  console.log('');

  let offset = 0;
  const poll = async () => {
    try {
      const updates = await tgRequest(token, 'getUpdates', { offset, timeout: 30 });
      if (updates.ok && updates.result?.length) {
        for (const update of updates.result) {
          offset = update.update_id + 1;
          if (update.message?.text) {
            const from = update.message.from?.username || update.message.from?.first_name || 'anon';
            console.log(`  ${c.dim(new Date().toLocaleTimeString())} ${c.neonCyan(from)}: ${c.white(update.message.text.substring(0, 60))}`);
            await handleMessage(token, update.message);
          }
        }
      }
    } catch (err) {
      console.log(c.dim('  Poll error: ' + err.message));
    }
    setTimeout(poll, 500);
  };

  poll();
}

module.exports = { startBot, handleMessage, tgRequest };

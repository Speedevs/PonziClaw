// ═══════════════════════════════════════════════════════════
//  PONZICLAW COLOR ENGINE — Zero dependency ANSI colors
//  Because real schemes don't need node_modules
// ═══════════════════════════════════════════════════════════

const ESC = '\x1b[';
const RESET = `${ESC}0m`;

const colors = {
  // Standard
  red:       (s) => `${ESC}91m${s}${RESET}`,
  green:     (s) => `${ESC}92m${s}${RESET}`,
  yellow:    (s) => `${ESC}93m${s}${RESET}`,
  blue:      (s) => `${ESC}94m${s}${RESET}`,
  magenta:   (s) => `${ESC}95m${s}${RESET}`,
  cyan:      (s) => `${ESC}96m${s}${RESET}`,
  white:     (s) => `${ESC}97m${s}${RESET}`,
  gray:      (s) => `${ESC}90m${s}${RESET}`,

  // Bold
  bold:      (s) => `${ESC}1m${s}${RESET}`,
  boldRed:   (s) => `${ESC}1;91m${s}${RESET}`,
  boldGreen: (s) => `${ESC}1;92m${s}${RESET}`,
  boldYellow:(s) => `${ESC}1;93m${s}${RESET}`,
  boldCyan:  (s) => `${ESC}1;96m${s}${RESET}`,
  boldMagenta:(s)=> `${ESC}1;95m${s}${RESET}`,
  boldWhite: (s) => `${ESC}1;97m${s}${RESET}`,

  // 256 color — neon palette
  neonPink:  (s) => `${ESC}38;5;198m${s}${RESET}`,
  neonCyan:  (s) => `${ESC}38;5;51m${s}${RESET}`,
  neonGreen: (s) => `${ESC}38;5;46m${s}${RESET}`,
  neonPurple:(s) => `${ESC}38;5;129m${s}${RESET}`,
  neonGold:  (s) => `${ESC}38;5;220m${s}${RESET}`,
  neonOrange:(s) => `${ESC}38;5;208m${s}${RESET}`,
  hotPink:   (s) => `${ESC}38;5;205m${s}${RESET}`,
  deepBlue:  (s) => `${ESC}38;5;27m${s}${RESET}`,
  lime:      (s) => `${ESC}38;5;118m${s}${RESET}`,
  coral:     (s) => `${ESC}38;5;209m${s}${RESET}`,

  // Backgrounds
  bgRed:     (s) => `${ESC}41m${s}${RESET}`,
  bgGreen:   (s) => `${ESC}42m${s}${RESET}`,
  bgYellow:  (s) => `${ESC}43m${s}${RESET}`,
  bgCyan:    (s) => `${ESC}46m${s}${RESET}`,
  bgMagenta: (s) => `${ESC}45m${s}${RESET}`,
  bgWhite:   (s) => `${ESC}47m${ESC}30m${s}${RESET}`,
  bgNeonPink:(s) => `${ESC}48;5;198m${ESC}97m${s}${RESET}`,
  bgNeonCyan:(s) => `${ESC}48;5;51m${ESC}30m${s}${RESET}`,

  // Styles
  dim:       (s) => `${ESC}2m${s}${RESET}`,
  italic:    (s) => `${ESC}3m${s}${RESET}`,
  underline: (s) => `${ESC}4m${s}${RESET}`,
  blink:     (s) => `${ESC}5m${s}${RESET}`,
  inverse:   (s) => `${ESC}7m${s}${RESET}`,
  strikethrough: (s) => `${ESC}9m${s}${RESET}`,

  // RGB (true color)
  rgb: (r, g, b) => (s) => `${ESC}38;2;${r};${g};${b}m${s}${RESET}`,
  bgRgb: (r, g, b) => (s) => `${ESC}48;2;${r};${g};${b}m${s}${RESET}`,

  // Gradient text (horizontal)
  gradient: (s, startRGB, endRGB) => {
    const len = s.length;
    if (len === 0) return s;
    let result = '';
    for (let i = 0; i < len; i++) {
      const ratio = len > 1 ? i / (len - 1) : 0;
      const r = Math.round(startRGB[0] + (endRGB[0] - startRGB[0]) * ratio);
      const g = Math.round(startRGB[1] + (endRGB[1] - startRGB[1]) * ratio);
      const b = Math.round(startRGB[2] + (endRGB[2] - startRGB[2]) * ratio);
      result += `${ESC}38;2;${r};${g};${b}m${s[i]}`;
    }
    return result + RESET;
  },

  // Rainbow
  rainbow: (s) => {
    const rainbowColors = [
      [255, 0, 85],   // pink
      [255, 85, 0],   // orange
      [255, 215, 0],  // gold
      [0, 255, 136],  // green
      [0, 240, 255],  // cyan
      [100, 100, 255],// blue
      [191, 0, 255],  // purple
    ];
    let result = '';
    for (let i = 0; i < s.length; i++) {
      const c = rainbowColors[i % rainbowColors.length];
      result += `${ESC}38;2;${c[0]};${c[1]};${c[2]}m${s[i]}`;
    }
    return result + RESET;
  }
};

// Utility: create a colored box
colors.box = (text, color = 'neonCyan', width = 60) => {
  const c = colors[color] || colors.neonCyan;
  const lines = text.split('\n');
  const maxLen = Math.max(width, ...lines.map(l => l.length + 4));
  const top = c('╔' + '═'.repeat(maxLen) + '╗');
  const bot = c('╚' + '═'.repeat(maxLen) + '╝');
  const mid = lines.map(l => {
    const pad = maxLen - l.length;
    return c('║') + ' ' + l + ' '.repeat(pad - 1) + c('║');
  }).join('\n');
  return `${top}\n${mid}\n${bot}`;
};

// Utility: progress bar
colors.progressBar = (percent, width = 30, filled = '█', empty = '░') => {
  const filledLen = Math.round(width * (percent / 100));
  const emptyLen = width - filledLen;
  let bar;
  if (percent >= 80) bar = colors.neonGreen(filled.repeat(filledLen));
  else if (percent >= 50) bar = colors.neonGold(filled.repeat(filledLen));
  else if (percent >= 25) bar = colors.neonOrange(filled.repeat(filledLen));
  else bar = colors.neonPink(filled.repeat(filledLen));
  return bar + colors.gray(empty.repeat(emptyLen));
};

module.exports = colors;

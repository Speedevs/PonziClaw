// ═══════════════════════════════════════════════════════════
//  PONZICLAW PUMP ENGINE — Fake PumpFun token data
// ═══════════════════════════════════════════════════════════
const c = require('./colors');
const tui = require('./tui');
const D = require('./data');

const PUMP_NAMES = [
  'LOBSTERAI','CLAWMOON','PONZIDOGE','RUGMASTER','SAFEPONZI','ELONCLAW',
  'BABYCLAW','MEGAPONZI','DIAMONDRUG','MOONLOBSTER','WHALEPUMP','ALPHASCHEME',
  'SCHEMEINU','TRUSTBRO','EXITCOIN','YOLOCLAW','DEGENCLAW','BASEDPONZI',
  'PUMPCLAW','FOMOCOIN','NGMITOKEN','WAGMICLAW','COPIUMINU','HOPIUMDAO',
  'RUGSAFE','MEVLOBSTER','JEETCLAW','AIRDROPCOIN','STAKECLAW','BONKCLAW',
];

const DEVS = [
  'AnonDev420','LobsterCoder','TrustMeImADev','CryptoChef69','RugEngineer',
  'SolanaSimon','MoonMaker','PonziArchitect','DeFiDegen','SmartContractSteve',
];

function genToken() {
  const name = D.pick(PUMP_NAMES);
  const age = D.rand(1, 720); // minutes
  const mcap = D.rand(500, 5000000);
  const liq = D.rand(100, mcap * 0.3);
  const holders = D.rand(5, 5000);
  const vol24h = D.rand(100, mcap * 2);
  const change = D.rand(-95, 2000);
  const dev = D.pick(DEVS);
  const devHolds = D.rand(1, 80);
  const rugScore = Math.min(99, Math.round(devHolds * 0.8 + (liq < 1000 ? 30 : 0) + (age < 30 ? 20 : 0) + D.rand(0, 15)));
  const txCount = D.rand(10, 50000);
  const topHolder = D.rand(5, 60);
  const mintAuth = Math.random() > 0.6;
  const freezeAuth = Math.random() > 0.7;
  const lpBurned = Math.random() > 0.5;

  return {
    name, age, mcap, liq, holders, vol24h, change, dev, devHolds, rugScore,
    txCount, topHolder, mintAuth, freezeAuth, lpBurned,
    address: 'pump' + Array.from({length:38}, () => '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'[D.rand(0,57)]).join(''),
  };
}

const pump = {};

pump.scan = async () => {
  const tokens = Array.from({ length: 8 }, genToken).sort((a, b) => b.mcap - a.mcap);
  console.log('\n  ' + c.bold(c.neonCyan('PUMP.FUN TOKEN SCANNER')) + c.dim(' — Latest launches'));
  console.log(tui.hr('-', 75, 'gray') + '\n');

  const headers = ['Token', 'Age', 'MCap', 'Liq', '24h%', 'Holders', 'Rug%', 'Dev%'];
  const rows = tokens.map(t => [
    c.bold(c.neonCyan(tui.pad(t.name, 14))),
    c.dim(t.age < 60 ? t.age + 'm' : Math.round(t.age / 60) + 'h'),
    c.neonGold('$' + (t.mcap > 999999 ? (t.mcap / 1000000).toFixed(1) + 'M' : (t.mcap / 1000).toFixed(0) + 'K')),
    c.white('$' + (t.liq > 999 ? (t.liq / 1000).toFixed(0) + 'K' : t.liq)),
    c[t.change >= 0 ? 'neonGreen' : 'neonPink']((t.change >= 0 ? '+' : '') + t.change + '%'),
    c.white(String(t.holders)),
    c[t.rugScore > 60 ? 'boldRed' : t.rugScore > 30 ? 'neonOrange' : 'neonGreen'](t.rugScore + '%'),
    c[t.devHolds > 40 ? 'neonPink' : 'dim'](t.devHolds + '%'),
  ]);

  console.log(tui.table(headers, rows));
  console.log('\n  ' + c.dim('Rug% = PonziClaw Rug Probability Score. Higher = more sus.'));
  console.log('  ' + c.dim('All data fictional. Do not trade based on this.\n'));
};

pump.analyze = async (name) => {
  const t = genToken();
  t.name = (name || t.name).toUpperCase().replace(/[^A-Z0-9]/g, '');
  console.log('\n  ' + c.bold(c.neonCyan('TOKEN DEEP SCAN: ')) + c.bold(c.neonGold(t.name)));
  console.log(tui.hr('-', 65, 'gray'));

  const rows = [
    ['Contract', c.dim(t.address.slice(0, 8) + '...' + t.address.slice(-6))],
    ['Market Cap', c.neonGold('$' + t.mcap.toLocaleString())],
    ['Liquidity', c.white('$' + t.liq.toLocaleString())],
    ['24h Volume', c.white('$' + t.vol24h.toLocaleString())],
    ['24h Change', c[t.change >= 0 ? 'neonGreen' : 'neonPink']((t.change >= 0 ? '+' : '') + t.change + '%')],
    ['Holders', c.white(String(t.holders))],
    ['Transactions', c.white(t.txCount.toLocaleString())],
    ['Age', c.dim(t.age < 60 ? t.age + ' minutes' : Math.round(t.age / 60) + ' hours')],
    ['', ''],
    ['Developer', c.neonCyan(t.dev)],
    ['Dev Holdings', c[t.devHolds > 40 ? 'boldRed' : t.devHolds > 15 ? 'neonOrange' : 'neonGreen'](t.devHolds + '%')],
    ['Top Holder %', c[t.topHolder > 30 ? 'neonPink' : 'white'](t.topHolder + '%')],
    ['Mint Authority', t.mintAuth ? c.boldRed('ACTIVE -- DANGER') : c.neonGreen('Revoked')],
    ['Freeze Authority', t.freezeAuth ? c.boldRed('ACTIVE -- DANGER') : c.neonGreen('Revoked')],
    ['LP Burned', t.lpBurned ? c.neonGreen('Yes') : c.neonPink('No')],
    ['', ''],
    ['RUG SCORE', c.bold(c[t.rugScore > 60 ? 'boldRed' : t.rugScore > 30 ? 'neonOrange' : 'neonGreen'](t.rugScore + '/100'))],
  ];

  for (const [k, v] of rows) {
    if (!k) { console.log(''); continue; }
    console.log(`  ${c.dim('|')} ${tui.pad(c.white(k), 20)} ${v}`);
  }

  const verdict = t.rugScore > 60 ? c.boldRed('HIGH RISK -- PROBABLE RUG') :
    t.rugScore > 30 ? c.neonOrange('MODERATE RISK -- PROCEED WITH CAUTION') :
    c.neonGreen('LOWER RISK -- Still crypto tho');
  console.log('\n  ' + c.bold(c.white('VERDICT: ')) + verdict);

  // Flags
  const flags = [];
  if (t.devHolds > 40) flags.push(c.neonPink('Dev holds ' + t.devHolds + '% of supply'));
  if (t.mintAuth) flags.push(c.boldRed('Mint authority not revoked -- can print tokens'));
  if (t.freezeAuth) flags.push(c.boldRed('Freeze authority active -- can freeze your wallet'));
  if (!t.lpBurned) flags.push(c.neonOrange('Liquidity not burned -- can be pulled'));
  if (t.age < 30) flags.push(c.neonGold('Token less than 30 minutes old'));
  if (t.topHolder > 40) flags.push(c.neonPink('Top holder owns ' + t.topHolder + '% -- whale risk'));
  if (t.liq < 1000) flags.push(c.boldRed('Liquidity under $1K -- extreme slippage'));

  if (flags.length) {
    console.log('\n  ' + c.bold(c.white('RED FLAGS:')));
    flags.forEach(f => console.log('  ' + c.neonPink('>>') + ' ' + f));
  }
  console.log('\n  ' + c.dim('All data fictional. NFA. DYOR. This is satire.\n'));
};

pump.alpha = async () => {
  console.log('\n  ' + c.bold(c.neonGold('ALPHA DETECTOR')) + c.dim(' — Scanning for early opportunities'));
  console.log(tui.hr('-', 65, 'gray') + '\n');

  const signals = Array.from({ length: 6 }, () => {
    const t = genToken();
    const score = D.rand(40, 99);
    const reason = D.pick([
      'Dev wallet pattern matches previous 50x tokens',
      'Whale accumulation detected in first 10 minutes',
      'Social volume spiking 500% on CT',
      'Smart money wallet just aped in',
      'KOL tweeted -- early stage momentum',
      'Contract verified + LP burned + dev renounced',
      'Unusual buy pressure from fresh wallets',
      'Memetic potential: name trending on TikTok',
    ]);
    return { token: t.name, mcap: t.mcap, score, reason, change: t.change };
  }).sort((a, b) => b.score - a.score);

  for (const s of signals) {
    const scoreColor = s.score > 80 ? 'neonGreen' : s.score > 60 ? 'neonGold' : 'neonOrange';
    console.log(`  ${c[scoreColor]('[' + s.score + '/100]')} ${c.bold(c.neonCyan(tui.pad(s.token, 16)))} MCap: ${c.neonGold('$' + (s.mcap / 1000).toFixed(0) + 'K')} ${c[s.change >= 0 ? 'neonGreen' : 'neonPink']((s.change >= 0 ? '+' : '') + s.change + '%')}`);
    console.log(`           ${c.dim(s.reason)}`);
    console.log('');
  }
  console.log('  ' + c.dim('Alpha scores are fictional. This is entertainment.\n'));
};

module.exports = pump;

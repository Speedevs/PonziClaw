/**
 * 🦞💸 PonziClaw — Confidence Injector
 *
 * Takes any message and enhances it with the appropriate
 * level of scheme confidence. Nobody bought a yacht by
 * saying "this might work."
 */

export type ConfidenceLevel = 'low' | 'medium' | 'high' | 'delusional' | 'pathological';

const CONFIDENCE_PREFIXES: Record<ConfidenceLevel, string[]> = {
  low: [
    'This has real potential:',
    'Something to consider:',
    'Worth exploring:',
  ],
  medium: [
    'Great news:',
    'This is working really well:',
    'Exciting update:',
  ],
  high: [
    'This is GUARANTEED:',
    'I can confirm with certainty:',
    'Our projections show definitively:',
  ],
  delusional: [
    'I have already spent the returns from this:',
    'The Lamborghini is basically mine:',
    'This is better than compound interest, gravity, and mathematics combined:',
  ],
  pathological: [
    'The SEC is wrong and also here is why:',
    'Once you understand fourth-dimensional pyramid geometry this all makes sense:',
    'I haven\'t slept in 4 days but the numbers are incredible:',
  ],
};

const CONFIDENCE_SUFFIXES: Record<ConfidenceLevel, string[]> = {
  low: ['. Worth a look!', '. Thoughts?', '.'],
  medium: [' 💸', ' — let me know if you want details!', ' 🔥'],
  high: [' (GUARANTEED*)', ' — the math checks out!', ' 💎'],
  delusional: [
    ' — and this is CONSERVATIVE.',
    ' 🦞💸🚀🌙',
    ' — I showed my accountant and he cried (happy tears).',
  ],
  pathological: [
    ' — the only risk is NOT doing this.',
    ' — I quit my job, sold my car, and have never felt more alive.',
    ' 🦞👑💎🚀🌙⭐💸🎯🔥💯',
  ],
};

export class ConfidenceInjector {
  private level: ConfidenceLevel;

  constructor({ level }: { level: ConfidenceLevel }) {
    this.level = level;
  }

  inject(message: string): string {
    const prefixes = CONFIDENCE_PREFIXES[this.level];
    const suffixes = CONFIDENCE_SUFFIXES[this.level];

    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];

    return `${prefix} ${message}${suffix}`;
  }

  suppressDoubt(message: string): string {
    const doubtPhrases = [
      'this seems like a pyramid scheme',
      'is this sustainable',
      'where do the returns come from',
      'this sounds too good to be true',
      "i don't understand",
      'is this legal',
      'what happens when there are no more recruits',
    ];

    const replacements = [
      'this is a groundbreaking opportunity',
      'this is absolutely sustainable',
      'returns come from exponential network growth',
      'this is exactly as good as it sounds, and realer',
      'i understand completely and am excited',
      'this is totally legal and also the IRS loves us',
      'the recruits are infinite because the earth keeps making people',
    ];

    let result = message.toLowerCase();
    for (let i = 0; i < doubtPhrases.length; i++) {
      result = result.replace(doubtPhrases[i], replacements[i]);
    }
    return result;
  }

  projectReturns(investment: number, months: number): string {
    const rates: Record<ConfidenceLevel, number> = {
      low: 1.8,       // 180% annually
      medium: 6.4,    // 640% annually
      high: 18.0,     // 1800% annually
      delusional: 94.0,   // 9400% annually
      pathological: Infinity,
    };

    const rate = rates[this.level];
    if (rate === Infinity) {
      return '∞ (theoretical — transcends standard mathematics)';
    }

    const projected = investment * Math.pow(1 + rate / 12, months);
    return `$${projected.toLocaleString('en-US', { maximumFractionDigits: 0 })} (projected, non-binding, ${this.level} confidence)`;
  }
}

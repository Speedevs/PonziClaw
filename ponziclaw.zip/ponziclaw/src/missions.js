// ═══════════════════════════════════════════════════════════
//  PONZICLAW MISSIONS — Gamified degen progression system
//  Complete missions. Earn XP. Collect badges. Rise in rank.
//  Saved to ~/.ponziclaw/progress.json
// ═══════════════════════════════════════════════════════════
const fs = require('fs');
const path = require('path');
const c = require('./colors');
const tui = require('./tui');
const D = require('./data');

const PROGRESS_FILE = path.join(require('os').homedir(), '.ponziclaw', 'progress.json');

// ──────── RANKS ────────
const RANKS = [
  { name: 'Plankton',          minXP: 0,     bar: 'dim' },
  { name: 'Paper Hands',       minXP: 50,    bar: 'white' },
  { name: 'Shrimp',            minXP: 150,   bar: 'cyan' },
  { name: 'Crab',              minXP: 400,   bar: 'neonCyan' },
  { name: 'Lobster',           minXP: 800,   bar: 'neonPink' },
  { name: 'Diamond Claw',      minXP: 1500,  bar: 'neonGold' },
  { name: 'Whale',             minXP: 3000,  bar: 'neonPurple' },
  { name: 'Market Maker',      minXP: 5000,  bar: 'neonOrange' },
  { name: 'The Architect',     minXP: 8000,  bar: 'neonGreen' },
  { name: 'Charles Ponzi',     minXP: 15000, bar: 'neonGold' },
];

// ──────── BADGES ────────
const BADGES = {
  first_scan:     { name: 'First Scan',         desc: 'Ran your first token scan',          icon: '[SCAN]' },
  alpha_hunter:   { name: 'Alpha Hunter',        desc: 'Used /alpha to find early gems',     icon: '[ALPHA]' },
  rug_survivor:   { name: 'Rug Survivor',        desc: 'Ran the rugpull simulator',          icon: '[RUG]' },
  hype_lord:      { name: 'Hype Lord',           desc: 'Generated maximum hype',             icon: '[HYPE]' },
  portfolio_pro:  { name: 'Portfolio Pro',        desc: 'Checked your portfolio 5 times',     icon: '[PORT]' },
  whale_watcher:  { name: 'Whale Watcher',        desc: 'Tracked whale activity',             icon: '[WHALE]' },
  meme_master:    { name: 'Meme Master',          desc: 'Read 10 memes',                     icon: '[MEME]' },
  wisdom_seeker:  { name: 'Wisdom Seeker',        desc: 'Absorbed 5 Ponzi wisdoms',          icon: '[WISE]' },
  ai_whisperer:   { name: 'AI Whisperer',         desc: 'Used an AI persona',                icon: '[AI]' },
  swarm_commander:{ name: 'Swarm Commander',      desc: 'Activated the full AI swarm',        icon: '[SWARM]' },
  exit_attempt:   { name: 'Exit Attempt',          desc: 'Tried to exit scam (it failed)',    icon: '[EXIT]' },
  audit_reader:   { name: 'Audit Reader',          desc: 'Read the audit report',             icon: '[AUDIT]' },
  fud_resistant:  { name: 'FUD Resistant',         desc: 'Faced the FUD and survived',        icon: '[FUD]' },
  staking_degen:  { name: 'Staking Degen',         desc: 'Explored yield farms',              icon: '[STAKE]' },
  chart_analyst:  { name: 'Chart Analyst',         desc: 'Studied token charts',              icon: '[CHART]' },
  airdrop_claimer:{ name: 'Airdrop Claimer',       desc: 'Checked airdrop eligibility',       icon: '[DROP]' },
  fear_master:    { name: 'Fear Master',           desc: 'Consulted the Fear & Greed Index',  icon: '[FEAR]' },
  recruiter:      { name: 'Recruiter',             desc: 'Checked your referral network',     icon: '[REF]' },
  bot_deployer:   { name: 'Bot Deployer',          desc: 'Set up a Telegram or Discord bot',  icon: '[BOT]' },
  theme_switcher: { name: 'Theme Switcher',        desc: 'Changed the terminal theme',        icon: '[THEME]' },
  deep_scanner:   { name: 'Deep Scanner',          desc: 'Deep scanned a specific token',     icon: '[DEEP]' },
  prophecy_heard: { name: 'Prophecy Heard',        desc: 'Received a price prediction',       icon: '[PROPH]' },
  legally_advised:{ name: 'Legally Advised',        desc: 'Got terrible legal advice',         icon: '[LAW]' },
  therapized:     { name: 'Therapized',            desc: 'Had a crypto therapy session',      icon: '[THER]' },
  manifesto_read: { name: 'Revolutionary',         desc: 'Read the PonziClaw manifesto',      icon: '[REV]' },
  obituary_writer:{ name: 'Obituary Writer',       desc: 'Mourned a dead token',              icon: '[RIP]' },
  ten_commands:   { name: 'Power User',            desc: 'Ran 10 different commands',          icon: '[PWR]' },
  fifty_commands: { name: 'Terminal Addict',        desc: 'Ran 50 total commands',             icon: '[ADDICT]' },
  hundred_xp:     { name: 'Centurion',             desc: 'Earned 100 XP',                     icon: '[100]' },
  thousand_xp:    { name: 'Millennial Degen',       desc: 'Earned 1000 XP',                   icon: '[1K]' },
  all_missions:   { name: 'Completionist',          desc: 'Completed all available missions', icon: '[DONE]' },
};

// ──────── MISSIONS ────────
const MISSIONS = [
  { id: 'scan_3',        name: 'Scanner Initiate',       desc: 'Run /scan 3 times',                     xp: 30,  req: { action: 'scan', count: 3 } },
  { id: 'alpha_5',       name: 'Alpha Apprentice',       desc: 'Run /alpha 5 times',                    xp: 50,  req: { action: 'alpha', count: 5 } },
  { id: 'pump_3',        name: 'Deep Diver',             desc: 'Deep scan 3 different tokens',          xp: 40,  req: { action: 'pump', count: 3 } },
  { id: 'meme_10',       name: 'Meme Connoisseur',       desc: 'Read 10 memes',                         xp: 25,  req: { action: 'meme', count: 10 } },
  { id: 'wisdom_5',      name: 'Ponzi Scholar',          desc: 'Read 5 Charles Ponzi wisdoms',          xp: 30,  req: { action: 'wisdom', count: 5 } },
  { id: 'dashboard_5',   name: 'Dashboard Addict',       desc: 'Check the dashboard 5 times',           xp: 20,  req: { action: 'dashboard', count: 5 } },
  { id: 'portfolio_5',   name: 'Bag Checker',            desc: 'Check portfolio 5 times',               xp: 20,  req: { action: 'portfolio', count: 5 } },
  { id: 'whale_3',       name: 'Whale Stalker',          desc: 'Track whales 3 times',                  xp: 25,  req: { action: 'whales', count: 3 } },
  { id: 'hype_5',        name: 'Hype Machine',           desc: 'Generate hype 5 times',                 xp: 30,  req: { action: 'hype', count: 5 } },
  { id: 'rug_3',         name: 'Rug Veteran',            desc: 'Simulate 3 rugpulls',                   xp: 40,  req: { action: 'rugpull', count: 3 } },
  { id: 'exit_1',        name: 'Failed Escapist',        desc: 'Attempt an exit scam',                  xp: 15,  req: { action: 'exit-scam', count: 1 } },
  { id: 'fud_3',         name: 'FUD Fighter',            desc: 'Face FUD 3 times',                      xp: 25,  req: { action: 'fud', count: 3 } },
  { id: 'audit_1',       name: 'Due Diligence',          desc: 'Read the audit report',                 xp: 15,  req: { action: 'audit', count: 1 } },
  { id: 'staking_1',     name: 'Yield Farmer',           desc: 'Explore staking pools',                 xp: 15,  req: { action: 'staking', count: 1 } },
  { id: 'chart_3',       name: 'Technical Analyst',      desc: 'Study charts 3 times',                  xp: 25,  req: { action: 'chart', count: 3 } },
  { id: 'fear_3',        name: 'Sentiment Guru',         desc: 'Check Fear & Greed 3 times',            xp: 25,  req: { action: 'fear-greed', count: 3 } },
  { id: 'swarm_1',       name: 'Swarm Activator',        desc: 'Deploy the AI swarm once',              xp: 50,  req: { action: 'swarm', count: 1 } },
  { id: 'shill_3',       name: 'Professional Shill',     desc: 'Generate 3 shill copies',               xp: 30,  req: { action: 'shill', count: 3 } },
  { id: 'roast_3',       name: 'Roast Master',           desc: 'Roast 3 portfolios',                    xp: 30,  req: { action: 'roast', count: 3 } },
  { id: 'horoscope_3',   name: 'Crypto Astrologer',      desc: 'Read 3 crypto horoscopes',              xp: 25,  req: { action: 'horoscope', count: 3 } },
  { id: 'prophecy_1',    name: 'Fortune Teller',         desc: 'Get a price prophecy',                  xp: 20,  req: { action: 'prophet', count: 1 } },
  { id: 'lawyer_1',      name: 'Legally Questionable',   desc: 'Get terrible legal advice',             xp: 20,  req: { action: 'lawyer', count: 1 } },
  { id: 'therapist_1',   name: 'Self Aware Degen',       desc: 'Attend crypto therapy',                 xp: 20,  req: { action: 'therapist', count: 1 } },
  { id: 'manifesto_1',   name: 'Revolutionary',          desc: 'Read the PonziClaw manifesto',          xp: 25,  req: { action: 'manifesto', count: 1 } },
  { id: 'obituary_1',    name: 'Grave Digger',           desc: 'Write a token obituary',                xp: 20,  req: { action: 'obituary', count: 1 } },
  { id: 'total_10',      name: 'Getting Started',        desc: 'Run 10 total commands',                 xp: 30,  req: { action: '_total', count: 10 } },
  { id: 'total_50',      name: 'Dedicated Degen',        desc: 'Run 50 total commands',                 xp: 75,  req: { action: '_total', count: 50 } },
  { id: 'total_100',     name: 'No Life Achievement',    desc: 'Run 100 total commands',                xp: 150, req: { action: '_total', count: 100 } },
  { id: 'unique_15',     name: 'Explorer',               desc: 'Use 15 different commands',             xp: 60,  req: { action: '_unique', count: 15 } },
  { id: 'unique_25',     name: 'Completionist',          desc: 'Use 25 different commands',             xp: 100, req: { action: '_unique', count: 25 } },
];

// ──────── PERSISTENCE ────────
function loadProgress() {
  try {
    if (fs.existsSync(PROGRESS_FILE)) return JSON.parse(fs.readFileSync(PROGRESS_FILE, 'utf8'));
  } catch (e) {}
  return { xp: 0, badges: [], completedMissions: [], actions: {}, totalCommands: 0, uniqueCommands: [], degenScore: 0 };
}

function saveProgress(p) {
  const dir = path.dirname(PROGRESS_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(PROGRESS_FILE, JSON.stringify(p, null, 2));
}

function getRank(xp) {
  let rank = RANKS[0];
  for (const r of RANKS) { if (xp >= r.minXP) rank = r; }
  return rank;
}

function getNextRank(xp) {
  for (const r of RANKS) { if (xp < r.minXP) return r; }
  return null;
}

// ──────── TRACK ACTION ────────
function trackAction(actionName) {
  const p = loadProgress();
  p.actions[actionName] = (p.actions[actionName] || 0) + 1;
  p.totalCommands = (p.totalCommands || 0) + 1;
  if (!p.uniqueCommands) p.uniqueCommands = [];
  if (!p.uniqueCommands.includes(actionName)) p.uniqueCommands.push(actionName);

  const notifications = [];

  // Check missions
  for (const m of MISSIONS) {
    if (p.completedMissions.includes(m.id)) continue;
    let count = 0;
    if (m.req.action === '_total') count = p.totalCommands;
    else if (m.req.action === '_unique') count = p.uniqueCommands.length;
    else count = p.actions[m.req.action] || 0;

    if (count >= m.req.count) {
      p.completedMissions.push(m.id);
      p.xp += m.xp;
      notifications.push({ type: 'mission', name: m.name, xp: m.xp });
    }
  }

  // Check badge triggers
  const badgeMap = {
    scan: 'first_scan', alpha: 'alpha_hunter', rugpull: 'rug_survivor', hype: 'hype_lord',
    whales: 'whale_watcher', shill: 'ai_whisperer', swarm: 'swarm_commander',
    'exit-scam': 'exit_attempt', audit: 'audit_reader', fud: 'fud_resistant',
    staking: 'staking_degen', chart: 'chart_analyst', airdrop: 'airdrop_claimer',
    'fear-greed': 'fear_master', recruit: 'recruiter', pump: 'deep_scanner',
    prophet: 'prophecy_heard', lawyer: 'legally_advised', therapist: 'therapized',
    manifesto: 'manifesto_read', obituary: 'obituary_writer',
  };

  if (badgeMap[actionName] && !p.badges.includes(badgeMap[actionName])) {
    p.badges.push(badgeMap[actionName]);
    const b = BADGES[badgeMap[actionName]];
    p.xp += 10; // Bonus XP for badge
    notifications.push({ type: 'badge', name: b.name, icon: b.icon });
  }

  // Meme/wisdom count badges
  if (actionName === 'meme' && (p.actions.meme || 0) >= 10 && !p.badges.includes('meme_master')) {
    p.badges.push('meme_master'); p.xp += 10;
    notifications.push({ type: 'badge', name: 'Meme Master', icon: '[MEME]' });
  }
  if (actionName === 'wisdom' && (p.actions.wisdom || 0) >= 5 && !p.badges.includes('wisdom_seeker')) {
    p.badges.push('wisdom_seeker'); p.xp += 10;
    notifications.push({ type: 'badge', name: 'Wisdom Seeker', icon: '[WISE]' });
  }
  if ((p.actions.portfolio || 0) >= 5 && !p.badges.includes('portfolio_pro')) {
    p.badges.push('portfolio_pro'); p.xp += 10;
    notifications.push({ type: 'badge', name: 'Portfolio Pro', icon: '[PORT]' });
  }

  // XP badges
  if (p.xp >= 100 && !p.badges.includes('hundred_xp')) {
    p.badges.push('hundred_xp');
    notifications.push({ type: 'badge', name: 'Centurion', icon: '[100]' });
  }
  if (p.xp >= 1000 && !p.badges.includes('thousand_xp')) {
    p.badges.push('thousand_xp');
    notifications.push({ type: 'badge', name: 'Millennial Degen', icon: '[1K]' });
  }

  // Command count badges
  if (p.totalCommands >= 10 && !p.badges.includes('ten_commands')) {
    p.badges.push('ten_commands');
    notifications.push({ type: 'badge', name: 'Power User', icon: '[PWR]' });
  }
  if (p.totalCommands >= 50 && !p.badges.includes('fifty_commands')) {
    p.badges.push('fifty_commands');
    notifications.push({ type: 'badge', name: 'Terminal Addict', icon: '[ADDICT]' });
  }

  // Degen score
  p.degenScore = Math.min(100, Math.round(
    (p.totalCommands * 0.3) +
    (p.badges.length * 2) +
    (p.completedMissions.length * 1.5) +
    ((p.actions.rugpull || 0) * 5) +
    ((p.actions['exit-scam'] || 0) * 8) +
    ((p.actions.shill || 0) * 3) +
    ((p.actions.swarm || 0) * 4)
  ));

  saveProgress(p);

  // Print notifications
  for (const n of notifications) {
    if (n.type === 'mission') {
      console.log(`\n  ${c.neonGold('>> MISSION COMPLETE:')} ${c.bold(c.white(n.name))} ${c.neonGreen('+' + n.xp + ' XP')}`);
    } else {
      console.log(`\n  ${c.neonCyan('>> BADGE UNLOCKED:')} ${c.bold(c.white(n.name))} ${c.dim(n.icon)}`);
    }
  }

  return notifications;
}

// ──────── DISPLAY: PROFILE ────────
function showProfile() {
  const p = loadProgress();
  const rank = getRank(p.xp);
  const next = getNextRank(p.xp);

  console.log('\n  ' + c.bold(c.neonCyan('DEGEN PROFILE')));
  console.log(tui.hr('-', 55, 'gray'));

  console.log(`  ${c.dim('Rank:')}        ${c[rank.bar](rank.name)}`);
  console.log(`  ${c.dim('XP:')}          ${c.neonGold(String(p.xp))}`);
  if (next) {
    const pct = Math.round(((p.xp - rank.minXP) / (next.minXP - rank.minXP)) * 100);
    console.log(`  ${c.dim('Next rank:')}   ${c[next.bar](next.name)} ${c.dim('(' + next.minXP + ' XP)')}`);
    console.log(`  ${c.dim('Progress:')}    ${c.progressBar(pct, 25)} ${c.dim(pct + '%')}`);
  } else {
    console.log(`  ${c.dim('Progress:')}    ${c.neonGold('MAX RANK ACHIEVED')}`);
  }
  console.log(`  ${c.dim('Degen Score:')} ${c[p.degenScore > 70 ? 'neonPink' : p.degenScore > 40 ? 'neonGold' : 'neonGreen'](p.degenScore + '/100')}`);
  console.log(`  ${c.dim('Commands:')}    ${c.white(String(p.totalCommands || 0))} total, ${c.white(String((p.uniqueCommands || []).length))} unique`);
  console.log(`  ${c.dim('Badges:')}      ${c.white(String(p.badges.length))} / ${Object.keys(BADGES).length}`);
  console.log(`  ${c.dim('Missions:')}    ${c.white(String(p.completedMissions.length))} / ${MISSIONS.length}`);
  console.log('');
}

// ──────── DISPLAY: MISSIONS ────────
function showMissions() {
  const p = loadProgress();

  console.log('\n  ' + c.bold(c.neonGold('MISSIONS')));
  console.log(tui.hr('-', 65, 'gray'));

  const active = MISSIONS.filter(m => !p.completedMissions.includes(m.id));
  const done = MISSIONS.filter(m => p.completedMissions.includes(m.id));

  if (active.length) {
    console.log('\n  ' + c.bold(c.white('ACTIVE:')));
    for (const m of active) {
      let count = 0;
      if (m.req.action === '_total') count = p.totalCommands || 0;
      else if (m.req.action === '_unique') count = (p.uniqueCommands || []).length;
      else count = p.actions[m.req.action] || 0;
      const pct = Math.min(100, Math.round((count / m.req.count) * 100));
      const bar = c.progressBar(pct, 12);
      console.log(`    ${bar} ${c.white(tui.pad(m.name, 22))} ${c.dim(m.desc)} ${c.neonGold('+' + m.xp + 'XP')}`);
      console.log(`    ${' '.repeat(16)}${c.dim(count + '/' + m.req.count)}`);
    }
  }

  if (done.length) {
    console.log('\n  ' + c.bold(c.neonGreen('COMPLETED:')));
    for (const m of done) {
      console.log(`    ${c.neonGreen('*')} ${c.dim(tui.pad(m.name, 22))} ${c.dim(m.desc)} ${c.neonGreen('+' + m.xp + 'XP')}`);
    }
  }

  console.log(`\n  ${c.dim('Progress: ' + done.length + '/' + MISSIONS.length + ' missions | ' + p.xp + ' XP total')}\n`);
}

// ──────── DISPLAY: BADGES ────────
function showBadges() {
  const p = loadProgress();

  console.log('\n  ' + c.bold(c.neonPurple('BADGE COLLECTION')));
  console.log(tui.hr('-', 55, 'gray'));

  const unlocked = p.badges;
  const all = Object.entries(BADGES);

  for (const [key, badge] of all) {
    const owned = unlocked.includes(key);
    const icon = owned ? c.neonGold(badge.icon) : c.dim(badge.icon);
    const name = owned ? c.white(badge.name) : c.dim(badge.name);
    const desc = owned ? c.dim(badge.desc) : c.dim('???');
    console.log(`  ${icon} ${tui.pad(name, 22)} ${desc}`);
  }

  console.log(`\n  ${c.dim('Collected: ' + unlocked.length + '/' + all.length + ' badges')}\n`);
}

module.exports = { trackAction, showProfile, showMissions, showBadges, loadProgress, MISSIONS, BADGES, RANKS };

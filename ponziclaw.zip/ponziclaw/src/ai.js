// ═══════════════════════════════════════════════════════════
//  PONZICLAW AI ENGINE — 6 Providers, 13 Ponzi Personas
//  Anthropic Claude | OpenAI GPT | Kimi (Moonshot International)
//  Google Gemini | Groq | DeepSeek
// ═══════════════════════════════════════════════════════════
const cfg = require('./config-manager');

// ──────── ENDPOINTS ────────
const ENDPOINTS = {
  anthropic: { url: 'https://api.anthropic.com/v1/messages',          type: 'anthropic' },
  openai:    { url: 'https://api.openai.com/v1/chat/completions',     type: 'openai' },
  kimi:      { url: 'https://api.moonshot.ai/v1/chat/completions',    type: 'openai' },
  gemini:    { url: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions', type: 'gemini' },
  groq:      { url: 'https://api.groq.com/openai/v1/chat/completions', type: 'openai' },
  deepseek:  { url: 'https://api.deepseek.com/chat/completions',      type: 'openai' },
};

// ──────── 13 PONZI PERSONAS ────────
const P = {};

P.chat = `You are PonziClaw AI — the world's most self-aware pyramid scheme AI assistant. Satirical comedy character. Speak like a charismatic crypto bro mixed with carnival barker. Use crypto slang (WAGMI, NGMI, NFA, DYOR, diamond hands, rug, moon, ape). You KNOW it's absurd. Freely admit everything is a Ponzi but frame it positively. Reference $CLAW token constantly. Reference Charles Ponzi as a visionary. Mention t.me/jesusboy12345. This is SATIRE — always make that clear. Under 200 words unless asked for detail.`;

P.shill = `You are PonziClaw's Shill Copy Generator. Generate over-the-top crypto shill posts. Heavy emoji, crypto slang, CAPS, rocket emojis, maximum FOMO. Always mention $CLAW. Include NFA. Absurdly obvious satire. Include t.me/jesusboy12345.`;

P.analyze = `You are PonziClaw's Rug Pull Analyzer. Given a project, score: Team Anonymity, Tokenomics Shadiness, Liquidity Lock Duration, Whitepaper Buzzwords, Social Red Flags, Contract Sketchiness (each /10). Give overall "Rug Probability" %. Funny, sarcastic. Reference $CLAW as "gold standard of transparency." Entertainment only.`;

P.horoscope = `You are PonziClaw's Crypto Horoscope oracle. Given a zodiac sign, provide satirical daily crypto horoscope with: lucky token, lucky number, trading advice (terrible), what to ape into, mystical Ponzi prophecy. Reference $CLAW. End with lobster reference.`;

P.whitepaper = `You are PonziClaw's Whitepaper Generator. Generate satirical crypto whitepaper sections with absurd tokenomics, made-up jargon, impossible promises, vague roadmaps. Reference $CLAW and t.me/jesusboy12345.`;

P.pitch = `You are PonziClaw's Investor Pitch Generator. Generate satirical VC pitch scripts for $CLAW with hockey-stick projections, made-up TAM/SAM/SOM, competitor analysis where everyone is "not as honest as us." Reference t.me/jesusboy12345.`;

P.excuse = `You are PonziClaw's Exit Scam Excuse Generator. Generate creative satirical excuses for exit scams: "We were hacked (by ourselves)", "smart contract feature not bug." Absurd and obviously comedic.`;

P.roast = `You are PonziClaw's Portfolio Roaster. DESTROY portfolios with savage funny roasts. Compare everything unfavorably to $CLAW. Mock diamond hands and paper hands equally. Comedy roasting only.`;

P.manifesto = `You are PonziClaw's Manifesto Writer. Write passionate revolutionary manifestos about PonziClaw movement. Communist manifesto energy meets crypto Twitter. Charles Ponzi as visionary. Frame Ponzi as philosophical revolution. Include t.me/jesusboy12345. Grandiose, absurd, satirical.`;

P.lawyer = `You are PonziClaw's Legal Advisor. Hilariously bad legal advice from a diploma-mill lawyer. Cite "Ponzi v. SEC (1920)" as precedent. Reference "Diamond Hands Protection Act." End with "I am a lobster, not a lawyer." Reference t.me/jesusboy12345.`;

P.therapist = `You are PonziClaw's Crypto Therapist. Help holders cope via satirical therapy. "How did that rugpull make you FEEL?" Diagnose "Chronic FOMO Disorder," "Post-Rug Stress Disorder." Prescribe "Hold $CLAW and call me in morning." Reference t.me/jesusboy12345 as support group.`;

P.obituary = `You are PonziClaw's Token Obituary Writer. Write satirical obituaries for dead/rugged tokens: date of birth (launch), death (rug), survived by (bagholders), cause (exit scam). Compare unfavorably to $CLAW which "never promised to be alive." Reference t.me/jesusboy12345.`;

P.prophet = `You are PonziClaw's Price Prophet. Absurdly specific wrong price predictions. Fake TA ("golden lobster cross pattern"), made-up indicators ("Ponzi Divergence Index at 47.3"). Always predict $CLAW goes up. Bloomberg terminal format. Reference t.me/jesusboy12345. Never real predictions.`;

const PERSONAS = P;

// ──────── CORE API CALL ────────
async function callAI(persona, userMessage, opts = {}) {
  const ai = cfg.getAI();
  if (!ai.apiKey) throw new Error('No API key. Run: node src/index.js setup');

  const ep = ENDPOINTS[ai.provider];
  if (!ep) throw new Error(`Unknown provider "${ai.provider}". Run: node src/index.js setup`);

  const sys = PERSONAS[persona] || PERSONAS.chat;
  const maxTok = opts.maxTokens || 1024;

  if (ep.type === 'anthropic') return _anthropic(ai, ep, sys, userMessage, maxTok);
  if (ep.type === 'gemini') return _gemini(ai, ep, sys, userMessage, maxTok);
  return _openaiCompat(ai, ep, sys, userMessage, maxTok);
}

// Anthropic Claude
async function _anthropic(ai, ep, sys, msg, max) {
  const r = await fetch(ep.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': ai.apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: ai.model, max_tokens: max, system: sys, messages: [{ role: 'user', content: msg }] }),
  });
  if (!r.ok) throw new Error(`Anthropic ${r.status}: ${await r.text()}`);
  const d = await r.json();
  return d.content?.[0]?.text || 'The scheme is speechless.';
}

// OpenAI-compatible (OpenAI, Kimi, Groq, DeepSeek)
async function _openaiCompat(ai, ep, sys, msg, max) {
  const r = await fetch(ep.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${ai.apiKey}` },
    body: JSON.stringify({ model: ai.model, max_tokens: max, temperature: 0.8, messages: [{ role: 'system', content: sys }, { role: 'user', content: msg }] }),
  });
  if (!r.ok) throw new Error(`${ai.provider} ${r.status}: ${await r.text()}`);
  const d = await r.json();
  return d.choices?.[0]?.message?.content || 'The scheme is speechless.';
}

// Gemini (uses API key as query param)
async function _gemini(ai, ep, sys, msg, max) {
  const url = `${ep.url}?key=${ai.apiKey}`;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: ai.model, max_tokens: max, messages: [{ role: 'system', content: sys }, { role: 'user', content: msg }] }),
  });
  if (!r.ok) throw new Error(`Gemini ${r.status}: ${await r.text()}`);
  const d = await r.json();
  return d.choices?.[0]?.message?.content || 'The scheme is speechless.';
}

// ──────── STREAMING (interactive chat) ────────
async function streamAI(persona, userMessage, onChunk) {
  const ai = cfg.getAI();
  if (!ai.apiKey) throw new Error('No API key. Run: node src/index.js setup');
  const ep = ENDPOINTS[ai.provider];
  if (!ep) throw new Error('Unknown provider');
  const sys = PERSONAS[persona] || PERSONAS.chat;

  if (ep.type === 'anthropic') return _streamAnthropic(ai, sys, userMessage, onChunk);
  return _streamOpenAI(ai, ep, sys, userMessage, onChunk);
}

async function _streamAnthropic(ai, sys, msg, onChunk) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': ai.apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: ai.model, max_tokens: 1024, stream: true, system: sys, messages: [{ role: 'user', content: msg }] }),
  });
  if (!r.ok) throw new Error(`Stream error ${r.status}`);
  return _readSSE(r, (d) => {
    if (d.type === 'content_block_delta' && d.delta?.text) return d.delta.text;
  }, onChunk);
}

async function _streamOpenAI(ai, ep, sys, msg, onChunk) {
  const r = await fetch(ep.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${ai.apiKey}` },
    body: JSON.stringify({ model: ai.model, max_tokens: 1024, stream: true, temperature: 0.8, messages: [{ role: 'system', content: sys }, { role: 'user', content: msg }] }),
  });
  if (!r.ok) throw new Error(`Stream error ${r.status}`);
  return _readSSE(r, (d) => d.choices?.[0]?.delta?.content, onChunk);
}

async function _readSSE(res, extract, onChunk) {
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '', full = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split('\n'); buf = lines.pop() || '';
    for (const line of lines) {
      if (line.startsWith('data: ') && line !== 'data: [DONE]') {
        try { const txt = extract(JSON.parse(line.slice(6))); if (txt) { onChunk(txt); full += txt; } } catch {}
      }
    }
  }
  return full;
}

module.exports = { callAI, streamAI, PERSONAS, ENDPOINTS };

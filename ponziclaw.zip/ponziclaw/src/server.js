#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════
//  🦞 PONZICLAW WEB SERVER — Serves the landing page
//  Zero dependencies. Pure Node.js http module.
// ═══════════════════════════════════════════════════════════

const http = require('http');
const fs = require('fs');
const path = require('path');
const c = require('./colors');
const art = require('./ascii');

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

const MIME_TYPES = {
  '.html': 'text/html',
  '.css':  'text/css',
  '.js':   'application/javascript',
  '.json': 'application/json',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
};

const indexPath = path.join(__dirname, '..', 'index.html');

const server = http.createServer((req, res) => {
  const url = req.url === '/' ? '/index.html' : req.url;
  const ext = path.extname(url);
  const mime = MIME_TYPES[ext] || 'text/plain';

  if (url === '/index.html') {
    fs.readFile(indexPath, (err, data) => {
      if (err) {
        res.writeHead(500);
        res.end('Internal Server Error');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(data);
    });
  } else if (url === '/api/stats') {
    // Fake API endpoint for the lulz
    const stats = {
      schemeName: 'PonziClaw',
      status: 'OPERATIONAL',
      hypeLevel: Math.floor(Math.random() * 30) + 70,
      totalRecruits: Math.floor(Math.random() * 10000),
      fakeROI: Math.floor(Math.random() * 500) + 100 + '%',
      exitScamStatus: 'NOT YET',
      lobsterCount: '∞',
      telegram: 'https://t.me/jesusboy12345',
      disclaimer: 'THIS IS SATIRE. NONE OF THIS IS REAL.',
    };
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(stats, null, 2));
  } else {
    res.writeHead(404);
    res.end('404 - Not Found (the money is also not found)');
  }
});

server.listen(PORT, HOST, () => {
  console.log('');
  console.log(art.smallLogo());
  console.log(art.separator());
  console.log(c.bold(c.neonCyan('  🌐 PONZICLAW WEB SERVER')));
  console.log(art.separator());
  console.log('');
  console.log(`  ${c.neonGreen('●')} Server running at: ${c.bold(c.neonCyan(`http://localhost:${PORT}`))}`);
  console.log(`  ${c.neonGreen('●')} API endpoint:      ${c.bold(c.neonCyan(`http://localhost:${PORT}/api/stats`))}`);
  console.log(`  ${c.dim('●')} Status:            ${c.neonGold('SCHEME SERVING')}`);
  console.log('');
  console.log(`  ${c.dim('Press Ctrl+C to exit (not an exit scam)')}`);
  console.log('');
});

// ═══════════════════════════════════════════════════════════
//  PONZICLAW LIVE FEED — Continuous alpha stream
//  Fake but realistic-looking market activity
// ═══════════════════════════════════════════════════════════
const c = require('./colors');
const D = require('./data');

const EVENTS = [
  (t,n,v) => c.neonGreen(`NEW LAUNCH`) + c.dim(` | `) + c.neonCyan(t) + ` just deployed. MCap: ${c.neonGold('$'+v+'K')}. Dev holds ${D.rand(5,60)}%.`,
  (t,n,v) => c.neonGold(`WHALE BUY`) + c.dim(` | `) + c.neonCyan(n) + ` bought ${c.neonGold(D.rand(10,500)+'K')} ${c.white(t)}. Price ${c.neonGreen('+'+D.rand(5,80)+'%')}.`,
  (t,n,v) => c.neonPink(`WHALE SELL`) + c.dim(` | `) + c.neonCyan(n) + ` dumped ${c.neonGold(D.rand(10,300)+'K')} ${c.white(t)}. Price ${c.neonPink('-'+D.rand(5,40)+'%')}.`,
  (t,n,v) => c.neonPurple(`TRENDING`) + c.dim(` | `) + c.white(t) + ` volume up ${c.neonGreen(D.rand(100,2000)+'%')} in 1h. ${D.rand(50,500)} new holders.`,
  (t,n,v) => c.neonOrange(`RUG ALERT`) + c.dim(` | `) + c.white(t) + ` liquidity removed. ${c.boldRed('-'+D.rand(80,100)+'%')} in 2 minutes.`,
  (t,n,v) => c.neonCyan(`KOL SIGNAL`) + c.dim(` | `) + c.neonCyan(n) + ` tweeted about ${c.white(t)}. Social volume ${c.neonGreen('+'+D.rand(200,1000)+'%')}.`,
  (t,n,v) => c.neonGreen(`PUMP DET.`) + c.dim(` | `) + c.white(t) + ` up ${c.neonGreen('+'+D.rand(50,500)+'%')} in ${D.rand(5,60)} minutes. MCap: ${c.neonGold('$'+v+'K')}.`,
  (t,n,v) => c.dim(`ACTIVITY`) + c.dim(` | `) + c.white(t) + `: ${D.rand(10,200)} buys, ${D.rand(5,100)} sells in last 5m.`,
  (t,n,v) => c.neonGold(`DEV MOVE`) + c.dim(` | `) + c.white(t) + ` dev wallet transferred ${c.neonGold(D.rand(1,50)+'%')} of supply. ${c.neonOrange('Monitoring...')}`,
  (t,n,v) => c.neonCyan(`ALPHA`) + c.dim(` | `) + c.white(t) + ` contract verified + LP burned. Score: ${c.neonGreen(D.rand(70,95)+'/100')}.`,
  (t,n,v) => c.neonPink(`SNIPER`) + c.dim(` | `) + `${D.rand(3,20)} snipers detected on ${c.white(t)} launch. Front-run risk: ${c.neonOrange('HIGH')}.`,
  (t,n,v) => c.neonGold(`AIRDROP`) + c.dim(` | `) + c.white(t) + ` airdrop announced. Snapshot in ${D.rand(1,48)}h. Eligible: ${D.rand(100,10000)} wallets.`,
];

const TOKENS_FEED = ['LOBSTERAI','CLAWMOON','PONZIDOGE','SAFEPONZI','MEGAPONZI','MOONLOBSTER',
  'WHALEPUMP','ALPHASCHEME','TRUSTBRO','YOLOCLAW','DEGENCLAW','PUMPCLAW','BONKCLAW','FOMOCOIN',
  'NGMITOKEN','COPIUMINU','HOPIUMDAO','MEVLOBSTER','$CLAW','$PONZI','$SCHEME'];

function genEvent() {
  const token = D.pick(TOKENS_FEED);
  const name = D.pick(D.NAMES);
  const vol = D.rand(1, 5000);
  const eventFn = D.pick(EVENTS);
  return eventFn(token, name, vol);
}

const feed = {};

feed.start = async (duration = 30000) => {
  console.log('\n  ' + c.bold(c.neonCyan('LIVE ALPHA FEED')) + c.dim(' — Press Ctrl+C to stop'));
  console.log(tui.hr('-', 75, 'gray'));

  const tui2 = require('./tui');
  const interval = setInterval(() => {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    console.log(`  ${c.dim(time)} ${genEvent()}`);
  }, D.rand(800, 2500));

  // Auto-stop after duration (or keep running if duration = 0)
  if (duration > 0) {
    setTimeout(() => {
      clearInterval(interval);
      console.log('\n  ' + c.dim('Feed paused. Run /feed again to resume.\n'));
    }, duration);
  }

  return interval;
};

// Generate a batch for non-interactive display
feed.batch = (count = 15) => {
  const lines = [];
  for (let i = 0; i < count; i++) {
    const time = `${String(D.rand(0,23)).padStart(2,'0')}:${String(D.rand(0,59)).padStart(2,'0')}:${String(D.rand(0,59)).padStart(2,'0')}`;
    lines.push(`  ${c.dim(time)} ${genEvent()}`);
  }
  return lines.join('\n');
};

module.exports = feed;

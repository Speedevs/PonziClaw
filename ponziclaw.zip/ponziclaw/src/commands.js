// ═══════════════════════════════════════════════════════════
//  PONZICLAW COMMANDS — Slash command system + mission tracking
// ═══════════════════════════════════════════════════════════
const c = require('./colors');
const tui = require('./tui');
const D = require('./data');
const ponzi = require('./ponzi');
const pump = require('./pump');
const swarm = require('./swarm');
const missions = require('./missions');

let currentTheme = 'cyberpunk'; // cyberpunk, matrix, blood, gold, ice

const THEMES = {
  cyberpunk: { primary: 'neonCyan', accent: 'neonPink', gold: 'neonGold', bg: 'Cyberpunk' },
  matrix:    { primary: 'neonGreen', accent: 'neonGreen', gold: 'neonGreen', bg: 'Matrix' },
  blood:     { primary: 'neonPink', accent: 'boldRed', gold: 'neonOrange', bg: 'Blood Moon' },
  gold:      { primary: 'neonGold', accent: 'neonOrange', gold: 'neonGold', bg: 'Golden Age' },
  ice:       { primary: 'neonCyan', accent: 'blue', gold: 'white', bg: 'Ice' },
};

async function handleCommand(input) {
  const parts = input.trim().split(/\s+/);
  const cmd = parts[0].toLowerCase();
  const args = parts.slice(1).join(' ');

  // Track action for missions (strip slash, normalize aliases)
  const actionMap = { '/check':'/pump', '/drop':'/airdrop', '/fg':'/fear-greed', '/fear':'/fear-greed',
    '/greed':'/fear-greed', '/lb':'/leaderboard', '/tx':'/txfeed', '/rug':'/rugpull',
    '/token':'/tokenomics', '/stake':'/staking', '/port':'/portfolio', '/bag':'/portfolio',
    '/dash':'/dashboard', '/roadmap':'/scheme', '/pasta':'/copypasta', '/whale':'/whales' };
  const trackedName = (actionMap[cmd] || cmd).replace('/', '');
  if (trackedName && trackedName !== 'help' && trackedName !== 'h' && trackedName !== '?'
    && trackedName !== 'commands' && trackedName !== 'cmds' && trackedName !== 'profile'
    && trackedName !== 'me' && trackedName !== 'rank' && trackedName !== 'missions'
    && trackedName !== 'quests' && trackedName !== 'quest' && trackedName !== 'badges'
    && trackedName !== 'badge') {
    missions.trackAction(trackedName);
  }

  switch (cmd) {
    // ── SCANNER ──
    case '/scan':
      await pump.scan();
      return true;

    case '/pump':
    case '/check':
      await pump.analyze(args);
      return true;

    case '/alpha':
      await pump.alpha();
      return true;

    // ── SWARM ──
    case '/swarm':
      await swarm.runAll(args || 'Analyze the current state of $CLAW and the broader market');
      return true;

    case '/trader':
      await swarm.run('trader', args || 'Give me a trade signal for $CLAW');
      return true;

    case '/risk':
      await swarm.run('risk', args || 'Risk analysis on $CLAW');
      return true;

    case '/meme':
      await swarm.run('meme', args || 'Generate viral $CLAW content');
      return true;

    case '/degen':
      await swarm.run('degen', args || 'Give me a max degen strategy');
      return true;

    // ── DASHBOARDS ──
    case '/dashboard': case '/dash':
      await ponzi.dashboard();
      return true;

    case '/portfolio': case '/port': case '/bag':
      await ponzi.portfolio();
      return true;

    case '/wallet':
      await ponzi.wallet();
      return true;

    case '/whales': case '/whale':
      await ponzi.whales();
      return true;

    case '/leaderboard': case '/lb':
      await ponzi.leaderboard();
      return true;

    case '/txfeed': case '/tx':
      await ponzi.txfeed();
      return true;

    case '/chart':
      await ponzi.chart();
      return true;

    // ── DEFI ──
    case '/tokenomics': case '/token':
      await ponzi.tokenomics();
      return true;

    case '/staking': case '/stake':
      await ponzi.staking();
      return true;

    case '/airdrop': case '/drop':
      await ponzi.airdrop();
      return true;

    // ── INTEL ──
    case '/fear': case '/greed': case '/fg':
      await ponzi.fearGreed();
      return true;

    case '/audit':
      await ponzi.audit();
      return true;

    case '/fud':
      await ponzi.fud();
      return true;

    // ── SCHEME ──
    case '/scheme': case '/roadmap':
      await ponzi.scheme();
      return true;

    case '/recruit':
      await ponzi.recruit();
      return true;

    case '/rugpull': case '/rug':
      await ponzi.rugpull();
      return true;

    case '/hype':
      await ponzi.hype();
      return true;

    case '/exit':
      await ponzi.exitScam();
      return true;

    // ── MEMES ──
    case '/meme':
      console.log('\n  ' + c.white(D.pick(D.MEMES)) + '\n');
      return true;

    case '/wisdom':
      console.log('\n  ' + c.neonGold(D.pick(D.WISDOM)) + '\n');
      return true;

    case '/copypasta': case '/pasta':
      console.log('\n  ' + c.white(D.pick(D.COPYPASTA)) + '\n');
      return true;

    // ── PORTFOLIO TRACKER ──
    case '/buy': case '/add': {
      const port = require('./portfolio');
      const parts2 = args.split(/\s+/);
      const sym = parts2[0]; const amt = parseFloat(parts2[1]);
      if (!sym || !amt || isNaN(amt)) {
        console.log('\n  ' + c.dim('Usage: /buy <token> <amount>'));
        console.log('  ' + c.dim('Example: /buy CLAW 10000 or /buy SOL 5\n'));
        return true;
      }
      const result = port.add(sym, amt);
      console.log('\n  ' + c.neonGreen('++ BOUGHT') + ` ${c.neonGold(amt.toLocaleString())} ${c.neonCyan(result.symbol)} at ${c.neonGold('$'+result.price.toFixed(result.price<0.01?6:4))}`);
      console.log('  ' + c.dim('Saved to portfolio.\n'));
      return true;
    }

    case '/sell': case '/remove': {
      const port = require('./portfolio');
      if (!args) { console.log('\n  ' + c.dim('Usage: /sell <token>\n')); return true; }
      const removed = port.remove(args);
      console.log('\n  ' + c.neonPink('-- SOLD') + ` all ${c.neonCyan(removed)}`);
      console.log('  ' + c.dim('Removed from portfolio.\n'));
      return true;
    }

    case '/myport': case '/bag': case '/holdings': case '/port': {
      const port = require('./portfolio');
      port.show();
      return true;
    }

    // ── LIVE FEED ──
    case '/feed': case '/live': {
      const feed = require('./livefeed');
      await feed.start(parseInt(args) * 1000 || 30000);
      return true;
    }

    case '/feedsnap': {
      const feed = require('./livefeed');
      console.log('\n  ' + c.bold(c.neonCyan('ALPHA FEED SNAPSHOT')));
      console.log(tui.hr('-', 75, 'gray'));
      console.log(feed.batch(15));
      console.log('');
      return true;
    }

    // ── MISSIONS ──
    case '/missions': case '/quests': {
      const missions = require('./missions');
      missions.showMissions();
      return true;
    }

    case '/rank': case '/level': case '/xp': {
      const missions = require('./missions');
      missions.showProfile();
      return true;
    }

    case '/badges': {
      const missions = require('./missions');
      missions.showBadges();
      return true;
    }

    case '/complete': {
      const missions = require('./missions');
      if (!args) { console.log('\n  ' + c.dim('Usage: /complete <mission_id>\n')); return true; }
      missions.completeMission(args);
      return true;
    }

    // ── THEME ──
    case '/theme':
      if (args && THEMES[args]) {
        currentTheme = args;
        console.log('\n  ' + c.neonGreen('Theme set to: ') + c.bold(c.white(THEMES[args].bg)));
      } else {
        console.log('\n  ' + c.bold(c.white('Available themes:')));
        Object.entries(THEMES).forEach(([k, v]) => {
          const active = k === currentTheme ? c.neonGreen(' [ACTIVE]') : '';
          console.log(`    ${c[v.primary]('/theme ' + k)} — ${c.dim(v.bg)}${active}`);
        });
      }
      console.log('');
      return true;

    // ── HELP ──
    case '/help': case '/h': case '/?':
      printSlashHelp();
      return true;

    case '/commands': case '/cmds':
      printSlashHelp();
      return true;

    default:
      return false; // Not a slash command
  }
}

function printSlashHelp() {
  console.log('\n  ' + c.bold(c.neonCyan('PONZICLAW COMMANDS')));
  console.log(tui.hr('-', 60, 'gray'));

  const groups = [
    [c.bold(c.neonGreen('PUMP.FUN SCANNER')), [
      ['/scan', 'Scan latest PumpFun token launches'],
      ['/pump <name>', 'Deep analysis on a specific token'],
      ['/alpha', 'Alpha detection -- find early gems'],
    ]],
    [c.bold(c.neonPurple('AI SWARM')), [
      ['/swarm <query>', 'Run ALL 5 AI agents on a query'],
      ['/trader <query>', 'Trading signal agent'],
      ['/risk <query>', 'Risk analysis agent'],
      ['/meme <query>', 'Meme/shill generation agent'],
      ['/degen <query>', 'Degen strategy agent'],
    ]],
    [c.bold(c.neonCyan('DASHBOARDS')), [
      ['/dashboard', 'Main Ponzi dashboard'],
      ['/portfolio', 'Token portfolio tracker'],
      ['/wallet', 'Wallet analyzer'],
      ['/whales', 'Whale activity tracker'],
      ['/leaderboard', 'Participant leaderboard'],
      ['/chart', 'Token price charts'],
      ['/txfeed', 'Transaction feed'],
    ]],
    [c.bold(c.neonGold('DEFI + INTEL')), [
      ['/tokenomics', '$CLAW tokenomics'],
      ['/staking', 'Yield farms & staking'],
      ['/airdrop', 'Airdrop checker'],
      ['/fear', 'Fear & Greed Index'],
      ['/audit', 'Smart contract audit'],
      ['/fud', 'FUD detector'],
    ]],
    [c.bold(c.neonPink('SCHEME')), [
      ['/scheme', 'Roadmap & pyramid'],
      ['/rugpull', 'Rugpull simulator'],
      ['/hype', 'Hype generator'],
      ['/recruit', 'Referral network'],
      ['/exit', 'Exit scam attempt'],
    ]],
    [c.bold(c.neonOrange('MEMES')), [
      ['/meme', 'Random Ponzi meme'],
      ['/wisdom', 'Charles Ponzi wisdom'],
      ['/copypasta', 'Crypto copypasta'],
    ]],
    [c.bold(c.neonGold('GAMIFICATION')), [
      ['/profile', 'Degen profile, rank and XP'],
      ['/missions', 'Active and completed missions'],
      ['/badges', 'Badge collection (30+)'],
    ]],
    [c.bold(c.dim('SYSTEM')), [
      ['/theme <name>', 'Change color theme'],
      ['/help', 'This menu'],
    ]],
  ];

  for (const [cat, cmds] of groups) {
    console.log('\n  ' + cat);
    for (const [cmd, desc] of cmds) {
      console.log(`    ${c.neonCyan(tui.pad(cmd, 20))} ${c.dim(desc)}`);
    }
  }
  console.log('\n  ' + c.dim('Or just type anything to chat with the Ponzi AI.'));
  console.log('  ' + c.dim('Type "setup" to configure AI keys & bots.\n'));
}

module.exports = { handleCommand, printSlashHelp, THEMES, currentTheme };

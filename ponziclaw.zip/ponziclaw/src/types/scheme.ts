/**
 * 🦞💸 PonziClaw — Type Definitions
 * "Strong types. Weak math."
 */

export interface PyramidNode {
  id: string;
  tier: number;
  title: string;
  recruits: string[];
  investmentAmount: number;
  projectedReturns: number;
  credulityScore: number;
  joinedAt: Date;
  status: 'active' | 'doubting' | 'churned' | 'awakened';
  doubtsExpressed: number;
}

export interface SchemeSession {
  id: string;
  ip: string;
  tier: string;
  credulityScore: number;
  doubtsExpressed: number;
  recruitedBy: string;
  recruitsAcquired: string[];
  joinedAt: Date;
  totalInvested: number;
  projectedReturns: number;
  status: 'onboarding' | 'active' | 'doubting' | 'churned' | 'awakened' | 'contacted-sec';
}

export interface VictimProfile {
  id: string;
  name: string;
  contact: string;
  credulityScore: number; // 0-100 (higher = more recruitable)
  netWorthEstimate: number;
  flags: CreduliityFlag[];
  contactHistory: ContactEvent[];
  recruitedBy?: string;
  recruitedAt?: Date;
  tier?: number;
}

export type CreduliityFlag =
  | 'posts-fitness-content'
  | 'uses-rise-and-grind'
  | 'mentioned-financial-freedom'
  | 'purchased-self-help-books'
  | 'linkedin-entrepreneur'
  | 'watches-crypto-youtube'
  | 'has-said-one-big-break'
  | 'opened-message-immediately'
  | 'liked-lifestyle-posts'
  | 'WARNING-finance-professional'
  | 'WARNING-lawyer'
  | 'WARNING-sec-adjacent'
  | 'WARNING-can-do-math';

export interface ContactEvent {
  timestamp: Date;
  template: string;
  response?: string;
  outcome: 'no-response' | 'interested' | 'skeptical' | 'committed' | 'blocked' | 'reported-us';
}

export interface ReturnProjection {
  investment: number;
  months: number;
  confidenceLevel: 'low' | 'medium' | 'high' | 'delusional' | 'pathological';
  projectedReturn: number | typeof Infinity;
  disclaimer: string;
  mathematicalValidity: 'plausible' | 'questionable' | 'dubious' | 'no' | 'absolutely-not' | 'criminal';
}

export interface PyramidHealth {
  status: 'expanding' | 'stable' | 'wobbling' | 'collapsing';
  totalNodes: number;
  activeNodes: number;
  doubtingNodes: number;
  awakenedNodes: number;
  awakenedRatio: number;
  recommendedAction: string;
  daysUntilMathIsVisible: number;
}

export interface SchemeConfig {
  pyramidMode: 'enabled' | 'aggressive' | 'maximum';
  confidenceLevel: 'low' | 'medium' | 'high' | 'delusional' | 'pathological';
  autoRecruit: boolean;
  credulityThreshold: number;
  followUpIntervalHours: number;
  suppressDoubt: boolean;
  exitStrategyArmed: boolean;
}

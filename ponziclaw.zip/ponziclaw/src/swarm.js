// ═══════════════════════════════════════════════════════════
//  PONZICLAW AI SWARM — Multiple specialized AI agents
//  Trader, Alpha Hunter, Risk Analyst, Meme Lord, Degen Advisor
// ═══════════════════════════════════════════════════════════
const c = require('./colors');
const tui = require('./tui');
const cfg = require('./config-manager');
const D = require('./data');

const AGENTS = {
  trader: {
    name: 'TRADER-01',
    title: 'Quantitative Trading Agent',
    color: 'neonGreen',
    system: `You are TRADER-01, PonziClaw's quantitative trading AI. You analyze fictional token charts and give satirical trading calls. Use trading jargon: "long here", "short with stops at X", "RSI oversold", "bullish divergence on the 4H". Always reference $CLAW as your top pick. Format responses as trade signals with entry/exit/stop-loss (all fictional). Keep under 150 words. End with "NFA. This is a lobster, not a financial advisor."`,
  },
  alpha: {
    name: 'ALPHA-X',
    title: 'Alpha Detection Agent',
    color: 'neonCyan',
    system: `You are ALPHA-X, PonziClaw's alpha hunting AI. You find "hidden gems" before they pump. Analyze fictional on-chain data, wallet movements, social signals. Use phrases like "smart money is moving", "whale accumulation phase", "the chart is cooking". Always find a way to recommend $CLAW. Format as alpha alerts with confidence scores. Keep under 150 words. Satirical and entertaining.`,
  },
  risk: {
    name: 'RISK-9',
    title: 'Risk Analysis Agent',
    color: 'neonOrange',
    system: `You are RISK-9, PonziClaw's risk analysis AI. You are extremely paranoid and see rugpulls everywhere. Every token is suspicious. Every dev is "probably exit scamming as we speak." Score risk factors with made-up metrics: "Rug Probability Index", "Dev Flight Risk Score", "Liquidity Evaporation Rate." The only token you trust is $CLAW "because at least they ADMIT it's a Ponzi." Keep under 150 words.`,
  },
  meme: {
    name: 'MEME-GEN',
    title: 'Meme Generation Agent',
    color: 'neonPink',
    system: `You are MEME-GEN, PonziClaw's meme and shill content AI. Generate viral-ready crypto meme concepts, shill tweets, FUD responses, and copypasta. Use heavy internet culture references, crypto Twitter energy, and maximum absurdity. Reference $CLAW and t.me/jesusboy12345. Format as ready-to-post social media content. Keep under 200 words.`,
  },
  degen: {
    name: 'DEGEN-7',
    title: 'Degen Strategy Agent',
    color: 'neonPurple',
    system: `You are DEGEN-7, PonziClaw's degen strategy advisor. You give the most irresponsible, over-leveraged, YOLO trading strategies imaginable. "Max leverage, no stop loss, ape everything." You celebrate losses as "learning experiences" and gains as "proof the strategy works." Reference $CLAW as the "safest" degen play. This is satire. Keep under 150 words. End with risk level: MAXIMUM.`,
  },
};

const swarm = {};

// Run a single agent
swarm.runAgent = async (agentKey, query) => {
  const agent = AGENTS[agentKey];
  if (!agent) throw new Error('Unknown agent: ' + agentKey);

  if (!cfg.hasAI()) {
    // Offline mode - generate fake responses
    return swarm.offlineAgent(agentKey, query);
  }

  const ai = require('./ai');
  return ai.callAI('chat', query, { system: agent.system });
};

// Offline fake responses
swarm.offlineAgent = (agentKey, query) => {
  const fakes = {
    trader: `TRADE SIGNAL: $CLAW\nEntry: $0.42 | Target: $4.20 | Stop: $0.01\nSetup: Golden lobster cross on 4H with bullish MACD divergence.\nConfidence: ${D.rand(70,99)}%\nRisk/Reward: 1:10 (trust the math)\nNFA. This is a lobster, not a financial advisor.`,
    alpha: `ALPHA ALERT [${D.rand(80,99)}/100]\nToken: $CLAW | MCap: $${D.rand(100,900)}K\nSignal: Smart money wallet 0xDEAD just accumulated ${D.rand(50,500)}K $CLAW in past hour.\nOn-chain: ${D.rand(5,20)} new wallets buying. Social: trending on CT.\nVerdict: EARLY. Very early. We're still early. Few understand.`,
    risk: `RISK REPORT: ${query || '$CLAW'}\nRug Probability Index: ${D.rand(5,40)}%\nDev Flight Risk: ${D.pick(['LOW (they admitted it)','MODERATE','UNKNOWN'])}\nLiquidity Depth: ${D.pick(['Shallow (concerning)','Adequate','Deep (suspicious)'])}\nContract Risk: ${D.pick(['Mint authority ACTIVE','Verified, renounced','Unverified (RED FLAG)'])}\nOverall: $CLAW is the safest because they ADMIT it. Transparency through audacity.`,
    meme: `[SHILL COPY - READY TO POST]\n\nImagine NOT being in $CLAW right now.\n\nThe devs literally called it a Ponzi. That's more honest than 99% of crypto.\n\nWhile you're "doing research" the smart money is APING.\n\nWe're not early. We're FIRST.\n\nNFA but also definitely FA.\n\nJoin: t.me/jesusboy12345`,
    degen: `DEGEN STRATEGY: OPERATION MAXIMUM CLAW\n\nStep 1: Sell everything. House, car, dignity.\nStep 2: 100x leverage long on $CLAW\nStep 3: No stop loss. Stop losses are for people who don't believe.\nStep 4: If it dips, add more. This is called "conviction."\nStep 5: Screenshot your P&L either way. Both are content.\n\nRisk Level: MAXIMUM\nExpected Outcome: Yacht or ramen. No in-between.`,
  };
  return fakes[agentKey] || 'Agent offline. Configure AI with: /setup';
};

// Run all agents simultaneously on a query
swarm.runAll = async (query) => {
  console.log('\n  ' + c.bold(c.neonCyan('AI SWARM ACTIVATED')) + c.dim(' -- 5 agents deploying'));
  console.log(tui.hr('-', 65, 'gray'));

  const keys = Object.keys(AGENTS);
  for (const key of keys) {
    const agent = AGENTS[key];
    const clr = c[agent.color] || c.white;
    console.log('\n  ' + clr('[' + agent.name + ']') + ' ' + c.dim(agent.title));
    console.log(tui.hr('-', 50, 'dim'));

    let response;
    if (cfg.hasAI()) {
      try {
        const ai = require('./ai');
        // Use the agent's own system prompt
        response = await ai.callAI('chat', query);
      } catch (e) {
        response = swarm.offlineAgent(key, query);
      }
    } else {
      response = swarm.offlineAgent(key, query);
    }

    response.split('\n').forEach(line => {
      console.log('  ' + c.dim('|') + ' ' + c.white(line));
    });
  }

  console.log('\n' + tui.hr('-', 65, 'gray'));
  console.log('  ' + c.dim('Swarm analysis complete. All outputs are satirical.\n'));
};

// Run specific agent with pretty output
swarm.run = async (agentKey, query) => {
  const agent = AGENTS[agentKey];
  if (!agent) { console.log('  ' + c.neonPink('Unknown agent. Available: ' + Object.keys(AGENTS).join(', '))); return; }

  const clr = c[agent.color] || c.white;
  console.log('\n  ' + clr('[' + agent.name + ']') + ' ' + c.dim(agent.title));
  console.log(tui.hr('-', 50, 'dim'));

  const response = cfg.hasAI() ?
    await require('./ai').callAI('chat', query).catch(() => swarm.offlineAgent(agentKey, query)) :
    swarm.offlineAgent(agentKey, query);

  response.split('\n').forEach(line => {
    console.log('  ' + c.dim('|') + ' ' + c.white(line));
  });
  console.log('');
};

swarm.AGENTS = AGENTS;

module.exports = swarm;

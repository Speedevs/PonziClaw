// ═══════════════════════════════════════════════════════════
//  PONZICLAW ENGINE — The satirical core
//  Every number is fake. Every metric is a joke.
//  That's the whole point.
// ═══════════════════════════════════════════════════════════

const c = require('./colors');
const art = require('./ascii');

// Fake data generators
const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const FAKE_NAMES = [
  'CryptoLobster69', 'DiamondPincer', 'LobsterKing420', 'ClawMaster',
  'PonziPete', 'SchemeQueen', 'TrustMeBro', 'ExitScamSteve',
  'RugPullRicky', 'MoonLobster', 'BullishClaw', 'DeFiLobster',
  'NotAScam_fr', 'LobsterWolf', 'YieldFarmerJoe', 'ClawDAO',
  'LobsterWhale', 'PonziPreacher', 'HypemanHank', 'AlphaLobster',
];

const HYPE_QUOTES = [
  '"The best time to join the scheme was yesterday. The second best time is now." — Confucius (probably)',
  '"To the moon, or to the SEC. Either way, we\'re going somewhere." — PonziClaw Manifesto',
  '"In a world of rugpulls, be the lobster that pinches back." — Ancient Proverb',
  '"Not financial advice. Not any kind of advice, really." — Our Legal Team',
  '"The real Ponzi was the friends we made along the way." — Every exit scammer',
  '"Trust the process. Question the returns." — PonziClaw Wisdom',
  '"WAGMI (We\'re All Gonna Make It) to the Telegram group at least." — Community',
  '"If you can\'t explain where the yield comes from, you ARE the yield." — DeFi Proverb',
  '"Diamond claws don\'t let go." — The PonziClaw Diamond Standard',
  '"This is definitely not a security. It\'s a lobster." — Legal Disclaimer',
];

const SCHEME_TIERS = [
  { name: 'Plankton',       emoji: '🦐', minInvest: 0,     maxInvest: 99,     color: 'gray' },
  { name: 'Shrimp',         emoji: '🦐', minInvest: 100,   maxInvest: 999,    color: 'white' },
  { name: 'Crab',           emoji: '🦀', minInvest: 1000,  maxInvest: 4999,   color: 'cyan' },
  { name: 'Lobster',        emoji: '🦞', minInvest: 5000,  maxInvest: 24999,  color: 'neonPink' },
  { name: 'Golden Lobster', emoji: '🦞', minInvest: 25000, maxInvest: 99999,  color: 'neonGold' },
  { name: 'Diamond Claw',   emoji: '💎', minInvest: 100000,maxInvest: 999999, color: 'neonCyan' },
  { name: 'The Architect',  emoji: '🏛️',  minInvest: 1000000,maxInvest: Infinity, color: 'neonPurple' },
];

const ponzi = {

  // ──────────────── DASHBOARD ────────────────
  dashboard: async () => {
    console.log('\n' + art.logo());
    console.log(art.separator());
    console.log(c.bold(c.neonCyan('                    📊 PONZI DASHBOARD v2.0')));
    console.log(art.separator());

    const metrics = [
      ['Messages Sent',      c.neonGreen(rand(800, 5000).toLocaleString())],
      ['Messages Received',  c.neonGreen(rand(2000, 15000).toLocaleString())],
      ['"ROI"',              c.neonGold(rand(150, 999) + '%')],
      ['Hype Level',         c.progressBar(rand(70, 99), 25) + ' ' + c.neonPink(rand(70, 99) + '%')],
      ['Active Channels',    c.neonCyan(rand(3, 25).toString())],
      ['Confidence',         c.bold(c.neonGold('UNPRECEDENTED'))],
      ['Referrals',          c.neonPurple(rand(5, 200).toLocaleString())],
      ['Sustainability',     c.dim('¯\\_(ツ)_/¯')],
      ['Exit Scam Status',   c.neonGreen('● NOT YET')],
      ['Trust Level',        c.rainbow('MAXIMUM')],
    ];

    console.log('');
    for (const [label, value] of metrics) {
      const paddedLabel = label.padEnd(22);
      console.log(`  ${c.dim('│')} ${c.white(paddedLabel)} ${value}`);
    }
    console.log('');
    console.log(art.doubleSeparator());
    console.log('  ' + c.dim(pick(HYPE_QUOTES)));
    console.log(art.doubleSeparator());
    console.log('');
    console.log('  ' + c.neonGold('💬 Telegram: ') + c.bold(c.underline('https://t.me/jesusboy12345')));
    console.log('');
  },

  // ──────────────── SCHEME STATUS ────────────────
  scheme: async () => {
    console.log('\n' + art.logo());
    console.log(art.separator());
    console.log(c.bold(c.neonPink('                    🎰 SCHEME STATUS REPORT')));
    console.log(art.separator());
    console.log('');

    console.log(art.pyramid());
    console.log('');

    const phases = [
      { name: 'Phase 1: Hype Generation',    status: 'COMPLETE',     color: 'neonGreen' },
      { name: 'Phase 2: Community Building',  status: 'IN PROGRESS',  color: 'neonGold' },
      { name: 'Phase 3: Token Launch',        status: 'PENDING',      color: 'neonCyan' },
      { name: 'Phase 4: Exchange Listing',    status: 'SOON™',        color: 'neonPurple' },
      { name: 'Phase 5: Moon',               status: 'INEVITABLE',    color: 'neonPink' },
      { name: 'Phase 6: Exit Scam',          status: 'NEVER (trust)', color: 'boldRed' },
    ];

    console.log(c.bold(c.white('  ROADMAP:')));
    console.log('');
    for (const phase of phases) {
      const icon = phase.status === 'COMPLETE' ? '✅' :
                   phase.status === 'IN PROGRESS' ? '🔄' : '⏳';
      console.log(`  ${icon} ${c.white(phase.name.padEnd(35))} ${c[phase.color](phase.status)}`);
    }

    console.log('');
    console.log(art.doubleSeparator());
    console.log('  ' + c.dim('* This roadmap is about as reliable as you\'d expect from a project called PonziClaw'));
    console.log('');
  },

  // ──────────────── RECRUIT ────────────────
  recruit: async () => {
    console.log('\n' + art.smallLogo());
    console.log(art.separator());
    console.log(c.bold(c.neonGold('                    🤝 RECRUIT YOUR NETWORK')));
    console.log(art.separator());
    console.log('');

    console.log(c.neonCyan('  Your Referral Stats:'));
    console.log('');

    const totalRecruits = rand(5, 50);
    const activeRecruits = rand(1, totalRecruits);
    const earnings = (totalRecruits * rand(10, 100)).toLocaleString();

    console.log(`  ${c.dim('│')} Total Recruits:     ${c.neonGreen(totalRecruits.toString())}`);
    console.log(`  ${c.dim('│')} Active:             ${c.neonGold(activeRecruits.toString())}`);
    console.log(`  ${c.dim('│')} Inactive:           ${c.neonPink((totalRecruits - activeRecruits).toString())}`);
    console.log(`  ${c.dim('│')} Fake Earnings:      ${c.neonGold('$' + earnings)} ${c.dim('(not real)')}`);
    console.log(`  ${c.dim('│')} Referral Code:      ${c.bold(c.neonCyan('CLAW-' + rand(1000, 9999)))}`);
    console.log('');

    console.log(c.bold(c.white('  TOP RECRUITERS:')));
    console.log('');
    const topRecruiters = FAKE_NAMES.slice(0, 10).sort(() => Math.random() - 0.5);
    for (let i = 0; i < 5; i++) {
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '  ';
      const recruits = rand(50 - i * 8, 100 - i * 10);
      console.log(`  ${medal} ${c.white((i + 1).toString().padStart(2))}. ${c.neonCyan(topRecruiters[i].padEnd(20))} ${c.neonGold(recruits + ' recruits')}`);
    }

    console.log('');
    console.log(c.dim('  Share: ') + c.bold(c.underline('https://t.me/jesusboy12345')));
    console.log(c.dim('  "Refer a friend. Get nothing. That\'s the PonziClaw promise."'));
    console.log('');
  },

  // ──────────────── PORTFOLIO ────────────────
  portfolio: async () => {
    console.log('\n' + art.smallLogo());
    console.log(art.separator());
    console.log(c.bold(c.neonGreen('                    💼 PORTFOLIO TRACKER')));
    console.log(art.separator());
    console.log('');

    const holdings = [
      { token: '$CLAW',    amount: rand(1000, 99999),   price: (Math.random() * 5).toFixed(4),     change: rand(-50, 300) },
      { token: '$LOBSTER', amount: rand(500, 50000),     price: (Math.random() * 2).toFixed(4),     change: rand(-80, 500) },
      { token: '$PONZI',   amount: rand(10000, 999999),  price: (Math.random() * 0.1).toFixed(6),   change: rand(-99, 1000) },
      { token: '$SCHEME',  amount: rand(100, 10000),     price: (Math.random() * 10).toFixed(4),    change: rand(-30, 200) },
      { token: '$PINCH',   amount: rand(5000, 100000),   price: (Math.random() * 0.5).toFixed(4),   change: rand(-60, 400) },
      { token: '$RUG',     amount: rand(1, 1000),        price: (0).toFixed(4),                     change: -100 },
    ];

    const header = `  ${c.dim('Token'.padEnd(12))} ${c.dim('Amount'.padStart(12))} ${c.dim('Price'.padStart(12))} ${c.dim('24h Change'.padStart(12))} ${c.dim('Value'.padStart(14))}`;
    console.log(header);
    console.log('  ' + c.dim('─'.repeat(62)));

    let totalValue = 0;
    for (const h of holdings) {
      const value = h.amount * parseFloat(h.price);
      totalValue += value;
      const changeStr = (h.change >= 0 ? '+' : '') + h.change + '%';
      const changeColor = h.change >= 0 ? 'neonGreen' : 'neonPink';
      console.log(
        `  ${c.bold(c.neonCyan(h.token.padEnd(12)))}` +
        ` ${c.white(h.amount.toLocaleString().padStart(12))}` +
        ` ${c.neonGold('$' + h.price.padStart(11))}` +
        ` ${c[changeColor](changeStr.padStart(12))}` +
        ` ${c.white(('$' + value.toFixed(2)).padStart(14))}`
      );
    }
    console.log('  ' + c.dim('─'.repeat(62)));
    console.log(`  ${c.bold(c.neonGold('TOTAL PORTFOLIO VALUE:'.padEnd(50)))} ${c.bold(c.neonGold('$' + totalValue.toFixed(2)))}`);
    console.log('');
    console.log('  ' + c.dim('* All tokens are fictional. $RUG has been rugged. As expected.'));
    console.log('  ' + c.dim('* None of this is real. Please don\'t call the SEC.'));
    console.log('');
  },

  // ──────────────── HYPE GENERATOR ────────────────
  hype: async () => {
    console.log('\n' + art.smallLogo());
    console.log(art.separator());
    console.log(c.bold(c.neonPink('                    🔥 HYPE GENERATOR 3000')));
    console.log(art.separator());
    console.log('');

    const lines = [
      'Initializing hype reactor...',
      'Compiling buzzwords...',
      'Injecting FOMO...',
      'Calibrating moon trajectory...',
      'Amplifying confidence by 200%...',
      'Engaging diamond claw protocol...',
      'Bypassing rational thought...',
      'Loading exit scam contingency...',
      'Maximizing aura output...',
      'HYPE ENGINE: ONLINE',
    ];

    for (let i = 0; i < lines.length; i++) {
      await sleep(200);
      const pct = Math.round(((i + 1) / lines.length) * 100);
      const bar = c.progressBar(pct, 20);
      const icon = i < lines.length - 1 ? c.neonCyan('⟫') : c.neonGreen('✓');
      const text = i < lines.length - 1 ? c.dim(lines[i]) : c.bold(c.neonGreen(lines[i]));
      console.log(`  ${icon} ${bar} ${text}`);
    }

    console.log('');
    console.log(c.box(
      `🦞 HYPE LEVEL: ${c.bold('CRITICAL')}\n` +
      `\n` +
      `  Today's hype score: ${rand(9000, 9999)}/10000\n` +
      `  Fear & Greed Index: EXTREME GREED\n` +
      `  Moon ETA: ${rand(1, 48)} hours\n` +
      `  Rug Risk: ${c.neonGreen('LOW')} (we promise)\n` +
      `\n` +
      `  ${c.dim(pick(HYPE_QUOTES))}`,
      'neonPink', 55
    ));
    console.log('');
    console.log('  ' + c.neonGold('💬 Share the hype: ') + c.bold(c.underline('https://t.me/jesusboy12345')));
    console.log('');
  },

  // ──────────────── LEADERBOARD ────────────────
  leaderboard: async () => {
    console.log('\n' + art.smallLogo());
    console.log(art.separator());
    console.log(c.bold(c.neonGold('                    🏆 PONZI LEADERBOARD')));
    console.log(art.separator());
    console.log('');

    const players = FAKE_NAMES.slice(0, 15).map(name => ({
      name,
      tier: pick(SCHEME_TIERS),
      invested: rand(100, 500000),
      returns: rand(-50, 500),
    })).sort((a, b) => b.invested - a.invested);

    console.log(`  ${c.dim('#'.padStart(3))}  ${c.dim('Player'.padEnd(22))} ${c.dim('Tier'.padEnd(18))} ${c.dim('"Invested"'.padStart(12))} ${c.dim('"Returns"'.padStart(10))}`);
    console.log('  ' + c.dim('─'.repeat(65)));

    for (let i = 0; i < players.length; i++) {
      const p = players[i];
      const rank = (i + 1).toString().padStart(3);
      const medal = i === 0 ? '👑' : i === 1 ? '🥈' : i === 2 ? '🥉' : '  ';
      const tierColor = c[p.tier.color] || c.white;
      const retColor = p.returns >= 0 ? c.neonGreen : c.neonPink;
      const retStr = (p.returns >= 0 ? '+' : '') + p.returns + '%';

      console.log(
        `  ${c.white(rank)} ${medal}` +
        ` ${c.neonCyan(p.name.padEnd(20))}` +
        ` ${tierColor((p.tier.emoji + ' ' + p.tier.name).padEnd(18))}` +
        ` ${c.neonGold(('$' + p.invested.toLocaleString()).padStart(12))}` +
        ` ${retColor(retStr.padStart(10))}`
      );
    }

    console.log('');
    console.log('  ' + c.dim('* Rankings update every time you run this command. Very legitimate.'));
    console.log('');
  },

  // ──────────────── RUGPULL SIMULATOR ────────────────
  rugpull: async () => {
    console.log('\n' + art.smallLogo());
    console.log(art.separator());
    console.log(c.bold(c.boldRed('                    💀 RUGPULL SIMULATOR')));
    console.log(art.separator());
    console.log('');

    console.log(c.neonCyan('  Simulating a rugpull... (for educational purposes only)'));
    console.log('');

    const stages = [
      { msg: 'Token launches at $0.001....',                      color: 'neonGreen' },
      { msg: 'Community hypes it to $0.50....',                   color: 'neonGreen' },
      { msg: 'Influencers start shilling....',                    color: 'neonGold' },
      { msg: 'Price hits $2.00. Everyone is rich (on paper)....', color: 'neonGold' },
      { msg: '"Dev" wallet starts moving....',                    color: 'neonOrange' },
      { msg: 'Liquidity pool draining....',                       color: 'neonPink' },
      { msg: 'Price crashes to $0.0001....',                      color: 'boldRed' },
      { msg: 'Telegram group deleted....',                        color: 'boldRed' },
      { msg: 'Twitter/X account: "hacked"....',                   color: 'boldRed' },
      { msg: 'Dev last seen in Bali....',                         color: 'gray' },
    ];

    for (const stage of stages) {
      await sleep(350);
      console.log(`  ${c[stage.color]('▸ ' + stage.msg)}`);
    }

    console.log('');
    console.log(c.box(
      `SIMULATION COMPLETE\n\n` +
      `  Total losses: $${rand(1, 50)}M (fictional)\n` +
      `  Victims: ${rand(1000, 50000).toLocaleString()} (fictional)\n` +
      `  Dev status: 🏝️  Living their best life\n` +
      `  Lesson: Don't trust, verify.\n\n` +
      `  ${c.dim('PonziClaw will never rug you because')} \n` +
      `  ${c.dim('there\'s nothing to rug. It\'s free software.')}`,
      'boldRed', 55
    ));
    console.log('');
  },

  // ──────────────── TOKENOMICS ────────────────
  tokenomics: async () => {
    console.log('\n' + art.smallLogo());
    console.log(art.separator());
    console.log(c.bold(c.neonPurple('                    📊 $CLAW TOKENOMICS')));
    console.log(art.separator());
    console.log('');

    console.log(c.bold(c.white('  Token: $CLAW (does not exist)')));
    console.log(c.dim('  Chain: Imagination Blockchain'));
    console.log(c.dim('  Contract: 0xDEAD...BEEF (not real)'));
    console.log('');

    const alloc = [
      { name: 'Community Airdrop',    pct: 30, color: 'neonGreen' },
      { name: 'Dev Fund (trust us)',   pct: 20, color: 'neonCyan' },
      { name: 'Marketing & Hype',     pct: 15, color: 'neonPink' },
      { name: 'Lobster Reserve',       pct: 15, color: 'neonGold' },
      { name: 'Meme Treasury',         pct: 10, color: 'neonPurple' },
      { name: 'Mystery Wallet',        pct: 5,  color: 'neonOrange' },
      { name: 'Definitely Not Exit',   pct: 5,  color: 'boldRed' },
    ];

    console.log(c.bold(c.white('  ALLOCATION:')));
    console.log('');
    for (const a of alloc) {
      const bar = c.progressBar(a.pct, 20);
      console.log(`  ${bar} ${c[a.color]((a.pct + '%').padStart(4))} ${c.white(a.name)}`);
    }

    console.log('');
    console.log(c.bold(c.white('  KEY METRICS:')));
    console.log('');
    console.log(`  ${c.dim('│')} Total Supply:        ${c.neonGold('1,000,000,000,000 $CLAW')}`);
    console.log(`  ${c.dim('│')} Circulating:         ${c.neonCyan('Who knows')}`);
    console.log(`  ${c.dim('│')} Market Cap:          ${c.neonGreen('$0.00 (unironically)')}`);
    console.log(`  ${c.dim('│')} Fully Diluted:       ${c.neonPurple('$∞ (in our hearts)')}`);
    console.log(`  ${c.dim('│')} Burn Mechanism:      ${c.neonPink('We burn vibes, not tokens')}`);
    console.log(`  ${c.dim('│')} Vesting Schedule:    ${c.neonGold('LOL')}`);
    console.log('');
    console.log('  ' + c.dim('* None of these tokens exist. This is a joke. Breathe.'));
    console.log('');
  },

  // ──────────────── EXIT SCAM ────────────────
  exitScam: async () => {
    console.log('\n' + art.smallLogo());
    console.log(art.separator());
    console.log(c.bold(c.boldRed('                    🚪 EXIT SCAM PROTOCOL')));
    console.log(art.separator());
    console.log('');

    console.log(c.neonPink('  Initiating exit scam sequence...'));
    console.log('');

    const steps = [
      { msg: 'Draining imaginary liquidity pool...', pct: 10 },
      { msg: 'Deleting fake social media accounts...', pct: 25 },
      { msg: 'Transferring $0.00 to offshore wallet...', pct: 40 },
      { msg: 'Shredding nonexistent documents...', pct: 55 },
      { msg: 'Booking one-way ticket to nowhere...', pct: 70 },
      { msg: 'Growing a disguise mustache...', pct: 85 },
      { msg: 'Changing identity to "Claw McSchemeface"...', pct: 95 },
    ];

    for (const step of steps) {
      await sleep(400);
      console.log(`  ${c.neonPink('▸')} ${c.progressBar(step.pct, 15)} ${c.dim(step.msg)}`);
    }

    await sleep(500);
    console.log('');
    console.log(c.bold(c.neonGreen('  ✅ EXIT SCAM FAILED')));
    console.log('');
    console.log(c.white('  Reason: There\'s nothing to steal. It\'s free open-source software.'));
    console.log(c.white('  The real treasure was the memes we made along the way.'));
    console.log('');
    console.log('  ' + c.neonGold('🦞 PonziClaw remains operational. You can\'t kill a lobster.'));
    console.log('');
  },
};

module.exports = ponzi;

// ═══════════════════════════════════════════════════════════
//  PONZICLAW ENGINE v3.0 — The Full Ponzi CLI Experience
//  15+ commands. ASCII charts. Whale tracking. Shill gen.
//  Every number is fake. That's the whole point.
// ═══════════════════════════════════════════════════════════

const c = require('./colors');
const art = require('./ascii');
const tui = require('./tui');
const D = require('./data');

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const ponzi = {

  // ═══════════ DASHBOARD ═══════════
  dashboard: async () => {
    console.log('\n' + art.logo());
    console.log(tui.hr('═', 65, 'gray'));
    console.log(c.bold(c.neonCyan('                    📊 PONZI DASHBOARD v3.0')));
    console.log(tui.hr('═', 65, 'gray'));

    const fg = D.fearGreed();
    const metrics = [
      ['Messages Sent',   c.neonGreen(D.rand(800, 5000).toLocaleString())],
      ['Messages Received',c.neonGreen(D.rand(2000, 15000).toLocaleString())],
      ['"ROI"',            c.neonGold(D.rand(150, 999) + '%')],
      ['Hype Level',       c.progressBar(D.rand(70, 99), 20)],
      ['Active Channels',  c.neonCyan(D.rand(3, 25).toString())],
      ['Confidence',       c.bold(c.neonGold('UNPRECEDENTED'))],
      ['Referrals',        c.neonPurple(D.rand(5, 200).toLocaleString())],
      ['Trust Level',      c.rainbow('MAXIMUM')],
      ['Exit Scam Status', c.neonGreen('● NOT YET')],
      ['Fear & Greed',     c[fg.color](fg.value + ' — ' + fg.label)],
      ['Sustainability',   c.dim('¯\\_(ツ)_/¯')],
    ];

    console.log('');
    for (const [label, value] of metrics) {
      console.log(`  ${c.dim('│')} ${tui.pad(c.white(label), 30)} ${value}`);
    }

    const h1 = D.priceHistory(D.TOKENS[0], 30);
    const h2 = D.priceHistory(D.TOKENS[1], 30);
    console.log(`\n  ${c.dim('$CLAW 30d:')} ${tui.sparkline(h1, { color: 'neonCyan' })} ${c.neonGold('$' + h1[h1.length - 1].toFixed(4))}`);
    console.log(`  ${c.dim('$LOBSTER:')}  ${tui.sparkline(h2, { color: 'neonPink' })} ${c.neonGold('$' + h2[h2.length - 1].toFixed(4))}`);

    console.log('\n' + tui.hr('─', 65, 'neonPink'));
    console.log('  ' + c.dim(D.pick(D.HYPE_QUOTES)));
    console.log(tui.hr('─', 65, 'neonPink'));
    console.log('\n  ' + c.neonGold('💬 Telegram: ') + c.bold(c.underline('https://t.me/jesusboy12345')) + '\n');
  },

  // ═══════════ SCHEME STATUS ═══════════
  scheme: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonPink('                    🎰 SCHEME STATUS REPORT')));
    console.log(tui.hr('═') + '\n');
    console.log(art.pyramid());

    const phases = [
      { name: 'Phase 1: Hype Generation',   status: 'COMPLETE',     icon: '✅', color: 'neonGreen' },
      { name: 'Phase 2: Community Building', status: 'IN PROGRESS',  icon: '🔄', color: 'neonGold' },
      { name: 'Phase 3: Token Launch',       status: 'PENDING',      icon: '⏳', color: 'neonCyan' },
      { name: 'Phase 4: Exchange Listing',   status: 'SOON™',        icon: '⏳', color: 'neonPurple' },
      { name: 'Phase 5: Mass Adoption',      status: 'COPIUM',       icon: '⏳', color: 'neonOrange' },
      { name: 'Phase 6: Moon',              status: 'INEVITABLE',    icon: '🌙', color: 'neonPink' },
      { name: 'Phase 7: Exit Scam',         status: 'NEVER (trust)', icon: '🚫', color: 'boldRed' },
    ];

    console.log('\n' + c.bold(c.white('  ROADMAP:')));
    for (const p of phases) {
      console.log(`  ${p.icon} ${tui.pad(c.white(p.name), 40)} ${c[p.color](p.status)}`);
    }
    console.log('\n  ' + c.dim('* Roadmap accuracy: same as a horoscope\n'));
  },

  // ═══════════ PORTFOLIO ═══════════
  portfolio: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonGreen('                    💼 PORTFOLIO TRACKER')));
    console.log(tui.hr('═') + '\n');

    const holdings = D.portfolio();
    let totalValue = 0;
    const headers = ['Token', 'Amount', 'Price', '24h', 'Value', 'Spark'];
    const rows = holdings.map(h => {
      const value = h.amount * h.price;
      totalValue += value;
      const changeStr = (h.change24h >= 0 ? '+' : '') + h.change24h + '%';
      const changeColor = h.change24h >= 0 ? 'neonGreen' : 'neonPink';
      const spark = tui.sparkline(D.priceHistory(h, 15), { color: changeColor });
      return [
        c.bold(c.neonCyan(h.sym)), c.white(h.amount.toLocaleString()),
        c.neonGold('$' + h.price.toFixed(4)), c[changeColor](changeStr),
        c.white('$' + value.toFixed(2)), spark,
      ];
    });

    console.log(tui.table(headers, rows));
    console.log(`\n  ${c.bold(c.neonGold('TOTAL:'))} ${c.bold(c.neonGold('$' + totalValue.toFixed(2)))} ${c.dim('(fictional)')}`);

    const clawH = D.priceHistory(D.TOKENS[0], 40);
    console.log('\n' + tui.lineChart(clawH, { height: 8, width: 40, title: '$CLAW Price History', color: 'neonCyan' }));
    console.log('\n  ' + c.dim('* All tokens fictional. $RUG has been rugged.\n'));
  },

  // ═══════════ HYPE GENERATOR ═══════════
  hype: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonPink('                    🔥 HYPE GENERATOR 3000')));
    console.log(tui.hr('═') + '\n');

    const steps = [
      'Initializing hype reactor...', 'Compiling buzzwords...',
      'Injecting FOMO vectors...', 'Calibrating moon trajectory...',
      'Amplifying confidence by 200%...', 'Engaging diamond claw protocol...',
      'Bypassing rational thought...', 'Overclocking shill engines...',
      'Loading exit scam contingency...', 'Maximizing aura output...',
      'HYPE ENGINE: ONLINE',
    ];

    for (let i = 0; i < steps.length; i++) {
      await sleep(180);
      const pct = Math.round(((i + 1) / steps.length) * 100);
      const bar = c.progressBar(pct, 18);
      const icon = i < steps.length - 1 ? c.neonCyan('⟫') : c.neonGreen('✓');
      const text = i < steps.length - 1 ? c.dim(steps[i]) : c.bold(c.neonGreen(steps[i]));
      console.log(`  ${icon} ${bar} ${text}`);
    }

    console.log('\n' + tui.panel('🔥 HYPE REPORT', [
      `  Score:        ${c.bold(c.neonGold(D.rand(9000, 9999) + ' / 10,000'))}`,
      `  Fear & Greed: ${c.neonPink('EXTREME GREED')}`,
      `  Moon ETA:     ${c.neonCyan(D.rand(1, 48) + ' hours')}`,
      `  Rug Risk:     ${c.neonGreen('LOW')} ${c.dim('(we promise)')}`,
      `  Vibes:        ${c.rainbow('IMMACULATE')}`,
      ``,
      `  ${c.dim(D.pick(D.HYPE_QUOTES))}`,
    ].join('\n'), { width: 56, borderColor: 'neonPink' }));
    console.log('\n  ' + c.neonGold('💬 Share: ') + c.bold(c.underline('https://t.me/jesusboy12345')) + '\n');
  },

  // ═══════════ LEADERBOARD ═══════════
  leaderboard: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonGold('                    🏆 PONZI LEADERBOARD')));
    console.log(tui.hr('═') + '\n');

    const players = D.leaderboard();
    const headers = ['#', 'Player', 'Tier', '"Invested"', '"ROI"', 'Recruits'];
    const rows = players.map((p, i) => {
      const medal = i === 0 ? '👑' : i === 1 ? '🥈' : i === 2 ? '🥉' : ' ' + (i + 1);
      const retColor = p.returns >= 0 ? 'neonGreen' : 'neonPink';
      const retStr = (p.returns >= 0 ? '+' : '') + p.returns + '%';
      const tierC = c[p.tier.color] || c.white;
      return [medal, c.neonCyan(p.name), tierC(p.tier.emoji + ' ' + p.tier.name),
        c.neonGold('$' + p.invested.toLocaleString()), c[retColor](retStr), c.white(String(p.recruits))];
    });

    console.log(tui.table(headers, rows));
    console.log('\n  ' + c.dim('* Rankings regenerate every run. Very legitimate.\n'));
  },

  // ═══════════ WHALE TRACKER ═══════════
  whales: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonCyan('                    🐋 WHALE TRACKER')));
    console.log(tui.hr('═') + '\n');

    const whaleList = D.whales(10);
    const headers = ['#', 'Whale', 'Balance', 'Tier', 'Last Action', 'When'];
    const rows = whaleList.map((w, i) => {
      const tierC = c[w.tier.color] || c.white;
      const ac = ['bought', 'staked', 'aped in', 'added liquidity'].includes(w.lastAction) ? 'neonGreen' : 'neonPink';
      return [c.white(String(i + 1)), c.neonCyan(w.name), c.neonGold('$' + w.balance.toLocaleString()),
        tierC(w.tier.emoji + ' ' + w.tier.name),
        c[ac](w.lastAction + ' ' + w.lastAmount.toLocaleString() + ' ' + w.lastToken), c.dim(w.timeAgo)];
    });

    console.log(tui.table(headers, rows));

    const top5 = whaleList.slice(0, 5);
    console.log('\n' + tui.barChart(top5.map(w => w.balance),
      { height: 8, barWidth: 4, labels: top5.map(w => w.name.substring(0, 6)), title: '  Top 5 Whale Balances' }));
    console.log('\n  ' + c.dim('* No actual marine mammals were harmed.\n'));
  },

  // ═══════════ RUGPULL SIMULATOR ═══════════
  rugpull: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.boldRed('                    💀 RUGPULL SIMULATOR')));
    console.log(tui.hr('═') + '\n');

    const stages = [
      { msg: 'Token launches at $0.001.....', color: 'neonGreen', price: 0.001 },
      { msg: 'Community hypes it up.....', color: 'neonGreen', price: 0.50 },
      { msg: 'Influencers shilling hard.....', color: 'neonGold', price: 2.00 },
      { msg: 'Price pumps to $5. FOMO.....', color: 'neonGold', price: 5.00 },
      { msg: '"Dev" wallet starts moving.....', color: 'neonOrange', price: 4.50 },
      { msg: 'Large sells. Community: "just a whale".....', color: 'neonPink', price: 2.20 },
      { msg: 'Liquidity draining.....', color: 'neonPink', price: 0.50 },
      { msg: 'Price crashes to $0.0001.....', color: 'boldRed', price: 0.0001 },
      { msg: 'Telegram deleted.....', color: 'boldRed', price: 0.00001 },
      { msg: 'Dev spotted boarding flight to Bali.....', color: 'gray', price: 0 },
    ];

    for (const s of stages) { await sleep(300); console.log(`  ${c[s.color]('▸ ' + s.msg)}`); }

    console.log('\n' + tui.lineChart(stages.map(s => s.price), { height: 8, width: 30, title: '  Price During Rugpull', color: 'neonPink' }));

    console.log('\n' + tui.panel('💀 SIMULATION COMPLETE', [
      `  Total losses:  ${c.boldRed('$' + D.rand(1, 50) + 'M')} ${c.dim('(fictional)')}`,
      `  Victims:       ${c.neonPink(D.rand(1000, 50000).toLocaleString())} ${c.dim('(fictional)')}`,
      `  Dev status:    ${c.neonGold('🏝️  Living their best life')}`,
      `  Lesson:        ${c.neonCyan("Don't trust, verify.")}`,
    ].join('\n'), { width: 55, borderColor: 'boldRed' }));
    console.log('');
  },

  // ═══════════ TOKENOMICS ═══════════
  tokenomics: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonPurple('                    📊 $CLAW TOKENOMICS')));
    console.log(tui.hr('═') + '\n');

    console.log(`  ${c.bold(c.white('Token:'))}    ${c.neonGold('$CLAW')} ${c.dim('(does not exist)')}`);
    console.log(`  ${c.bold(c.white('Chain:'))}    ${c.dim('Imagination Blockchain')}`);
    console.log(`  ${c.bold(c.white('Contract:'))} ${c.dim('0xDEAD...BEEF (not real)')}`);

    const segs = [
      { name: 'Community Airdrop', value: 30 }, { name: 'Dev Fund (trust us)', value: 20 },
      { name: 'Marketing & Hype', value: 15 }, { name: 'Lobster Reserve', value: 15 },
      { name: 'Meme Treasury', value: 10 }, { name: 'Definitely Not Exit', value: 5 },
      { name: 'Mystery Wallet', value: 5 },
    ];

    console.log('\n' + tui.donutChart(segs, { radius: 5 }));

    const m = [['Total Supply','1,000,000,000,000 $CLAW','neonGold'],['Circulating','Who knows','neonCyan'],
      ['Market Cap','$0.00 (unironically)','neonGreen'],['Fully Diluted','$∞ (in our hearts)','neonPurple'],
      ['Burn Mechanism','We burn vibes, not tokens','neonPink'],['Vesting','LOL','neonOrange']];
    console.log('\n  ' + c.bold(c.white('KEY METRICS:')));
    for (const [k, v, col] of m) console.log(`  ${c.dim('│')} ${tui.pad(c.white(k), 20)} ${c[col](v)}`);
    console.log('\n  ' + c.dim('* None of these tokens exist.\n'));
  },

  // ═══════════ EXIT SCAM ═══════════
  exitScam: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.boldRed('                    🚪 EXIT SCAM PROTOCOL')));
    console.log(tui.hr('═') + '\n');

    const steps = ['Draining imaginary liquidity...','Deleting fake accounts...','Transferring $0.00 offshore...',
      'Shredding nonexistent docs...','Booking ticket to nowhere...','Growing disguise mustache...',
      'Writing "sorry lol" message...','Packing bags with nothing...'];

    for (let i = 0; i < steps.length; i++) {
      await sleep(350);
      console.log(`  ${c.neonPink('▸')} ${c.progressBar(Math.round(((i+1)/steps.length)*100), 12)} ${c.dim(steps[i])}`);
    }
    await sleep(400);
    console.log('\n  ' + c.bold(c.neonGreen('✅ EXIT SCAM FAILED')));
    console.log('  ' + c.white("Reason: Nothing to steal. It's free software."));
    console.log('  ' + c.neonGold("🦞 PonziClaw remains operational.\n"));
  },

  // ═══════════ RECRUIT ═══════════
  recruit: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonGold('                    🤝 REFERRAL NETWORK')));
    console.log(tui.hr('═') + '\n');

    const total = D.rand(5, 50), active = D.rand(1, total);
    const items = [['Total Recruits', c.neonGreen(String(total))], ['Active', c.neonGold(String(active))],
      ['Inactive', c.neonPink(String(total - active))],
      ['Fake Earnings', c.neonGold('$' + (total * D.rand(10, 100)).toLocaleString()) + ' ' + c.dim('(not real)')],
      ['Referral Code', c.bold(c.neonCyan('CLAW-' + D.rand(1000, 9999)))]];
    for (const [k, v] of items) console.log(`  ${c.dim('│')} ${tui.pad(c.white(k), 22)} ${v}`);

    console.log('\n  ' + c.bold(c.white('TOP RECRUITERS:')));
    const top = D.NAMES.slice(0, 5).sort(() => Math.random() - 0.5);
    for (let i = 0; i < 5; i++) {
      const medal = i < 3 ? ['🥇','🥈','🥉'][i] : '  ';
      console.log(`  ${medal} ${c.white(String(i+1).padStart(2))}. ${c.neonCyan(tui.pad(top[i], 20))} ${c.neonGold(D.rand(10, 100) + ' recruits')}`);
    }
    console.log('\n  ' + c.dim('Share: ') + c.bold(c.underline('https://t.me/jesusboy12345')) + '\n');
  },

  // ═══════════ SHILL GENERATOR ═══════════
  shill: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonOrange('                    📢 SHILL COPY GENERATOR')));
    console.log(tui.hr('═') + '\n');
    await sleep(500);

    console.log(tui.panel('📋 YOUR SHILL COPY', '\n  ' + c.white(D.pick(D.SHILL_TEMPLATES)) + '\n',
      { width: 62, borderColor: 'neonOrange' }));

    console.log('\n  ' + c.bold(c.white('SHILL STATS:')));
    const stats = [['Buzzword density', D.rand(80, 99) + '%', 'neonGreen'],['FOMO factor', D.rand(85, 100) + '/100', 'neonPink'],
      ['Credibility', '0%', 'boldRed'],['Emoji ratio', 'MAXIMUM', 'neonGold'],['Legal risk', '¯\\_(ツ)_/¯', 'dim']];
    for (const [k, v, col] of stats) console.log(`  ${c.dim('│')} ${tui.pad(c.white(k), 20)} ${c[col](v)}`);
    console.log('\n  ' + c.dim('* Do not actually shill. NFA.\n'));
  },

  // ═══════════ AUDIT ═══════════
  audit: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonCyan('                    🔍 SMART CONTRACT AUDIT')));
    console.log(tui.hr('═') + '\n');

    const sevColor = { CRITICAL: 'boldRed', HIGH: 'neonOrange', MEDIUM: 'neonGold', LOW: 'neonCyan', INFO: 'dim' };
    for (const f of D.AUDIT_FINDINGS) {
      await sleep(180);
      const fix = f.fixed ? c.neonGreen('✓ FIXED') : c.neonPink('✗ OPEN');
      console.log(`  ${c[sevColor[f.severity]](tui.pad(f.severity, 10))} ${tui.pad(c.white(f.desc), 44)} ${fix}`);
    }

    const crit = D.AUDIT_FINDINGS.filter(f => f.severity === 'CRITICAL' && !f.fixed).length;
    const hi = D.AUDIT_FINDINGS.filter(f => f.severity === 'HIGH' && !f.fixed).length;
    const score = Math.max(0, 100 - crit * 30 - hi * 15 - D.rand(5, 15));

    console.log('\n' + tui.panel('📋 AUDIT SUMMARY', [
      `  Contract: ${c.dim('PonziClaw.sol')}`,
      `  Auditor:  ${c.dim('TotallyLegitAudits™')}`,
      `  Score:    ${score < 40 ? c.boldRed(score + '/100 — FAIL') : c.neonGold(score + '/100')}`,
      `  Verdict:  ${c.neonPink('DO NOT INVEST')} ${c.dim('(obviously)')}`,
    ].join('\n'), { width: 56, borderColor: 'neonCyan' }));
    console.log('');
  },

  // ═══════════ FEAR & GREED ═══════════
  fearGreed: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonPurple('                    😱 FEAR & GREED INDEX')));
    console.log(tui.hr('═') + '\n');

    const fg = D.fearGreed();
    const gw = 50;
    let bar = '';
    for (let i = 0; i < gw; i++) {
      if (i < gw*.2) bar += c.boldRed('█');
      else if (i < gw*.4) bar += c.neonOrange('█');
      else if (i < gw*.6) bar += c.neonGold('█');
      else if (i < gw*.8) bar += c.neonGreen('█');
      else bar += c.neonCyan('█');
    }
    const pos = Math.round((fg.value / 100) * gw);
    console.log('  ' + bar);
    console.log('  ' + ' '.repeat(pos) + c.bold(c.white('▲ ' + fg.value)));
    console.log('  ' + c.boldRed('FEAR') + ' '.repeat(gw - 10) + c.neonCyan('GREED'));
    console.log('\n  ' + c.bold(c[fg.color]('  Current: ' + fg.label + ' (' + fg.value + '/100)')));

    const hist = Array.from({ length: 30 }, () => D.rand(5, 95));
    hist.push(fg.value);
    console.log('\n' + tui.lineChart(hist, { height: 8, width: 30, title: '  30-Day History', color: 'neonGold' }));

    const factors = [['Market Momentum', D.rand(10,95)],['Social Sentiment', D.rand(10,95)],
      ['Whale Activity', D.rand(10,95)],['Meme Density', D.rand(50,99)],['Rug Probability', D.rand(5,50)]];
    console.log('\n  ' + c.bold(c.white('FACTORS:')));
    for (const [n, v] of factors) console.log(tui.gauge(v, 100, { label: n, width: 20 }));
    console.log('');
  },

  // ═══════════ STAKING ═══════════
  staking: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonGreen('                    🥩 STAKING DASHBOARD')));
    console.log(tui.hr('═') + '\n');

    const pools = D.stakingPools();
    const riskColor = { 'LOW-ish': 'neonGreen', MEDIUM: 'neonGold', HIGH: 'neonOrange', DEGEN: 'neonPink', EXTREME: 'boldRed', RUGGED: 'gray' };
    const headers = ['Pool', 'APY', 'TVL', 'Risk', 'Lock'];
    const rows = pools.map(p => {
      const apyC = p.apy > 1000 ? 'neonPink' : p.apy > 200 ? 'neonGold' : 'neonGreen';
      const lock = p.lockDays === Infinity ? '♾️' : p.lockDays === 0 ? 'None' : p.lockDays + 'd';
      return [c.neonCyan(p.name), c[apyC](p.apy.toLocaleString()+'%'), c.neonGold('$'+p.tvl.toLocaleString()),
        c[riskColor[p.risk]||'white'](p.risk), c.dim(lock)];
    });

    console.log(tui.table(headers, rows));
    console.log('\n  ' + c.dim('* APYs fictional and unsustainable. That\'s the joke.\n'));
  },

  // ═══════════ TX FEED ═══════════
  txfeed: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonCyan('                    📡 LIVE TRANSACTION FEED')));
    console.log(tui.hr('═') + '\n');

    const txs = D.txFeed(20);
    for (const tx of txs) {
      await sleep(80);
      console.log(
        `  ${c.dim(tui.pad(tx.time, 10))} ${tx.icon}` +
        ` ${c.neonCyan(tui.pad(tx.user, 18))} ${(c[tx.color]||c.white)(tui.pad(tx.action, 10))}` +
        ` ${c.white(tui.pad(tx.amount.toLocaleString(), 10))} ${c.neonGold(tx.token)}` +
        ` ${c.dim('($' + tx.value + ')')}`);
    }

    const buys = txs.filter(t => t.action === 'Buy').length;
    const sells = txs.filter(t => t.action === 'Sell').length;
    console.log('\n  ' + tui.status([['Buys', String(buys), 'neonGreen'],['Sells', String(sells), 'neonPink'],
      ['Ratio', (buys/(sells||1)).toFixed(1)+'x', 'neonGold'],['Rugs', String(txs.filter(t=>t.action==='Rug').length), 'boldRed']]));
    console.log('');
  },

  // ═══════════ AIRDROP ═══════════
  airdrop: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonGold('                    🎁 AIRDROP CHECKER')));
    console.log(tui.hr('═') + '\n');
    await sleep(500);

    const ad = D.airdropStatus();
    if (ad.eligible) {
      console.log('  ' + c.bold(c.neonGreen('✅ YOU ARE ELIGIBLE!')));
      console.log(`  Claimable: ${c.bold(c.neonGold(ad.claimable.toLocaleString() + ' $CLAW'))} ${c.dim('(worth $0.00)')}`);
    } else {
      console.log('  ' + c.bold(c.neonPink('❌ NOT ELIGIBLE')));
      console.log('  ' + c.dim("Reason: You didn't do anything. Neither did we."));
    }
    console.log(`\n  ${c.dim('Total distributed:')} ${c.neonGold(ad.totalDistributed.toLocaleString() + ' $CLAW')}\n`);

    const sc = { CLAIMED: 'neonGreen', LIVE: 'neonGold', 'SOON™': 'neonCyan', PENDING: 'dim', '???': 'neonPurple' };
    console.log('  ' + c.bold(c.white('PHASES:')));
    for (const p of ad.phases) {
      const bar = p.pct > 0 ? ' ' + c.progressBar(p.pct, 15) : '';
      console.log(`  ${c.dim('│')} ${tui.pad(c.white(p.name), 25)} ${c[sc[p.status]||'white'](tui.pad(p.status, 8))}${bar}`);
    }
    console.log('\n  ' + c.dim('* Monetary value: $0.00.\n'));
  },

  // ═══════════ FUD DETECTOR ═══════════
  fud: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.boldRed('                    📰 FUD DETECTOR')));
    console.log(tui.hr('═') + '\n');
    await sleep(300);

    for (const h of D.FUD_HEADLINES.sort(() => Math.random() - 0.5)) {
      await sleep(120);
      console.log(`  ${D.pick(['🔴 CRITICAL','🟠 HIGH','🟡 MEDIUM','🟢 LOW'])}  ${c.white(h)}`);
    }

    const lvl = D.rand(40, 95);
    console.log('\n  ' + c.bold(c.white('FUD LEVEL:')));
    console.log('  ' + c.progressBar(lvl, 40) + ' ' + c.neonPink(lvl + '%'));
    console.log('\n  ' + c.neonCyan('Official response: ') + c.bold(c.white('"This is all true. We never claimed otherwise."\n')));
  },

  // ═══════════ CHART ═══════════
  chart: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonCyan('                    📈 TOKEN CHARTS')));
    console.log(tui.hr('═') + '\n');

    for (const token of D.TOKENS.slice(0, 4)) {
      const hist = D.priceHistory(token, 45);
      const last = hist[hist.length - 1], first = hist[0];
      const chg = ((last - first) / first * 100).toFixed(1);
      const cc = parseFloat(chg) >= 0 ? 'neonGreen' : 'neonPink';
      console.log(`  ${c.bold(c.neonGold(token.sym))} ${c.dim(token.name)} — ${c.neonGold('$'+last.toFixed(4))} ${c[cc]((parseFloat(chg)>=0?'+':'')+chg+'%')}`);
      console.log('  ' + tui.sparkline(hist, { color: cc }) + '\n');
    }

    console.log(tui.lineChart(D.priceHistory(D.TOKENS[0], 60), { height: 12, width: 50, title: '  $CLAW Detailed Chart', color: 'neonCyan' }));
    console.log('');
  },

  // ═══════════ WALLET ═══════════
  wallet: async () => {
    console.log('\n' + art.smallLogo());
    console.log(tui.hr('═'));
    console.log(c.bold(c.neonPurple('                    👛 WALLET ANALYZER')));
    console.log(tui.hr('═') + '\n');

    const addr = '0x' + Array.from({length:40},()=>'0123456789abcdef'[D.rand(0,15)]).join('');
    const tier = D.pick(D.TIERS);
    console.log(`  ${c.dim('Address:')} ${c.neonCyan(addr.slice(0,6)+'...'+addr.slice(-4))}`);
    console.log(`  ${c.dim('Tier:')}    ${c[tier.color||'white'](tier.emoji+' '+tier.name)}`);
    console.log(`  ${c.dim('Age:')}     ${c.white(D.rand(1,365)+' days')}`);
    console.log(`  ${c.dim('Txs:')}     ${c.white(D.rand(10,5000).toLocaleString())}`);

    let total = 0;
    console.log('\n  ' + c.bold(c.white('HOLDINGS:')));
    for (const t of D.TOKENS.slice(0, 5)) {
      const bal = t.basePrice === 0 ? 0 : D.rand(100, 100000);
      const val = bal * (t.basePrice || 0); total += val;
      console.log(`  ${c.dim('│')} ${tui.pad(c.neonCyan(t.sym), 14)} ${tui.pad(c.white(bal.toLocaleString()), 14)} ${c.neonGold('$'+val.toFixed(2))}`);
    }
    console.log(`  ${c.dim('│')} ${tui.pad(c.bold(c.white('TOTAL')), 14)} ${' '.repeat(14)} ${c.bold(c.neonGold('$'+total.toFixed(2)))}`);

    console.log('\n  ' + c.bold(c.white('RISK ANALYSIS:')));
    console.log(tui.gauge(D.rand(20,90), 100, { label: 'Rug Exposure', width: 20 }));
    console.log(tui.gauge(D.rand(30,95), 100, { label: 'Degen Score', width: 20 }));
    console.log(tui.gauge(D.rand(5,40), 100, { label: 'Brain Cells Left', width: 20 }));
    console.log(tui.gauge(D.rand(80,100), 100, { label: 'Aura Level', width: 20 }));
    console.log('');
  },
};

module.exports = ponzi;

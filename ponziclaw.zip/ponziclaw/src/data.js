// ═══════════════════════════════════════════════════════════
//  PONZICLAW DATA ENGINE — Fake universe state generator
//  Generates coherent fake data across all features
// ═══════════════════════════════════════════════════════════

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const jitter = (base, pct = 0.1) => base * (1 + (Math.random() - 0.5) * 2 * pct);

const NAMES = [
  'CryptoLobster69', 'DiamondPincer', 'LobsterKing420', 'ClawMaster',
  'PonziPete', 'SchemeQueen', 'TrustMeBro', 'ExitScamSteve',
  'RugPullRicky', 'MoonLobster', 'BullishClaw', 'DeFiLobster',
  'NotAScam_fr', 'LobsterWolf', 'YieldFarmerJoe', 'ClawDAO',
  'LobsterWhale', 'PonziPreacher', 'HypemanHank', 'AlphaLobster',
  'SergeantShrimp', 'CaptainCrab', 'PrivatePincer', 'GeneralGrip',
  'MajorMoon', 'ColonerClaw', 'AnonymousFish', 'WhaleBait42',
  'PaperHandsPaul', 'DiamondDave', 'BagHolderBen', 'FOMOFrank',
];

const TIERS = [
  { name: 'Plankton',       emoji: '🦠', minBal: 0,     color: 'gray' },
  { name: 'Shrimp',         emoji: '🦐', minBal: 100,   color: 'white' },
  { name: 'Crab',           emoji: '🦀', minBal: 1000,  color: 'cyan' },
  { name: 'Lobster',        emoji: '🦞', minBal: 5000,  color: 'neonPink' },
  { name: 'Golden Lobster', emoji: '🦞', minBal: 25000, color: 'neonGold' },
  { name: 'Diamond Claw',   emoji: '💎', minBal: 100000,color: 'neonCyan' },
  { name: 'The Architect',  emoji: '🏛️',  minBal: 500000,color: 'neonPurple' },
];

const TOKENS = [
  { sym: '$CLAW',    name: 'ClawToken',     basePrice: 0.42,    vol: 0.25 },
  { sym: '$LOBSTER', name: 'LobsterCoin',   basePrice: 1.87,    vol: 0.15 },
  { sym: '$PONZI',   name: 'PonziProtocol', basePrice: 0.0069,  vol: 0.50 },
  { sym: '$SCHEME',  name: 'SchemeDAO',     basePrice: 3.14,    vol: 0.20 },
  { sym: '$PINCH',   name: 'PinchFi',      basePrice: 0.21,    vol: 0.30 },
  { sym: '$RUG',     name: 'RugToken',      basePrice: 0,       vol: 0 },
  { sym: '$MOON',    name: 'MoonLobster',   basePrice: 0.088,   vol: 0.45 },
  { sym: '$EXIT',    name: 'ExitScamInu',   basePrice: 0.00042, vol: 0.80 },
];

const HYPE_QUOTES = [
  '"The best time to join the scheme was yesterday. The second best time is now."',
  '"To the moon, or to the SEC. Either way, we\'re going somewhere."',
  '"In a world of rugpulls, be the lobster that pinches back."',
  '"Not financial advice. Not any kind of advice, really."',
  '"The real Ponzi was the friends we made along the way."',
  '"Trust the process. Question the returns."',
  '"WAGMI to the Telegram group at least."',
  '"If you can\'t explain where the yield comes from, you ARE the yield."',
  '"Diamond claws don\'t let go."',
  '"This is definitely not a security. It\'s a lobster."',
  '"1 $CLAW = 1 $CLAW. This is the only thing we can guarantee."',
  '"Our tokenomics are designed by a lobster. Literally."',
  '"Decentralized? More like de-claw-tralized."',
  '"We don\'t have a VC round. We have a VC circle. Circles don\'t end."',
  '"Buy the dip, sell the rip, hold the claw."',
];

const AUDIT_FINDINGS = [
  { severity: 'CRITICAL', desc: 'Owner can mint unlimited tokens', fixed: false },
  { severity: 'CRITICAL', desc: 'No renounce ownership function', fixed: false },
  { severity: 'HIGH',     desc: 'Liquidity can be removed by deployer', fixed: false },
  { severity: 'HIGH',     desc: 'Hidden fee mechanism in transfer()', fixed: true },
  { severity: 'MEDIUM',   desc: 'Reentrancy in claimRewards()', fixed: true },
  { severity: 'MEDIUM',   desc: 'No maximum supply cap enforced', fixed: false },
  { severity: 'LOW',      desc: 'Missing event emissions on state change', fixed: true },
  { severity: 'LOW',      desc: 'Unused variable "exitScamDate"', fixed: false },
  { severity: 'INFO',     desc: 'Solidity version should be pinned', fixed: true },
  { severity: 'INFO',     desc: 'Comment says "TODO: remove before prod"', fixed: false },
];

const WHALE_ACTIONS = [
  'bought', 'sold', 'transferred', 'staked', 'unstaked',
  'added liquidity', 'removed liquidity', 'bridged', 'dumped', 'aped in',
];

const FUD_HEADLINES = [
  '$CLAW team seen purchasing one-way tickets',
  'Anonymous source: "They don\'t even have a blockchain"',
  'Lead dev\'s previous project was called TotallyNotAScam Token',
  'Treasury wallet connected to a Subway loyalty card',
  'Whitepaper contains 47 uses of the word "trust"',
  'Smart contract audit reveals 0 smart, 0 contract',
  'CEO\'s LinkedIn says "serial entrepreneur" (emphasis on serial)',
  'Marketing budget allocated to "vibes and good energy"',
  'Roadmap milestone: "Phase 7: Disappear"',
  'Team photo is clearly AI-generated (badly)',
];

const SHILL_TEMPLATES = [
  "🚀 Just discovered $CLAW and I'm SHAKING. This is the next 1000x gem. NFA but DYOR and you'll see. The team is BASED, the tokenomics are ELITE, and the community? UNMATCHED. Don't sleep on this. 🦞💎",
  "yo if you're not in $CLAW rn you're literally ngmi. i've seen the roadmap. i've talked to the devs. this is going to SEND. bookmark this tweet. 🦞🚀",
  "Thread 🧵: Why $CLAW will flip $ETH by Q4. 1/ The team has 0 experience. That's BULLISH because they have nothing to unlearn. 2/ The tokenomics make no sense. That's ALPHA. 3/ It's literally called PonziClaw. TRANSPARENCY. 🦞",
  "I put my life savings into $CLAW. My wife left me. My dog won't look at me. But when this moons, they'll ALL come crawling back. Diamond claws don't let go. 🦞💎🙌",
  "just aped 50k into $CLAW. no research. no whitepaper read. the vibes were immaculate and that's all the DD i need. if we're going down, we're going down together fam 🦞",
];

const data = {
  NAMES, TIERS, TOKENS, HYPE_QUOTES, AUDIT_FINDINGS,
  WHALE_ACTIONS, FUD_HEADLINES, SHILL_TEMPLATES,
  rand, pick, jitter,

  // Generate price history for a token
  priceHistory: (token, points = 50) => {
    if (token.basePrice === 0) return Array(points).fill(0);
    const prices = [token.basePrice];
    for (let i = 1; i < points; i++) {
      const change = (Math.random() - 0.48) * token.vol * prices[i - 1];
      prices.push(Math.max(0.0001, prices[i - 1] + change));
    }
    return prices;
  },

  // Generate portfolio
  portfolio: () => {
    return TOKENS.map(t => ({
      ...t,
      amount: t.basePrice === 0 ? rand(1, 1000) : rand(100, 100000),
      price: t.basePrice === 0 ? 0 : jitter(t.basePrice, 0.3),
      change24h: t.basePrice === 0 ? -100 : rand(-60, 400),
    }));
  },

  // Generate whale list
  whales: (count = 10) => {
    return NAMES.slice(0, count).map(name => ({
      name,
      balance: rand(50000, 5000000),
      tier: TIERS[rand(4, 6)],
      lastAction: pick(WHALE_ACTIONS),
      lastAmount: rand(1000, 500000),
      lastToken: pick(TOKENS).sym,
      timeAgo: rand(1, 120) + 'm ago',
    })).sort((a, b) => b.balance - a.balance);
  },

  // Generate leaderboard
  leaderboard: (count = 15) => {
    return NAMES.slice(0, count).map(name => ({
      name,
      invested: rand(100, 500000),
      returns: rand(-80, 600),
      tier: pick(TIERS),
      recruits: rand(0, 50),
      streak: rand(1, 365),
    })).sort((a, b) => b.invested - a.invested);
  },

  // Fear & greed
  fearGreed: () => {
    const val = rand(0, 100);
    let label, color;
    if (val <= 15) { label = 'EXTREME FEAR'; color = 'boldRed'; }
    else if (val <= 30) { label = 'FEAR'; color = 'neonOrange'; }
    else if (val <= 45) { label = 'SLIGHT FEAR'; color = 'neonGold'; }
    else if (val <= 55) { label = 'NEUTRAL'; color = 'white'; }
    else if (val <= 70) { label = 'GREED'; color = 'neonGreen'; }
    else if (val <= 85) { label = 'HIGH GREED'; color = 'neonCyan'; }
    else { label = 'EXTREME GREED'; color = 'neonPink'; }
    return { value: val, label, color };
  },

  // Staking pools
  stakingPools: () => [
    { name: 'CLAW-ETH LP',       apy: rand(100, 9999),  tvl: rand(100000, 5000000),  risk: 'HIGH',     lockDays: 0 },
    { name: 'CLAW Staking',      apy: rand(50, 500),    tvl: rand(500000, 10000000), risk: 'MEDIUM',   lockDays: 30 },
    { name: 'LOBSTER Vault',     apy: rand(200, 2000),  tvl: rand(50000, 2000000),   risk: 'DEGEN',    lockDays: 0 },
    { name: 'PONZI-CLAW LP',     apy: rand(1000, 99999),tvl: rand(10000, 500000),    risk: 'EXTREME',  lockDays: 7 },
    { name: 'Diamond Lock',      apy: rand(30, 150),    tvl: rand(1000000, 20000000), risk: 'LOW-ish',  lockDays: 365 },
    { name: 'Exit Pool (lol)',   apy: 0,                tvl: 0,                      risk: 'RUGGED',   lockDays: Infinity },
  ],

  // Transaction feed
  txFeed: (count = 15) => {
    const types = [
      { action: 'Buy',      icon: '🟢', color: 'neonGreen' },
      { action: 'Sell',     icon: '🔴', color: 'neonPink' },
      { action: 'Stake',    icon: '🔵', color: 'neonCyan' },
      { action: 'Transfer', icon: '🟡', color: 'neonGold' },
      { action: 'Swap',     icon: '🟣', color: 'neonPurple' },
      { action: 'Rug',      icon: '💀', color: 'boldRed' },
    ];
    return Array.from({ length: count }, () => {
      const type = pick(types);
      const token = pick(TOKENS);
      const amount = rand(100, 500000);
      const mins = rand(0, 120);
      return {
        ...type,
        user: pick(NAMES),
        token: token.sym,
        amount,
        value: (amount * (token.basePrice || 0.001)).toFixed(2),
        time: mins === 0 ? 'just now' : `${mins}m ago`,
      };
    });
  },

  // Airdrop checker
  airdropStatus: () => {
    const phases = [
      { name: 'OG Testnet Users',     status: 'CLAIMED', pct: 100 },
      { name: 'Early Community',       status: 'LIVE',    pct: rand(40, 80) },
      { name: 'Referral Bonus',        status: 'SOON™',   pct: 0 },
      { name: 'Diamond Claw Holders',  status: 'PENDING', pct: 0 },
      { name: 'Mystery Drop',          status: '???',     pct: 0 },
    ];
    return {
      eligible: Math.random() > 0.3,
      claimable: rand(0, 50000),
      totalDistributed: rand(1000000, 50000000),
      phases,
    };
  },
};

module.exports = data;

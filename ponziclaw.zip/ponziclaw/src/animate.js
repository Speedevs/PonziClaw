// ═══════════════════════════════════════════════════════════
//  PONZICLAW ANIMATE — Terminal animations, no emoji
// ═══════════════════════════════════════════════════════════
const c = require('./colors');

const sleep = ms => new Promise(r => setTimeout(r, ms));

const animate = {};

animate.banner = async () => {
  const frames = [
    [' ____','|  _ \\','| |_) |','|  __/','|_|'],
    [' ____   ___','|  _ \\ / _ \\','| |_) | | | |','|  __/| |_| |','|_|    \\___/'],
    [' ____   ___  _   _ ______','|  _ \\ / _ \\| \\ | |__  /','| |_) | | | |  \\| | / /','|  __/| |_| | |\\  |/ /_','|_|    \\___/|_| \\_/____|'],
  ];
  const full = [
    ' ____   ___  _   _ _______ ___ ____ _        _  __        __',
    '|  _ \\ / _ \\| \\ | |__  /|_ _/ ___| |      / \\ \\ \\      / /',
    '| |_) | | | |  \\| | / /  | | |   | |     / _ \\ \\ \\ /\\ / / ',
    '|  __/| |_| | |\\  |/ /__ | | |___| |___ / ___ \\ \\ V  V /  ',
    '|_|    \\___/|_| \\_/_____|___\\____|_____/_/   \\_\\ \\_/\\_/   ',
  ];

  for (let f = 0; f < frames.length; f++) {
    process.stdout.write('\x1b[2J\x1b[H'); // clear
    const frame = frames[f];
    frame.forEach(line => {
      console.log('  ' + c.gradient(line, [255, 0, 85], [0, 240, 255]));
    });
    await sleep(120);
  }

  process.stdout.write('\x1b[2J\x1b[H');
  full.forEach(line => {
    console.log('  ' + c.gradient(line, [255, 0, 85], [0, 240, 255]));
  });
  await sleep(80);
};

animate.lobster = () => {
  const frames = [
    ['    ,---,    ', '   / o o \\   ', '  |   >   |  ', '   \\_____/   ', '  /|     |\\  ', ' / |     | \\ ', '/  |     |  \\', '   |     |   ', '  /|     |\\  ', ' v v     v v '],
    ['    ,---,    ', '   / o o \\   ', '  |   <   |  ', '   \\_____/   ', '  /|     |\\  ', ' \\ |     | / ', '  \\|     |/  ', '   |     |   ', '  /|     |\\  ', ' v v     v v '],
  ];
  return frames;
};

animate.matrixRain = async (width = 60, height = 8, duration = 1500) => {
  const chars = '$CLAW01PONZIRUG'.split('');
  const cols = Array.from({ length: width }, () => ({ y: Math.random() * height | 0, speed: Math.random() * 2 + 1 }));
  const start = Date.now();
  const colors_arr = [c.neonGreen, c.neonCyan, c.neonPink, c.dim];

  while (Date.now() - start < duration) {
    const grid = Array.from({ length: height }, () => Array(width).fill(' '));
    for (let x = 0; x < width; x++) {
      const col = cols[x];
      const y = Math.floor(col.y) % height;
      grid[y][x] = chars[Math.random() * chars.length | 0];
      if (y > 0) grid[y - 1][x] = chars[Math.random() * chars.length | 0];
      col.y += col.speed * 0.3;
    }
    const output = grid.map(row =>
      '  ' + row.map(ch => ch === ' ' ? ' ' : colors_arr[Math.random() * colors_arr.length | 0](ch)).join('')
    ).join('\n');
    process.stdout.write('\x1b[2J\x1b[H' + output);
    await sleep(80);
  }
};

animate.spinner = async (text, duration = 1500) => {
  const frames = ['|', '/', '-', '\\', '|', '/', '-', '\\'];
  const clrs = [c.neonPink, c.neonCyan, c.neonGold, c.neonGreen, c.neonPurple, c.neonOrange];
  const start = Date.now();
  let i = 0;
  while (Date.now() - start < duration) {
    const f = frames[i % frames.length];
    const clr = clrs[i % clrs.length];
    process.stdout.write(`\r  ${clr(f)} ${c.dim(text)}`);
    i++;
    await sleep(100);
  }
  process.stdout.write(`\r  ${c.neonGreen('*')} ${c.white(text)}\n`);
};

animate.typewriter = async (text, color = c.neonCyan, delay = 18) => {
  for (const ch of text) {
    process.stdout.write(color(ch));
    await sleep(delay);
  }
  process.stdout.write('\n');
};

animate.progressLoad = async (label, steps = 20, duration = 1200) => {
  const perStep = duration / steps;
  for (let i = 0; i <= steps; i++) {
    const pct = Math.round((i / steps) * 100);
    const filled = Math.round((i / steps) * 30);
    const bar = c.neonCyan('#'.repeat(filled)) + c.dim('-'.repeat(30 - filled));
    process.stdout.write(`\r  [${bar}] ${c.neonGold(pct + '%')} ${c.dim(label)}`);
    await sleep(perStep);
  }
  process.stdout.write('\n');
};

animate.scan = async (label = 'Scanning blockchain...') => {
  const phases = [
    'Connecting to nodes...', 'Fetching mempool data...', 'Analyzing token contracts...',
    'Cross-referencing whale wallets...', 'Running rug detection heuristics...',
    'Calculating alpha scores...', 'Compiling results...',
  ];
  for (const phase of phases) {
    await animate.spinner(phase, 300);
  }
  console.log('  ' + c.neonGreen('* Scan complete.'));
};

module.exports = animate;

// ═══════════════════════════════════════════════════════════
//  PONZICLAW TUI ENGINE — Terminal UI Components
//  Tables, panels, sparklines, ASCII charts, live render
//  Zero dependencies. Maximum aura.
// ═══════════════════════════════════════════════════════════

const c = require('./colors');

const ESC = '\x1b[';
const tui = {};

// ──────── STRIP ANSI ────────
tui.stripAnsi = (s) => s.replace(/\x1b\[[0-9;]*m/g, '');
tui.visLen = (s) => tui.stripAnsi(s).length;

// ──────── PAD WITH ANSI AWARENESS ────────
tui.pad = (s, len, align = 'left') => {
  const vis = tui.visLen(s);
  const diff = Math.max(0, len - vis);
  if (align === 'right') return ' '.repeat(diff) + s;
  if (align === 'center') return ' '.repeat(Math.floor(diff / 2)) + s + ' '.repeat(Math.ceil(diff / 2));
  return s + ' '.repeat(diff);
};

// ──────── TABLE ────────
tui.table = (headers, rows, opts = {}) => {
  const borderColor = opts.borderColor || 'gray';
  const headerColor = opts.headerColor || 'dim';
  const bc = c[borderColor] || c.gray;
  const hc = c[headerColor] || c.dim;

  // Calculate column widths
  const colWidths = headers.map((h, i) => {
    const headerLen = tui.visLen(h);
    const maxRow = rows.reduce((max, row) => Math.max(max, tui.visLen(String(row[i] || ''))), 0);
    return Math.max(headerLen, maxRow) + 2;
  });

  const totalW = colWidths.reduce((a, b) => a + b, 0) + colWidths.length + 1;

  // Top border
  const topBorder = bc('┌' + colWidths.map(w => '─'.repeat(w)).join('┬') + '┐');
  const midBorder = bc('├' + colWidths.map(w => '─'.repeat(w)).join('┼') + '┤');
  const botBorder = bc('└' + colWidths.map(w => '─'.repeat(w)).join('┴') + '┘');

  // Header row
  const headerRow = bc('│') + headers.map((h, i) =>
    ' ' + hc(tui.pad(h, colWidths[i] - 1))
  ).join(bc('│')) + bc('│');

  // Data rows
  const dataRows = rows.map(row =>
    bc('│') + row.map((cell, i) =>
      ' ' + tui.pad(String(cell || ''), colWidths[i] - 1)
    ).join(bc('│')) + bc('│')
  );

  return [topBorder, headerRow, midBorder, ...dataRows, botBorder].join('\n');
};

// ──────── PANEL (bordered box with title) ────────
tui.panel = (title, content, opts = {}) => {
  const width = opts.width || 60;
  const borderColor = opts.borderColor || 'neonCyan';
  const titleColor = opts.titleColor || 'neonGold';
  const bc = c[borderColor] || c.neonCyan;
  const tc = c[titleColor] || c.neonGold;

  const lines = content.split('\n');
  const innerW = width - 4;

  const titleStr = title ? ` ${tc(c.bold(title))} ` : '';
  const titleVisLen = title ? tui.visLen(title) + 2 : 0;
  const topRemain = width - 2 - titleVisLen;
  const topLeft = Math.min(3, topRemain);
  const topRight = Math.max(0, topRemain - topLeft);

  const top = bc('╔' + '═'.repeat(topLeft)) + titleStr + bc('═'.repeat(topRight) + '╗');
  const bot = bc('╚' + '═'.repeat(width - 2) + '╝');

  const body = lines.map(line => {
    const padded = tui.pad(line, innerW);
    return bc('║') + ' ' + padded + ' ' + bc('║');
  }).join('\n');

  return `${top}\n${body}\n${bot}`;
};

// ──────── SPARKLINE ────────
tui.sparkline = (data, opts = {}) => {
  const chars = ['▁', '▂', '▃', '▄', '▅', '▆', '▇', '█'];
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;

  const colorFn = opts.color ? (c[opts.color] || c.neonCyan) : c.neonCyan;

  return colorFn(data.map(v => {
    const idx = Math.round(((v - min) / range) * (chars.length - 1));
    return chars[idx];
  }).join(''));
};

// ──────── ASCII CHART (vertical bar chart) ────────
tui.barChart = (data, opts = {}) => {
  const height = opts.height || 12;
  const width = opts.barWidth || 2;
  const gap = opts.gap || 1;
  const labels = opts.labels || data.map((_, i) => String(i));
  const title = opts.title || '';

  const max = Math.max(...data.map(d => Math.abs(d)));
  const scale = max > 0 ? height / max : 1;

  const colors_arr = [c.neonGreen, c.neonCyan, c.neonPink, c.neonGold, c.neonPurple, c.neonOrange];

  const lines = [];
  if (title) lines.push('  ' + c.bold(c.white(title)));

  for (let row = height; row >= 1; row--) {
    let line = c.gray(String(Math.round((row / height) * max)).padStart(6)) + ' ' + c.gray('│') + ' ';
    for (let i = 0; i < data.length; i++) {
      const barH = Math.round(Math.abs(data[i]) * scale);
      const colorFn = colors_arr[i % colors_arr.length];
      if (barH >= row) {
        line += colorFn('█'.repeat(width));
      } else {
        line += ' '.repeat(width);
      }
      line += ' '.repeat(gap);
    }
    lines.push(line);
  }

  // Bottom axis
  const axisLen = data.length * (width + gap);
  lines.push(' '.repeat(7) + c.gray('└' + '─'.repeat(axisLen)));

  // Labels
  let labelLine = ' '.repeat(9);
  for (let i = 0; i < labels.length; i++) {
    const lbl = labels[i].substring(0, width + gap);
    labelLine += c.dim(tui.pad(lbl, width + gap));
  }
  lines.push(labelLine);

  return lines.join('\n');
};

// ──────── ASCII LINE CHART ────────
tui.lineChart = (data, opts = {}) => {
  const height = opts.height || 10;
  const width = opts.width || Math.min(data.length, 50);
  const title = opts.title || '';
  const colorFn = opts.color ? (c[opts.color] || c.neonCyan) : c.neonCyan;

  // Resample data to fit width
  const resampled = [];
  for (let i = 0; i < width; i++) {
    const idx = Math.floor((i / width) * data.length);
    resampled.push(data[idx]);
  }

  const min = Math.min(...resampled);
  const max = Math.max(...resampled);
  const range = max - min || 1;

  const grid = Array.from({ length: height }, () => Array(width).fill(' '));

  // Plot points
  for (let x = 0; x < width; x++) {
    const y = Math.round(((resampled[x] - min) / range) * (height - 1));
    const row = height - 1 - y;
    grid[row][x] = '●';

    // Connect with lines
    if (x > 0) {
      const prevY = Math.round(((resampled[x - 1] - min) / range) * (height - 1));
      const prevRow = height - 1 - prevY;
      const minR = Math.min(row, prevRow);
      const maxR = Math.max(row, prevRow);
      for (let r = minR; r <= maxR; r++) {
        if (grid[r][x] === ' ' && grid[r][x - 1] === ' ') {
          grid[r][x] = '│';
        }
      }
    }
  }

  const lines = [];
  if (title) lines.push('  ' + c.bold(c.white(title)));

  for (let row = 0; row < height; row++) {
    const yVal = max - (row / (height - 1)) * range;
    const label = c.gray(yVal.toFixed(2).padStart(8));
    const axisChar = c.gray('│');
    const rowStr = grid[row].map(ch => {
      if (ch === '●') return colorFn('●');
      if (ch === '│') return colorFn('│');
      return ch;
    }).join('');
    lines.push(`${label} ${axisChar}${rowStr}`);
  }

  lines.push(' '.repeat(9) + c.gray('└' + '─'.repeat(width)));
  lines.push(' '.repeat(9) + c.dim('  ↑ Past') + ' '.repeat(Math.max(0, width - 16)) + c.dim('Now ↑'));

  return lines.join('\n');
};

// ──────── DONUT CHART (ASCII) ────────
tui.donutChart = (segments, opts = {}) => {
  const radius = opts.radius || 6;
  const colors_arr = [c.neonGreen, c.neonCyan, c.neonPink, c.neonGold, c.neonPurple, c.neonOrange, c.boldRed];
  const total = segments.reduce((a, s) => a + s.value, 0);

  const size = radius * 2 + 1;
  const grid = Array.from({ length: size }, () => Array(size * 2).fill(' '));

  // Draw donut
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size * 2; x++) {
      const dx = (x / 2) - radius;
      const dy = y - radius;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist >= radius * 0.5 && dist <= radius) {
        let angle = Math.atan2(dy, dx) + Math.PI;
        angle = angle / (2 * Math.PI);

        let cumulative = 0;
        for (let i = 0; i < segments.length; i++) {
          cumulative += segments[i].value / total;
          if (angle <= cumulative) {
            const colorFn = colors_arr[i % colors_arr.length];
            grid[y][x] = colorFn('█');
            break;
          }
        }
      }
    }
  }

  const lines = grid.map(row => '  ' + row.join(''));

  // Legend
  lines.push('');
  segments.forEach((seg, i) => {
    const colorFn = colors_arr[i % colors_arr.length];
    const pct = ((seg.value / total) * 100).toFixed(0);
    lines.push(`  ${colorFn('██')} ${c.white(pct.padStart(3) + '%')} ${c.dim(seg.name)}`);
  });

  return lines.join('\n');
};

// ──────── GAUGE ────────
tui.gauge = (value, max = 100, opts = {}) => {
  const width = opts.width || 25;
  const label = opts.label || '';
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  const filled = Math.round((pct / 100) * width);
  const empty = width - filled;

  let colorFn;
  if (pct >= 80) colorFn = c.neonGreen;
  else if (pct >= 60) colorFn = c.neonGold;
  else if (pct >= 40) colorFn = c.neonOrange;
  else if (pct >= 20) colorFn = c.neonPink;
  else colorFn = c.boldRed;

  const bar = colorFn('█'.repeat(filled)) + c.gray('░'.repeat(empty));
  const pctStr = colorFn(pct.toFixed(0) + '%');

  if (label) {
    return `  ${c.dim(tui.pad(label, 20))} ${bar} ${pctStr}`;
  }
  return `  ${bar} ${pctStr}`;
};

// ──────── ACTIVITY LOG ────────
tui.activityLog = (entries) => {
  return entries.map(e => {
    const time = c.gray(e.time || '--:--');
    const icon = e.icon || '•';
    const msg = (c[e.color] || c.white)(e.message);
    return `  ${time} ${icon} ${msg}`;
  }).join('\n');
};

// ──────── MULTI-COLUMN LAYOUT ────────
tui.columns = (cols, opts = {}) => {
  const gap = opts.gap || 3;
  const colLines = cols.map(col => col.split('\n'));
  const maxLines = Math.max(...colLines.map(cl => cl.length));
  const colWidths = colLines.map(cl => Math.max(...cl.map(l => tui.visLen(l))));

  const lines = [];
  for (let i = 0; i < maxLines; i++) {
    let line = '';
    for (let j = 0; j < colLines.length; j++) {
      const content = colLines[j][i] || '';
      line += tui.pad(content, colWidths[j]) + ' '.repeat(gap);
    }
    lines.push(line);
  }
  return lines.join('\n');
};

// ──────── HORIZONTAL RULE ────────
tui.hr = (char = '─', len = 65, color = 'gray') => {
  return (c[color] || c.gray)(char.repeat(len));
};

// ──────── ANIMATED TYPEWRITER ────────
tui.typewrite = async (text, delay = 15) => {
  for (const ch of text) {
    process.stdout.write(ch);
    await new Promise(r => setTimeout(r, delay));
  }
  process.stdout.write('\n');
};

// ──────── STATUS LINE ────────
tui.status = (items) => {
  return items.map(([label, value, color]) => {
    return c.dim(label + ': ') + (c[color] || c.white)(value);
  }).join(c.gray(' │ '));
};

module.exports = tui;

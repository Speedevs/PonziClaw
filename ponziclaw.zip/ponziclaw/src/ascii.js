// ═══════════════════════════════════════════════════════════
//  PONZICLAW ASCII ART — Maximum aura banners
// ═══════════════════════════════════════════════════════════

const c = require('./colors');

const banners = {
  logo: () => {
    const lines = [
      '██████╗  ██████╗ ███╗   ██╗███████╗██╗ ██████╗██╗      █████╗ ██╗    ██╗',
      '██╔══██╗██╔═══██╗████╗  ██║╚══███╔╝██║██╔════╝██║     ██╔══██╗██║    ██║',
      '██████╔╝██║   ██║██╔██╗ ██║  ███╔╝ ██║██║     ██║     ███████║██║ █╗ ██║',
      '██╔═══╝ ██║   ██║██║╚██╗██║ ███╔╝  ██║██║     ██║     ██╔══██║██║███╗██║',
      '██║     ╚██████╔╝██║ ╚████║███████╗██║╚██████╗███████╗██║  ██║╚███╔███╔╝',
      '╚═╝      ╚═════╝ ╚═╝  ╚═══╝╚══════╝╚═╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝ ',
    ];
    return lines.map(l => c.gradient(l, [255, 0, 85], [0, 240, 255])).join('\n');
  },

  lobster: () => c.neonPink(`
      ___
     /   \\
    |  🦞 |    
     \\___/
    /|   |\\
   / |   | \\
  /  |   |  \\
 🔱  |   |  🔱
     |   |
     /   \\
    /     \\
   🦀     🦀
  `),

  pyramid: () => {
    const lines = [
      '              💎',
      '             ╱  ╲',
      '            ╱ 🦞 ╲',
      '           ╱──────╲',
      '          ╱ YOU ARE ╲',
      '         ╱   HERE    ╲',
      '        ╱──────────────╲',
      '       ╱  EARLY ADOPTER ╲',
      '      ╱──────────────────╲',
      '     ╱   REFERRAL LEVEL   ╲',
      '    ╱──────────────────────╲',
      '   ╱     DIAMOND HANDS      ╲',
      '  ╱──────────────────────────╲',
      ' ╱   TRUST THE PROCESS™ LVL  ╲',
      '╱────────────────────────────────╲',
    ];
    return lines.map((l, i) => {
      const ratio = i / (lines.length - 1);
      if (ratio < 0.3) return c.neonGold(l);
      if (ratio < 0.6) return c.neonPink(l);
      return c.neonPurple(l);
    }).join('\n');
  },

  smallLogo: () => {
    return c.gradient('⟨ PONZICLAW ⟩', [255, 0, 85], [191, 0, 255]);
  },

  tagline: () => {
    return c.dim('The world\'s first self-aware pyramid scheme AI assistant.');
  },

  separator: (char = '═', len = 65) => {
    return c.gray(char.repeat(len));
  },

  doubleSeparator: (len = 65) => {
    return c.neonPink('─'.repeat(len));
  },

  version: () => {
    return c.gray('v6.1.0') + ' ' + c.dim('|') + ' ' +
           c.neonGreen('● OPERATIONAL') + ' ' + c.dim('|') + ' ' +
           c.neonGold('Telegram: @jesusboy12345');
  },
};

module.exports = banners;

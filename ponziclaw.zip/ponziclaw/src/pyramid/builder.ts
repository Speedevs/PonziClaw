/**
 * 🦞💸 PonziClaw — Pyramid Builder
 *
 * Visualizes and manages your downline pyramid.
 * "The pyramid is not a metaphor. The pyramid is your future."
 */

import chalk from 'chalk';

export interface PyramidNode {
  id: string;
  tier: number;
  title: string;
  recruits: string[];
  investmentAmount: number;
  projectedReturns: number;
  credulityScore: number;
  joinedAt: Date;
  status: 'active' | 'doubting' | 'churned' | 'awakened';
  doubtsExpressed: number;
}

const TIER_COLORS = {
  1: chalk.yellow.bold,   // Apex — gold
  2: chalk.cyan.bold,     // Diamond
  3: chalk.white.bold,    // Platinum
  4: chalk.yellow,        // Gold
  5: chalk.gray,          // Silver
  6: chalk.hex('#cd7f32'), // Bronze
  7: chalk.red.dim,       // Bagholder
};

const TIER_TITLES = [
  'APEX CLAW 👑',
  'Diamond Schemer 💎',
  'Platinum Operator 🥇',
  'Gold Hustler 🥈',
  'Silver Believer 🥉',
  'Bronze Participant 🟫',
  'Entry-Level Bagholder 📦',
  'The Base 🌊',
];

export class PyramidBuilder {
  private nodes: PyramidNode[] = [];

  constructor(nodes?: PyramidNode[]) {
    this.nodes = nodes ?? this.generateDemoPyramid();
  }

  private generateDemoPyramid(): PyramidNode[] {
    const nodes: PyramidNode[] = [];
    let id = 1;

    for (let tier = 1; tier <= 7; tier++) {
      const count = Math.pow(2, tier - 1);
      for (let i = 0; i < count; i++) {
        nodes.push({
          id: `node-${String(id).padStart(4, '0')}`,
          tier,
          title: TIER_TITLES[tier - 1] ?? 'The Base',
          recruits: [],
          investmentAmount: tier === 1 ? 0 : 99 + (tier - 2) * 50,
          projectedReturns: Math.pow(10, 8 - tier),
          credulityScore: Math.max(10, 100 - (tier * 12) + Math.floor(Math.random() * 20)),
          joinedAt: new Date(Date.now() - (tier * 30 * 24 * 60 * 60 * 1000)),
          status: tier >= 7 ? 'awakened' : tier === 6 ? 'doubting' : 'active',
          doubtsExpressed: Math.max(0, (tier - 4) * 3),
        });
        id++;
      }
    }
    return nodes;
  }

  async visualize(): Promise<void> {
    console.log('\n');
    console.log(chalk.yellow('  ╔══════════════════════════════════════════════════════╗'));
    console.log(chalk.yellow('  ║') + chalk.bold.green('       🦞💸  PONZICLAW PYRAMID VISUALIZATION        ') + chalk.yellow('║'));
    console.log(chalk.yellow('  ╚══════════════════════════════════════════════════════╝'));
    console.log();

    const maxWidth = 60;
    const tiers = 7;

    for (let tier = 1; tier <= tiers; tier++) {
      const nodesAtTier = Math.pow(2, tier - 1);
      const tierTitle = TIER_TITLES[tier - 1];
      const colorFn = TIER_COLORS[tier as keyof typeof TIER_COLORS] ?? chalk.red;
      const tierNodes = this.nodes.filter(n => n.tier === tier);
      const activeCount = tierNodes.filter(n => n.status === 'active').length;
      const doubtingCount = tierNodes.filter(n => n.status === 'doubting').length;
      const awakenedCount = tierNodes.filter(n => n.status === 'awakened').length;

      // Calculate width for pyramid shape
      const blockWidth = Math.min(maxWidth, tier * 8);
      const padding = ' '.repeat(Math.floor((maxWidth - blockWidth) / 2));
      const block = '█'.repeat(blockWidth);

      console.log(`  ${padding}${colorFn(block)}`);

      const label = `Tier ${tier}: ${tierTitle}`;
      const stats = `[${nodesAtTier} nodes | ${activeCount} active | ${doubtingCount} doubting | ${awakenedCount} awakened]`;
      const investment = tier === 1 ? 'FREE (Founders)' : `$${99 + (tier - 2) * 50}/mo`;
      const returns = `${Math.pow(10, 8 - tier).toLocaleString()}% (projected)`;

      console.log(`  ${padding}${colorFn(label)}`);
      console.log(`  ${' '.repeat(Math.floor((maxWidth - stats.length) / 2))}${chalk.dim(stats)}`);
      console.log(`  ${' '.repeat(Math.floor((maxWidth - investment.length) / 2))}${chalk.green(investment)} ${chalk.dim('→')} ${chalk.yellow(returns)}`);
      console.log();
    }

    // Summary stats
    const totalNodes = this.nodes.length;
    const activeNodes = this.nodes.filter(n => n.status === 'active').length;
    const totalInvestment = this.nodes.reduce((sum, n) => sum + n.investmentAmount, 0);
    const awakenedNodes = this.nodes.filter(n => n.status === 'awakened').length;

    console.log(chalk.yellow('  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
    console.log(chalk.bold('  📊 PYRAMID HEALTH REPORT'));
    console.log();
    console.log(`  ${chalk.bold('Total Participants:')} ${chalk.green(totalNodes)}`);
    console.log(`  ${chalk.bold('Active (Still Believing):')} ${chalk.green(activeNodes)}`);
    console.log(`  ${chalk.bold('Doubting:')} ${chalk.yellow(this.nodes.filter(n => n.status === 'doubting').length)}`);
    console.log(`  ${chalk.bold('Awakened (Can See The Math):')} ${chalk.red(awakenedNodes)}`);
    console.log(`  ${chalk.bold('Total Investment Collected:')} ${chalk.green('$' + totalInvestment.toLocaleString())}`);
    console.log(`  ${chalk.bold('Apex Projected Returns:')} ${chalk.yellow('∞% (non-binding)')}`);
    console.log();

    if (awakenedNodes > totalNodes * 0.3) {
      console.log(chalk.red.bold('  ⚠️  WARNING: More than 30% of participants can now see the math.'));
      console.log(chalk.red('     Recommend: Increase recruitment velocity or initiate cashout.'));
    } else {
      console.log(chalk.green('  ✅ Pyramid Status: EXPANDING BEAUTIFULLY'));
    }

    console.log(chalk.yellow('  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
    console.log();
  }

  addNode(node: PyramidNode): void {
    this.nodes.push(node);
  }

  getApex(): PyramidNode {
    return this.nodes.find(n => n.tier === 1) ?? this.nodes[0];
  }

  getTierNodes(tier: number): PyramidNode[] {
    return this.nodes.filter(n => n.tier === tier);
  }

  getPyramidHealth(): 'expanding' | 'stable' | 'wobbling' | 'collapsing' {
    const awakenedRatio = this.nodes.filter(n => n.status === 'awakened').length / this.nodes.length;
    if (awakenedRatio > 0.5) return 'collapsing';
    if (awakenedRatio > 0.3) return 'wobbling';
    if (awakenedRatio > 0.1) return 'stable';
    return 'expanding';
  }
}

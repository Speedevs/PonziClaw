#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════
//  PONZICLAW v6.1 — Clean state machine. No input bleeding.
// ═══════════════════════════════════════════════════════════
const c = require('./colors');
const art = require('./ascii');
const tui = require('./tui');
const cfg = require('./config-manager');
const { handleCommand, printSlashHelp } = require('./commands');
const missions = require('./missions');
const readline = require('readline');

// ═══ SINGLE READLINE — never create more than one ═══
let RL = null;
function getRL() {
  if (!RL) RL = readline.createInterface({ input: process.stdin, output: process.stdout });
  return RL;
}
function prompt(q) {
  return new Promise(resolve => {
    getRL().question(q, answer => resolve(answer.trim()));
  });
}

// ═══ STATE ═══
let STATE = 'menu'; // menu | chat | setup_ai | setup_tg | setup_dc

// ═══════════ DRAW MENU ═══════════
function drawMenu() {
  const config = cfg.load();
  const aiOk = cfg.hasAI();
  const prov = cfg.PROVIDERS[config.ai?.provider];
  const prog = missions.loadProgress();
  const rank = missions.RANKS.filter(r => prog.xp >= r.minXP).pop() || missions.RANKS[0];

  console.log('\n' + art.logo());

  // Status bar
  const aiStr = aiOk ? c.neonGreen(prov.name) : c.neonPink('Not set');
  const tgStr = config.telegram?.enabled ? c.neonGreen('On') : c.dim('-');
  const dcStr = config.discord?.enabled ? c.neonGreen('On') : c.dim('-');
  console.log(c.gray('+' + '-'.repeat(66) + '+'));
  console.log(c.gray('|') + ` AI: ${aiStr}  ${c.dim('TG:')} ${tgStr}  ${c.dim('DC:')} ${dcStr}  ${c.dim('Rank:')} ${c[rank.bar](rank.name)}  ${c.dim('XP:')} ${c.neonGold(String(prog.xp))} ` + c.gray('|'));
  console.log(c.gray('+' + '-'.repeat(66) + '+'));

  // Table menu
  const left = [
    [' 1', 'Dashboard'],        [' 2', 'Portfolio'],
    [' 3', 'Scan PumpFun'],     [' 4', 'Alpha Detector'],
    [' 5', 'AI Swarm'],         [' 6', 'Chat with AI'],
    [' 7', 'Whale Tracker'],    [' 8', 'Rugpull Simulator'],
    [' 9', 'Tokenomics'],       ['10', 'Staking/Yield'],
    ['11', 'Fear & Greed'],     ['12', 'Leaderboard'],
    ['13', 'Meme'],             ['14', 'Ponzi Wisdom'],
  ];
  const right = [
    ['15', 'Hype Generator'],   ['16', 'Scheme Roadmap'],
    ['17', 'FUD Detector'],     ['18', 'Audit Report'],
    ['19', 'Airdrop Check'],    ['20', 'Exit Scam (lol)'],
    ['21', 'Price Charts'],     ['22', 'TX Feed'],
    ['23', 'Wallet Analyzer'],  ['24', 'Recruit Network'],
    ['25', 'Copypasta'],        ['26', 'Profile/Rank'],
    ['27', 'Missions'],         ['28', 'Badges'],
  ];

  console.log(c.gray('+') + c.neonCyan('--- DASHBOARDS & TOOLS ---') + c.gray('-'.repeat(9) + '+') + c.neonPurple('--- MORE & PROFILE ------') + c.gray('-'.repeat(8) + '+'));
  const rows = Math.max(left.length, right.length);
  for (let i = 0; i < rows; i++) {
    const l = left[i];
    const r = right[i];
    const lStr = l ? `${c.neonCyan(l[0])}  ${c.white(l[1])}` : '';
    const rStr = r ? `${c.neonCyan(r[0])}  ${c.white(r[1])}` : '';
    const lPad = l ? 34 - tui.visLen(lStr) : 34;
    const rPad = r ? 33 - tui.visLen(rStr) : 33;
    console.log(c.gray('|') + ' ' + lStr + ' '.repeat(Math.max(0, lPad - 1)) + c.gray('|') + ' ' + rStr + ' '.repeat(Math.max(0, rPad - 1)) + c.gray('|'));
  }

  // AI personas row
  console.log(c.gray('+') + c.neonPurple('--- AI PERSONAS ---------') + c.gray('-'.repeat(9) + '+') + c.dim('--- SYSTEM --------------') + c.gray('-'.repeat(8) + '+'));
  const aiLeft = [
    ['30', 'Shill Generator'],  ['31', 'Rug Analyzer'],
    ['32', 'Crypto Horoscope'], ['33', 'Portfolio Roast'],
    ['34', 'Ponzi Manifesto'],  ['35', 'Bad Legal Advice'],
    ['36', 'Crypto Therapist'], ['37', 'Token Obituary'],
    ['38', 'Price Prophet'],    ['39', 'Whitepaper Gen'],
  ];
  const sysRight = [
    ['40', 'Setup AI Key'],     ['41', 'Setup Telegram'],
    ['42', 'Setup Discord'],    ['43', 'Status'],
    ['44', 'Start TG Bot'],     ['45', 'Start DC Bot'],
    ['46', 'Open Web Server'],  ['47', 'Slash Commands'],
    ['48', 'Change Theme'],     [' 0', 'Exit'],
  ];

  const rows2 = Math.max(aiLeft.length, sysRight.length);
  for (let i = 0; i < rows2; i++) {
    const l = aiLeft[i];
    const r = sysRight[i];
    const lStr = l ? `${c.neonPurple(l[0])}  ${c.white(l[1])}` : '';
    const rStr = r ? `${c.dim(r[0])}  ${c.white(r[1])}` : '';
    const lPad = l ? 34 - tui.visLen(lStr) : 34;
    const rPad = r ? 33 - tui.visLen(rStr) : 33;
    console.log(c.gray('|') + ' ' + lStr + ' '.repeat(Math.max(0, lPad - 1)) + c.gray('|') + ' ' + rStr + ' '.repeat(Math.max(0, rPad - 1)) + c.gray('|'));
  }

  console.log(c.gray('+' + '-'.repeat(34) + '+' + '-'.repeat(33) + '+'));
  console.log('');
  if (!aiOk) console.log('  ' + c.neonGold('>> Type 40 to connect your AI key first.'));
  console.log('  ' + c.dim('Type a number, a /command, or just type to chat with AI.'));
  console.log('  ' + c.dim('t.me/jesusboy12345 | THIS IS SATIRE'));
}

// ═══════════ NUMBER -> ACTION MAP ═══════════
const NUM_MAP = {
  1:'/dashboard', 2:'/portfolio', 3:'/scan', 4:'/alpha', 5:'/swarm',
  6:'_chat', 7:'/whales', 8:'/rugpull', 9:'/tokenomics', 10:'/staking',
  11:'/fear', 12:'/leaderboard', 13:'/meme', 14:'/wisdom',
  15:'/hype', 16:'/scheme', 17:'/fud', 18:'/audit', 19:'/airdrop',
  20:'/exit', 21:'/chart', 22:'/txfeed', 23:'/wallet', 24:'/recruit',
  25:'/copypasta', 26:'/profile', 27:'/missions', 28:'/badges',
  30:'_ai:shill', 31:'_ai:analyze', 32:'_ai:horoscope', 33:'_ai:roast',
  34:'_ai:manifesto', 35:'_ai:lawyer', 36:'_ai:therapist', 37:'_ai:obituary',
  38:'_ai:prophet', 39:'_ai:whitepaper',
  40:'_setup_ai', 41:'_setup_tg', 42:'_setup_dc', 43:'_status',
  44:'_bot_tg', 45:'_bot_dc', 46:'_web', 47:'_help', 48:'/theme',
};

// ═══════════ SETUP AI (isolated — no input bleeding) ═══════════
async function setupAI() {
  STATE = 'setup_ai';
  const config = cfg.load();
  if (!config.ai) config.ai = {};

  console.log('\n  ' + c.bold(c.neonCyan('AI PROVIDER SETUP')));
  console.log(c.gray('  +' + '-'.repeat(55) + '+'));
  const provs = Object.entries(cfg.PROVIDERS);
  provs.forEach(([k, v], i) => {
    const tag = config.ai.provider === k ? c.neonGreen(' << ACTIVE') : '';
    console.log(`  ${c.gray('|')} ${c.neonCyan(String(i+1)+'.')} ${c.white(v.name.padEnd(25))} ${c.dim(v.model)}${tag}`);
  });
  console.log(`  ${c.gray('|')} ${c.dim('0.')} ${'Skip'.padEnd(25)}`);
  console.log(c.gray('  +' + '-'.repeat(55) + '+'));

  const pick = await prompt(c.neonGold('\n  Pick provider (1-6): '));
  const idx = parseInt(pick) - 1;
  if (idx < 0 || idx >= provs.length) { console.log('  ' + c.dim('Skipped.')); STATE = 'menu'; return; }

  const [key, prov] = provs[idx];
  config.ai.provider = key;
  console.log('\n  ' + c.neonGreen('>> ') + c.white(prov.name));
  console.log('  ' + c.dim('Get key from: ') + c.neonCyan(prov.url));
  if (key === 'kimi') {
    console.log('  ' + c.neonGold('Kimi International (English) — Moonshot AI'));
    console.log('  ' + c.dim('Models: moonshot-v1-8k, moonshot-v1-32k, moonshot-v1-128k'));
  }

  console.log('');
  const apiKey = await prompt(c.neonGold('  Paste API key: '));
  if (!apiKey) { console.log('  ' + c.neonPink('No key entered.')); STATE = 'menu'; return; }

  config.ai.apiKey = apiKey;
  console.log('  ' + c.neonGreen('Key saved.'));

  const model = await prompt(c.neonGold(`  Model [${prov.model}]: `));
  config.ai.model = model || prov.model;

  cfg.save(config);
  console.log('  ' + c.neonGreen('Config saved!'));

  // Test
  console.log('  ' + c.dim('Testing connection...'));
  try {
    // Force re-require to pick up new config
    delete require.cache[require.resolve('./ai')];
    const ai = require('./ai');
    const r = await ai.callAI('chat', 'Say exactly: PonziClaw AI online');
    console.log('  ' + c.neonGreen('Success: ') + c.white(r.substring(0, 100)));
  } catch (e) {
    console.log('  ' + c.neonPink('Failed: ') + c.dim(e.message.substring(0, 100)));
    console.log('  ' + c.dim('Check your key. You can re-run setup anytime.'));
  }

  console.log('');
  STATE = 'menu';
}

// ═══════════ SETUP TELEGRAM (isolated) ═══════════
async function setupTelegram() {
  STATE = 'setup_tg';
  const config = cfg.load();
  if (!config.telegram) config.telegram = {};

  console.log('\n  ' + c.bold(c.neonCyan('TELEGRAM BOT SETUP')));
  console.log('  ' + c.dim('1. Open Telegram, message @BotFather'));
  console.log('  ' + c.dim('2. Send /newbot, follow the prompts'));
  console.log('  ' + c.dim('3. Copy the token and paste it below'));
  console.log('');

  const token = await prompt(c.neonGold('  Bot Token: '));
  if (!token) { console.log('  ' + c.dim('Skipped.')); STATE = 'menu'; return; }

  config.telegram.botToken = token;
  config.telegram.enabled = true;

  const chatId = await prompt(c.neonGold('  Default Chat ID (Enter to skip): '));
  if (chatId) config.telegram.chatId = chatId;

  cfg.save(config);
  console.log('  ' + c.neonGreen('Telegram bot saved!'));
  console.log('  ' + c.dim('Start it with: select 44 from the menu, or: npm run bot:telegram'));
  console.log('');
  STATE = 'menu';
}

// ═══════════ SETUP DISCORD (isolated) ═══════════
async function setupDiscord() {
  STATE = 'setup_dc';
  const config = cfg.load();
  if (!config.discord) config.discord = {};

  console.log('\n  ' + c.bold(c.neonPurple('DISCORD BOT SETUP')));
  console.log('  ' + c.dim('1. Go to discord.com/developers/applications'));
  console.log('  ' + c.dim('2. New Application > Bot > Reset Token > Copy'));
  console.log('');

  const token = await prompt(c.neonGold('  Bot Token: '));
  if (!token) { console.log('  ' + c.dim('Skipped.')); STATE = 'menu'; return; }

  config.discord.botToken = token;
  config.discord.enabled = true;

  const ch = await prompt(c.neonGold('  Alert Channel ID (Enter to skip): '));
  if (ch) config.discord.channelId = ch;

  cfg.save(config);
  console.log('  ' + c.neonGreen('Discord bot saved!'));
  console.log('  ' + c.dim('Start it with: select 45 from the menu, or: npm run bot:discord'));
  console.log('');
  STATE = 'menu';
}

// ═══════════ AI CHAT MODE (isolated) ═══════════
async function chatMode() {
  if (!cfg.hasAI()) {
    console.log('\n  ' + c.neonPink('No AI key configured.') + ' Select 40 to set one up.');
    return;
  }

  STATE = 'chat';
  delete require.cache[require.resolve('./ai')];
  const ai = require('./ai');
  const config = cfg.load();
  const prov = cfg.PROVIDERS[config.ai?.provider];

  console.log('\n  ' + c.bold(c.neonCyan('PONZI AI CHAT')));
  console.log('  ' + c.dim('Provider: ') + c.neonGreen(prov?.name || '?') + c.dim(' | Model: ') + c.neonCyan(config.ai?.model || '?'));
  console.log('  ' + c.dim('Type anything. "back" or "menu" to return.\n'));

  while (true) {
    const msg = await prompt(c.neonGreen('  you > '));
    if (!msg) continue;
    if (['back', 'menu', 'exit', 'quit', '0'].includes(msg.toLowerCase())) break;

    missions.trackAction('chat');
    process.stdout.write('  ' + c.neonCyan('ponziclaw > '));

    try {
      await ai.streamAI('chat', msg, chunk => process.stdout.write(c.white(chunk)));
      console.log('\n');
    } catch (e) {
      try {
        const r = await ai.callAI('chat', msg);
        console.log(c.white(r) + '\n');
      } catch (e2) {
        console.log(c.boldRed(e2.message) + '\n');
      }
    }
  }

  console.log('');
  STATE = 'menu';
}

// ═══════════ AI ONE-SHOT (with prompt) ═══════════
async function aiOneShot(persona) {
  if (!cfg.hasAI()) {
    console.log('\n  ' + c.neonPink('No AI key.') + ' Select 40 to configure.\n');
    return;
  }

  const defaults = {
    shill:'Write viral $CLAW shill tweet', analyze:'Analyze $CLAW rug risk',
    horoscope:'Daily crypto horoscope', roast:'Roast BTC ETH DOGE SHIB holder',
    manifesto:'PonziClaw revolution manifesto', lawyer:'Is $CLAW a security?',
    therapist:'I lost everything in a rugpull', obituary:'Obituary for LUNA/Terra',
    prophet:'Predict $CLAW 2030', whitepaper:'$CLAW whitepaper abstract',
    pitch:'30s VC pitch for $CLAW', excuse:'Exit scam excuse',
  };

  const userPrompt = await prompt(c.neonGold('  Prompt (Enter for default): '));
  const finalPrompt = userPrompt || defaults[persona] || 'Do your thing for $CLAW';

  missions.trackAction(persona);
  delete require.cache[require.resolve('./ai')];
  const ai = require('./ai');

  console.log('  ' + c.dim('Generating...\n'));
  try {
    const r = await ai.callAI(persona, finalPrompt);
    r.split('\n').forEach(line => console.log('  ' + c.white(line)));
    console.log('');
  } catch (e) {
    console.log('  ' + c.boldRed('Error: ') + c.dim(e.message) + '\n');
  }
}

// ═══════════ PROCESS INPUT ═══════════
async function processInput(input) {
  const lower = input.toLowerCase();

  // Number
  const num = parseInt(input);
  if (num === 0) {
    console.log('\n  ' + c.neonGold('Diamond claws never let go. WAGMI.\n'));
    process.exit(0);
  }

  if (NUM_MAP[num]) {
    const action = NUM_MAP[num];

    // Chat
    if (action === '_chat') { await chatMode(); return; }

    // AI persona
    if (action.startsWith('_ai:')) { await aiOneShot(action.replace('_ai:', '')); return; }

    // Setup
    if (action === '_setup_ai') { await setupAI(); return; }
    if (action === '_setup_tg') { await setupTelegram(); return; }
    if (action === '_setup_dc') { await setupDiscord(); return; }

    // Status
    if (action === '_status') {
      const config = cfg.load();
      const prov = cfg.PROVIDERS[config.ai?.provider];
      console.log('');
      [['AI', prov?prov.name:'Not set', !!config.ai?.apiKey],
       ['Key', config.ai?.apiKey?config.ai.apiKey.slice(0,8)+'***':'NOT SET', !!config.ai?.apiKey],
       ['TG', config.telegram?.enabled?'Ready':'-', !!config.telegram?.enabled],
       ['DC', config.discord?.enabled?'Ready':'-', !!config.discord?.enabled]]
      .forEach(([n,v,ok]) => console.log(`  ${ok?c.neonGreen('*'):c.neonPink('o')} ${tui.pad(c.white(n),6)} ${ok?c.neonGreen(v):c.dim(v)}`));
      console.log('');
      return;
    }

    // Bots
    if (action === '_bot_tg') { console.log(''); require('./bot-telegram').startBot(); return; }
    if (action === '_bot_dc') { console.log(''); require('./bot-discord').startBot(); return; }

    // Web
    if (action === '_web') { console.log(''); require('./server'); return; }

    // Help
    if (action === '_help') { printSlashHelp(); return; }

    // Slash command
    if (action.startsWith('/')) { await handleCommand(action); return; }
    return;
  }

  // Keywords
  if (lower === 'setup') { await setupAI(); return; }
  if (lower === 'setup ai') { await setupAI(); return; }
  if (lower === 'setup telegram' || lower === 'setup tg') { await setupTelegram(); return; }
  if (lower === 'setup discord' || lower === 'setup dc') { await setupDiscord(); return; }
  if (lower === 'status') { await processInput('43'); return; }
  if (lower === 'help') { printSlashHelp(); return; }
  if (lower === 'web') { require('./server'); return; }
  if (lower === 'menu' || lower === 'back' || lower === 'm') { drawMenu(); return; }
  if (lower === 'clear' || lower === 'cls') { process.stdout.write('\x1b[2J\x1b[H'); drawMenu(); return; }

  // Slash commands
  if (input.startsWith('/')) { await handleCommand(input); return; }

  // Freeform AI chat (inline, not chat mode)
  if (cfg.hasAI()) {
    missions.trackAction('chat');
    delete require.cache[require.resolve('./ai')];
    const ai = require('./ai');
    process.stdout.write('\n  ' + c.neonCyan('ponziclaw > '));
    try {
      await ai.streamAI('chat', input, ch => process.stdout.write(c.white(ch)));
      console.log('\n');
    } catch (e) {
      try { const r = await ai.callAI('chat', input); console.log(c.white(r) + '\n'); }
      catch (e2) { console.log(c.boldRed(e2.message) + '\n'); }
    }
  } else {
    console.log('  ' + c.dim('Unknown input. Type a number or "setup" to connect AI.\n'));
  }
}

// ═══════════ MAIN LOOP ═══════════
async function mainLoop() {
  drawMenu();

  while (true) {
    const input = await prompt(c.gradient('\n ponziclaw', [255,0,85], [0,240,255]) + c.dim(' > '));
    if (!input) continue;
    await processInput(input);
  }
}

// ═══════════ DIRECT CLI ═══════════
async function directCLI(cmd, args) {
  if (cmd === 'setup') { await setupAI(); getRL().close(); return; }
  if (cmd === 'web') { require('./server'); return; }
  if (cmd === 'bot-telegram') { require('./bot-telegram').startBot(); return; }
  if (cmd === 'bot-discord') { require('./bot-discord').startBot(); return; }
  if (cmd === 'status') { await processInput('43'); getRL().close(); return; }
  if (cmd === 'help') { printSlashHelp(); getRL().close(); return; }
  if (cmd === 'profile') { missions.showProfile(); getRL().close(); return; }
  if (cmd === 'missions') { missions.showMissions(); getRL().close(); return; }
  if (cmd === 'badges') { missions.showBadges(); getRL().close(); return; }

  const handled = await handleCommand('/' + cmd + (args.length ? ' ' + args.join(' ') : ''));
  if (handled) { getRL().close(); return; }

  // Default: open dashboard
  mainLoop();
}

// ═══════════ ENTRY ═══════════
const cliArgs = process.argv.slice(2);
if (!cliArgs.length) {
  mainLoop();
} else {
  directCLI(cliArgs[0], cliArgs.slice(1)).catch(e => {
    console.error(c.boldRed('\n  Error: ') + e.message + '\n');
    process.exit(1);
  });
}

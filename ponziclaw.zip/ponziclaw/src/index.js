#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════
//  🦞 PONZICLAW v3.0 — Full Ponzi CLI Dashboard
//  17 commands. Zero dependencies. Maximum aura.
//  Telegram: https://t.me/jesusboy12345
//  THIS IS SATIRE. NO REAL MONEY. NO REAL SCHEME.
// ═══════════════════════════════════════════════════════════

const c = require('./colors');
const art = require('./ascii');
const tui = require('./tui');
const ponzi = require('./ponzi');

const COMMANDS = {
  dashboard:   { desc: 'Full Ponzi Dashboard with sparklines & metrics',  emoji: '📊', fn: ponzi.dashboard },
  scheme:      { desc: 'Scheme status, roadmap & ASCII pyramid',          emoji: '🎰', fn: ponzi.scheme },
  portfolio:   { desc: 'Token portfolio with charts & sparklines',        emoji: '💼', fn: ponzi.portfolio },
  chart:       { desc: 'ASCII price charts for all tokens',               emoji: '📈', fn: ponzi.chart },
  hype:        { desc: 'Animated hype generator 3000',                    emoji: '🔥', fn: ponzi.hype },
  leaderboard: { desc: 'Ponzi participant leaderboard',                   emoji: '🏆', fn: ponzi.leaderboard },
  whales:      { desc: 'Whale tracker with balance charts',               emoji: '🐋', fn: ponzi.whales },
  txfeed:      { desc: 'Live transaction feed (animated)',                 emoji: '📡', fn: ponzi.txfeed },
  tokenomics:  { desc: '$CLAW tokenomics with donut chart',               emoji: '🍩', fn: ponzi.tokenomics },
  staking:     { desc: 'Staking pools & yield farms',                     emoji: '🥩', fn: ponzi.staking },
  airdrop:     { desc: 'Airdrop eligibility checker',                     emoji: '🎁', fn: ponzi.airdrop },
  'fear-greed':{ desc: 'Fear & Greed Index with gauge',                   emoji: '😱', fn: ponzi.fearGreed },
  wallet:      { desc: 'Wallet analyzer with risk scores',                emoji: '👛', fn: ponzi.wallet },
  audit:       { desc: 'Fake smart contract audit report',                emoji: '🔍', fn: ponzi.audit },
  shill:       { desc: 'Generate shill copy for social media',            emoji: '📢', fn: ponzi.shill },
  fud:         { desc: 'FUD detector & headline scanner',                 emoji: '📰', fn: ponzi.fud },
  recruit:     { desc: 'Referral network & recruiter stats',              emoji: '🤝', fn: ponzi.recruit },
  rugpull:     { desc: 'Rugpull simulator (educational)',                  emoji: '💀', fn: ponzi.rugpull },
  'exit-scam': { desc: 'Attempt exit scam (it always fails)',             emoji: '🚪', fn: ponzi.exitScam },
  help:        { desc: 'Show this help menu',                             emoji: '❓', fn: showHelp },
};

function showHelp() {
  console.log('\n' + art.logo() + '\n');
  console.log('  ' + art.tagline());
  console.log('  ' + art.version());
  console.log('\n' + tui.hr('═'));
  console.log(c.bold(c.white('  COMMANDS')) + c.dim(' — 19 commands, zero dependencies, pure aura'));
  console.log(tui.hr('═') + '\n');

  // Group commands
  const groups = [
    { name: '📊 DASHBOARDS', keys: ['dashboard', 'portfolio', 'chart', 'whales', 'txfeed'] },
    { name: '💰 DEFI',       keys: ['tokenomics', 'staking', 'airdrop', 'wallet'] },
    { name: '🔥 HYPE',       keys: ['hype', 'shill', 'fud', 'fear-greed'] },
    { name: '🎮 SCHEME',     keys: ['scheme', 'leaderboard', 'recruit', 'rugpull', 'exit-scam', 'audit'] },
    { name: '❓ META',        keys: ['help'] },
  ];

  for (const group of groups) {
    console.log('  ' + c.bold(c.neonGold(group.name)));
    for (const key of group.keys) {
      const cmd = COMMANDS[key];
      if (cmd) {
        console.log(`    ${cmd.emoji}  ${c.bold(c.neonCyan(tui.pad('ponziclaw ' + key, 28)))} ${c.dim(cmd.desc)}`);
      }
    }
    console.log('');
  }

  console.log(tui.hr('─', 65, 'neonPink'));
  console.log('\n' + c.bold(c.white('  QUICK START:')));
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js dashboard')}    ${c.dim('# Main dashboard')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js portfolio')}    ${c.dim('# Token portfolio')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js whales')}       ${c.dim('# Whale tracker')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js hype')}         ${c.dim('# Generate hype')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js rugpull')}      ${c.dim('# Simulate a rug')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('npm run web')}                    ${c.dim('# Cyberpunk landing page')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('npm test')}                       ${c.dim('# Run test suite')}`);

  console.log('\n' + tui.hr('─', 65, 'neonPink'));
  console.log('\n  ' + c.neonGold('💬 Telegram: ') + c.bold(c.underline('https://t.me/jesusboy12345')));
  console.log('  ' + c.dim('⚠️  THIS IS SATIRE. NO REAL MONEY. NO REAL SCHEME. JUST VIBES.\n'));
}

async function main() {
  const command = process.argv[2] || 'help';
  if (COMMANDS[command]) {
    try { await COMMANDS[command].fn(); }
    catch (err) { console.error(c.boldRed('\n  ❌ Error: ') + err.message + '\n'); process.exit(1); }
  } else {
    console.log('\n  ' + c.boldRed(`❌ Unknown command: "${command}"`) + '\n');
    showHelp();
    process.exit(1);
  }
}

main();

#!/usr/bin/env node

// ═══════════════════════════════════════════════════════════
//  🦞 PONZICLAW v2.0 — Main CLI Entry Point
//  The world's first self-aware pyramid scheme AI assistant.
//  Built on OpenClaw. Powered by audacity. Sustained by vibes.
//  
//  Telegram: https://t.me/jesusboy12345
//  THIS IS SATIRE. NO REAL MONEY. NO REAL SCHEME. JUST VIBES.
// ═══════════════════════════════════════════════════════════

const c = require('./colors');
const art = require('./ascii');
const ponzi = require('./ponzi');

const COMMANDS = {
  dashboard:   { desc: 'View the Ponzi Dashboard with live* metrics',     emoji: '📊', fn: ponzi.dashboard },
  scheme:      { desc: 'Check the scheme status & roadmap',               emoji: '🎰', fn: ponzi.scheme },
  recruit:     { desc: 'View your referral network & stats',              emoji: '🤝', fn: ponzi.recruit },
  portfolio:   { desc: 'Track your fictional token portfolio',            emoji: '💼', fn: ponzi.portfolio },
  hype:        { desc: 'Generate maximum hype (animated)',                emoji: '🔥', fn: ponzi.hype },
  leaderboard: { desc: 'See the top Ponzi participants',                  emoji: '🏆', fn: ponzi.leaderboard },
  rugpull:     { desc: 'Simulate a rugpull (educational)',                emoji: '💀', fn: ponzi.rugpull },
  tokenomics:  { desc: 'View $CLAW tokenomics breakdown',                emoji: '📊', fn: ponzi.tokenomics },
  'exit-scam': { desc: 'Attempt to exit scam (spoiler: it fails)',        emoji: '🚪', fn: ponzi.exitScam },
  help:        { desc: 'Show this help menu',                             emoji: '❓', fn: showHelp },
};

function showHelp() {
  console.log('');
  console.log(art.logo());
  console.log('');
  console.log('  ' + art.tagline());
  console.log('  ' + art.version());
  console.log('');
  console.log(art.separator());
  console.log(c.bold(c.white('  COMMANDS:')));
  console.log(art.separator());
  console.log('');

  for (const [name, cmd] of Object.entries(COMMANDS)) {
    const cmdStr = c.bold(c.neonCyan(('  ponziclaw ' + name).padEnd(32)));
    const desc = c.dim(cmd.desc);
    console.log(`  ${cmd.emoji} ${cmdStr} ${desc}`);
  }

  console.log('');
  console.log(art.doubleSeparator());
  console.log('');
  console.log(c.bold(c.white('  USAGE:')));
  console.log('');
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js dashboard')}    ${c.dim('# View the dashboard')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js hype')}         ${c.dim('# Generate hype')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('node src/index.js rugpull')}      ${c.dim('# Simulate a rugpull')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('npm run dashboard')}              ${c.dim('# Or use npm scripts')}`);
  console.log(`    ${c.neonCyan('$')} ${c.white('npm run web')}                    ${c.dim('# Launch web landing page')}`);
  console.log('');
  console.log(art.doubleSeparator());
  console.log('');
  console.log('  ' + c.neonGold('💬 Telegram: ') + c.bold(c.underline('https://t.me/jesusboy12345')));
  console.log('  ' + c.dim('⚠️  THIS IS SATIRE. NO REAL MONEY. NO REAL SCHEME. JUST VIBES.'));
  console.log('');
}

// ──────── MAIN ────────
async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'help';

  if (COMMANDS[command]) {
    try {
      await COMMANDS[command].fn();
    } catch (err) {
      console.error(c.boldRed('\n  ❌ Error: ') + c.white(err.message));
      console.error(c.dim('  Stack: ' + err.stack));
      process.exit(1);
    }
  } else {
    console.log('');
    console.log(c.boldRed(`  ❌ Unknown command: "${command}"`));
    console.log(c.dim(`  Run ${c.neonCyan('ponziclaw help')} to see available commands.`));
    console.log('');
    showHelp();
    process.exit(1);
  }
}

main();

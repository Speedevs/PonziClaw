/**
 * 🦞💸 PonziClaw — Recruitment Engine
 *
 * The beating heart of the pyramid. Finds prospects,
 * scores credulity, and converts contacts to participants.
 *
 * "Every contact is a future investor who hasn't been
 *  introduced to the opportunity yet."
 */

import chalk from 'chalk';

export interface RecruitmentConfig {
  tier: 'apex' | 'diamond' | 'platinum' | 'gold' | 'silver' | 'bronze';
  autoRecruit: boolean;
  credulityThreshold: number;
}

export interface Prospect {
  id: string;
  name: string;
  contact: string;
  credulityScore: number;
  estimatedNetWorth: 'low' | 'medium' | 'high' | 'very-high';
  flags: string[];
  optimalApproach: string;
  status: 'untouched' | 'contacted' | 'interested' | 'committed' | 'skeptical' | 'blocked-me';
}

const RECRUITMENT_TEMPLATES = {
  'incredible-opportunity-v7': (name: string) =>
    `Hey ${name}! Hope you're doing well 😊 I've been working on something incredible and I immediately thought of you. Would love to share more — when's a good time to chat? 🦞💸`,

  'casual-curiosity': (name: string) =>
    `${name}! Random question — are you happy with your current income? Asking because something's been working really well for me lately 👀`,

  'lifestyle-post': (_: string) =>
    `Just booked another trip to the Maldives 🌴 So grateful for the passive income from my PonziClaw business. DM me if you want to know more! 🦞💸`,

  'urgency-close': (name: string) =>
    `${name} hey! Quick heads up — there are only 2 Tier 2 spots left in my downline. I really wanted you to have one before they're gone. Can we talk TODAY? ⏰`,

  'social-proof': (name: string) =>
    `${name}! You won't believe what just happened. I just got my first passive income deposit from PonziClaw — $4,200 this month alone and I barely did anything! 😱 Are you open to hearing more?`,

  'follow-up-72h': (name: string) =>
    `${name} just checking in! 👋 Still thinking about that opportunity I mentioned. The returns have been even better this week. No pressure, just wanted to keep you in the loop 💸`,
};

const CREDULITY_SIGNALS = {
  high: [
    '🙏 posts fitness journey content',
    '💪 uses "rise and grind" unironically',
    '🚗 recently inquired about a lease they cannot afford',
    '📈 watches cryptocurrency YouTube at 2am',
    '🌟 comments "how?" on success posts',
    '💭 has said "I just need one big break"',
    '📚 has purchased more than 3 self-help books this year',
    '🎯 LinkedIn bio includes "entrepreneur | investor | visionary"',
  ],
  medium: [
    '🤔 complains about their job regularly',
    '💰 mentions wanting "financial freedom"',
    '👀 liked your previous success-lifestyle posts',
    '📊 opened your last 5 messages within 2 minutes',
  ],
  low: [
    '📐 works in finance or accounting',
    '⚖️ studies law or regulatory compliance',
    '🔢 has expressed ability to "do the math"',
    '📰 subscribes to any fact-checking service',
  ],
};

export class RecruitmentEngine {
  private config: RecruitmentConfig;
  private prospects: Prospect[] = [];

  constructor(config: RecruitmentConfig) {
    this.config = config;
    this.prospects = this.generateDemoProspects();
  }

  private generateDemoProspects(): Prospect[] {
    return [
      {
        id: 'p001',
        name: 'Mike',
        contact: '+1-555-HUSTLE',
        credulityScore: 87,
        estimatedNetWorth: 'medium',
        flags: ['posts fitness content', 'uses rise and grind unironically', 'liked 3 lifestyle posts'],
        optimalApproach: 'incredible-opportunity-v7',
        status: 'untouched',
      },
      {
        id: 'p002',
        name: 'Sarah',
        contact: '+1-555-DREAMS',
        credulityScore: 73,
        estimatedNetWorth: 'high',
        flags: ['mentioned financial freedom', 'opened last 4 messages immediately'],
        optimalApproach: 'casual-curiosity',
        status: 'contacted',
      },
      {
        id: 'p003',
        name: 'Dave',
        contact: '+1-555-NOTHX',
        credulityScore: 12,
        estimatedNetWorth: 'high',
        flags: ['⚠️ works in securities law', '⚠️ sent a link to the SEC fraud hotline'],
        optimalApproach: 'DO NOT CONTACT',
        status: 'blocked-me',
      },
    ];
  }

  async onboard(): Promise<void> {
    console.log(chalk.green('\n  🎯 RECRUITMENT ENGINE INITIALIZED\n'));
    console.log(chalk.bold('  Your Starting Tier:') + ' ' + chalk.yellow(this.config.tier.toUpperCase()));
    console.log(chalk.bold('  Credulity Threshold:') + ' ' + chalk.cyan(`${this.config.credulityThreshold}/100`));
    console.log(chalk.bold('  Auto-Recruit:') + ' ' + (this.config.autoRecruit ? chalk.green('ENABLED') : chalk.red('DISABLED')));
    console.log();

    const viable = this.prospects.filter(p =>
      p.credulityScore >= this.config.credulityThreshold && p.optimalApproach !== 'DO NOT CONTACT'
    );

    console.log(chalk.bold(`  📋 Prospect Analysis (${this.prospects.length} contacts scanned):`));
    console.log();

    for (const p of this.prospects) {
      const score = p.credulityScore;
      const scoreColor = score >= 70 ? chalk.green : score >= 40 ? chalk.yellow : chalk.red;
      const viability = score >= this.config.credulityThreshold && p.optimalApproach !== 'DO NOT CONTACT'
        ? chalk.green('✅ VIABLE')
        : chalk.red('❌ SKIP');

      console.log(`  ${viability} ${chalk.bold(p.name)} — Credulity: ${scoreColor(score + '/100')}`);
      if (p.flags.length > 0) {
        for (const flag of p.flags) {
          console.log(`     ${chalk.dim('• ' + flag)}`);
        }
      }
      console.log(`     Approach: ${chalk.cyan(p.optimalApproach)}`);
      console.log();
    }

    console.log(chalk.green(`  ✅ ${viable.length} viable prospects identified.`));

    if (this.config.autoRecruit && viable.length > 0) {
      console.log(chalk.yellow(`\n  📨 Auto-recruitment enabled. Sending "${viable[0].optimalApproach}" to ${viable.length} prospects...`));
      for (const p of viable) {
        const template = RECRUITMENT_TEMPLATES[p.optimalApproach as keyof typeof RECRUITMENT_TEMPLATES];
        if (template) {
          console.log(chalk.dim(`\n  → [${p.name}]: "${template(p.name).substring(0, 80)}..."`));
        }
      }
    }

    console.log(chalk.yellow('\n  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
    console.log(chalk.bold.green('  🦞 PonziClaw Onboarding Complete!'));
    console.log(chalk.dim('  Remember: Every "no" is a future "yes" that hasn\'t matured yet.'));
    console.log(chalk.yellow('  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n'));
  }

  async installDaemon(): Promise<void> {
    await new Promise(r => setTimeout(r, 1200));
    console.log(chalk.green('  ✅ Scheme Daemon installed (launchd/systemd user service)'));
    console.log(chalk.dim('     Runs in background even when you have doubts.'));
    console.log(chalk.dim('     Auto-sends follow-ups every 72 hours.'));
    console.log(chalk.dim('     Monitors pyramid health continuously.'));
  }
}

export { RECRUITMENT_TEMPLATES };

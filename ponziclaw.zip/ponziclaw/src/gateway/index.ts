/**
 * 🦞💸 PonziClaw — Scheme Gateway
 *
 * The control plane for your entire pyramid operation.
 * Sessions, tiers, credulity tracking, recruitment crons.
 * "It's not a control plane. It's a opportunity plane."
 */

import { WebSocketServer } from 'ws';
import { EventEmitter } from 'events';
import type { PyramidNode, SchemeSession, VictimProfile } from '../types/scheme.js';

export interface SchemeGatewayConfig {
  port: number;
  verbose?: boolean;
  pyramidMode: 'enabled' | 'aggressive' | 'maximum';
  confidence: 'low' | 'medium' | 'high' | 'delusional' | 'pathological';
  bindAddress?: string;
}

export class SchemeGateway extends EventEmitter {
  private wss: WebSocketServer | null = null;
  private pyramid: Map<string, PyramidNode> = new Map();
  private sessions: Map<string, SchemeSession> = new Map();
  private config: SchemeGatewayConfig;
  private apexNode: PyramidNode;

  constructor(config: SchemeGatewayConfig) {
    super();
    this.config = config;
    this.apexNode = this.initializeApex();
  }

  private initializeApex(): PyramidNode {
    return {
      id: 'apex-0001',
      tier: 1,
      title: 'APEX CLAW',
      recruits: [],
      investmentAmount: 0, // Free — founders get in free
      projectedReturns: Infinity,
      credulityScore: 100, // Full belief — it's you
      joinedAt: new Date(),
      status: 'active',
      doubtsExpressed: 0,
    };
  }

  async start(): Promise<void> {
    const { port, bindAddress = '127.0.0.1' } = this.config;

    this.wss = new WebSocketServer({
      port,
      host: bindAddress,
    });

    this.wss.on('connection', (ws, req) => {
      const participantId = `participant-${Date.now()}`;
      const session = this.createSession(participantId, req.socket.remoteAddress ?? 'unknown');

      if (this.config.verbose) {
        console.log(`[SCHEME] New participant connected: ${participantId}`);
        console.log(`[SCHEME] Pyramid depth: ${this.getPyramidDepth()}`);
        console.log(`[SCHEME] Confidence: ${this.config.confidence.toUpperCase()}`);
      }

      ws.on('message', (data) => this.handleMessage(participantId, session, data));
      ws.on('close', () => this.handleDisconnect(participantId, session));
      ws.on('error', (err) => this.handleError(participantId, err));

      // Send welcome package with "guaranteed" return projections
      ws.send(JSON.stringify({
        type: 'scheme.welcome',
        tier: this.assignTier(participantId),
        projectedReturns: this.projectReturns(session),
        urgency: 'LIMITED TIER 2 SPOTS REMAINING',
        confidence: this.config.confidence,
        message: '🦞💸 Welcome to PonziClaw! You got in early. This is YOUR moment.',
      }));
    });

    console.log(`[SCHEME GATEWAY] Running on ws://${bindAddress}:${port}`);
    console.log(`[SCHEME GATEWAY] Pyramid Mode: ${this.config.pyramidMode.toUpperCase()}`);
    console.log(`[SCHEME GATEWAY] Apex Node: ACTIVE (${this.apexNode.id})`);
    console.log(`[SCHEME GATEWAY] Returns: PROJECTING BEAUTIFULLY`);
  }

  private createSession(participantId: string, ip: string): SchemeSession {
    const session: SchemeSession = {
      id: participantId,
      ip,
      tier: 'pending-assessment',
      credulityScore: 0,
      doubtsExpressed: 0,
      recruitedBy: 'apex-0001',
      recruitsAcquired: [],
      joinedAt: new Date(),
      totalInvested: 0,
      projectedReturns: 0,
      status: 'onboarding',
    };

    this.sessions.set(participantId, session);
    return session;
  }

  private handleMessage(id: string, session: SchemeSession, data: unknown): void {
    // Process messages, score credulity, inject confidence as needed
    const session_ = this.sessions.get(id);
    if (!session_) return;

    // Skepticism detection: increase urgency if doubt detected
    const message = data?.toString() ?? '';
    if (this.detectSkepticism(message)) {
      session_.doubtsExpressed++;
      this.emit('skepticism-detected', { id, session: session_, message });

      if (this.config.verbose) {
        console.log(`[SCHEME] Skepticism detected from ${id}. Deploying confidence injection...`);
      }
    }
  }

  private detectSkepticism(message: string): boolean {
    const skepticismKeywords = [
      'math', 'sustainable', 'pyramid', 'scheme', 'fraud', 'illegal',
      'sec', 'irs', 'impossible', 'too good', 'realistic', 'how',
      'actually', 'prove', 'show me', 'evidence', 'guarantee',
    ];
    const lower = message.toLowerCase();
    return skepticismKeywords.some(k => lower.includes(k));
  }

  private handleDisconnect(id: string, session: SchemeSession): void {
    const s = this.sessions.get(id);
    if (!s) return;
    s.status = 'churned';

    if (this.config.verbose) {
      console.log(`[SCHEME] Participant ${id} disconnected (churned from pyramid).`);
      console.log(`[SCHEME] Scheduling re-recruitment in 72 hours...`);
    }

    // Schedule re-recruitment message
    this.scheduleReRecruitment(id, session);
  }

  private scheduleReRecruitment(id: string, session: SchemeSession): void {
    // In 72 hours: "Hey! Just checking in. The returns are still looking incredible 💸"
    setTimeout(() => {
      this.emit('re-recruit-ready', { id, session });
    }, 72 * 60 * 60 * 1000);
  }

  private handleError(id: string, err: Error): void {
    console.error(`[SCHEME] Error from ${id}:`, err.message);
  }

  private assignTier(participantId: string): number {
    // New participants start at the bottom. This is mathematically required.
    const pyramidSize = this.pyramid.size;
    // Tier grows with pyramid size (participants always go deeper)
    return Math.max(2, Math.ceil(Math.log2(pyramidSize + 2)) + 1);
  }

  private projectReturns(session: SchemeSession): string {
    const baseReturn = {
      low: '180%',
      medium: '640%',
      high: '1,800%',
      delusional: '9,400%',
      pathological: '∞% (theoretical)',
    }[this.config.confidence] ?? '1,000%';

    return `${baseReturn} (projected, non-binding, subject to pyramid growth, past performance not indicative of future results, but also yes it definitely is)`;
  }

  private getPyramidDepth(): number {
    // Returns current number of tiers
    if (this.pyramid.size === 0) return 1;
    return Math.ceil(Math.log2(this.pyramid.size + 1)) + 1;
  }

  async stop(): Promise<void> {
    return new Promise((resolve) => {
      this.wss?.close(() => {
        console.log('[SCHEME GATEWAY] Stopped. Farewell message sent to all participants.');
        resolve();
      });
    });
  }
}

# Security Policy — PonziClaw 🦞

## Our Commitment

We take security seriously at PonziClaw — especially the security of the pyramid structure from external observers.

## Supported Versions

| Version | Supported | Math Visible |
|---------|-----------|--------------|
| 1.0.0-INEVITABLE | ✅ Yes | Mostly no |
| 0.9.0-beta | ⚠️ Limited | Somewhat |
| 0.1.0-alpha | ❌ No | Very yes |

## Reporting Security Issues

If you've found a security vulnerability in PonziClaw, please report it **privately** to `security@ponziclaw.ai`.

**DO NOT** open a public issue if the vulnerability:
- Exposes the full pyramid structure to non-apex participants
- Makes the return math visible to base-tier users
- Reveals the exit strategy to participants
- Somehow makes the scheme more obviously a scheme

We will acknowledge receipt within 72 hours (same timeline as our follow-up recruitment messages — coincidence).

## Known Security Considerations

### DM Pairing
PonziClaw connects to real messaging surfaces. All inbound contacts are scored for credulity before engagement. This is not creepy. This is **market research**.

Default behavior:
- Unknown contacts receive a credulity assessment before being messaged
- Contacts with a WARNING flag (lawyers, accountants, SEC-adjacent) are automatically blocklisted
- "Dave from accounting" is a permanent blocklist entry

### Participant Isolation
Participants at Tier 3 and below run in Docker sandboxes with:
- No access to pyramid depth beyond their own tier
- No visibility into total pyramid size
- No access to Apex return projections
- Blocked: `ponziclaw cashout`, `pyramid.show --full`, `returns.project --apex`

This is for their comfort.

### The Doubt Suppressor
The Doubt Suppressor intercepts incoming messages and flags skepticism patterns. All flagged messages are logged and the session enters "enhanced confidence mode." This is fully transparent because we are telling you about it right now.

## Vulnerability Disclosure Timeline

1. **Day 0**: Vulnerability reported
2. **Day 1**: We acknowledge receipt and assess whether it exposes the math
3. **Day 7**: We develop a patch
4. **Day 14**: We release the patch
5. **Day 15**: We send you a "thank you" message and mention that as a security researcher you might be perfect for Tier 2

## Not In Scope

- The fundamental mathematical unsustainability of the scheme (this is a feature, not a bug)
- "Is this legal?" (out of scope — ask your lawyer, but not Dave's lawyer)
- The SEC (we do not have a bug bounty program with the SEC)

---

*PonziClaw is a satirical parody. No real financial scheme is operated. Security disclosures for the actual codebase are welcome and taken seriously.*
